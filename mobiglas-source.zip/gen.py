import json
S=[]
def a(body,name,type,qt=True,acces="inconnu",faction="",services="",notes=""):
    S.append(dict(body=body,name=name,type=type,qt=qt,acces=acces,faction=faction,services=services,notes=notes))
HH="Headhunters";CFP="Citizens for Prosperity";RR="Rough & Ready";PYAM="installation abandonnée"
# Pyro I
a("Pyro I","Gray Gardens Depot","colonie",notes="Dépôt de surface (settlement).")
for n in ["Phoenix-I","Phoenix-II","Phoenix-III","Tithonus-I","Tithonus-II","Tithonus-III"]:
    a("Pyro I",f"Lazarus Transport Hub {n}","avant-poste",faction="ASD",notes="Hub de transport desservant un labo Lazarus.")
a("Pyro I","Lazarus Phoenix Research Lab","autre",acces="restreint/hostile",faction="ASD",notes="Labo de recherche dans une tempête EM irradiée ; accès via les hubs de transport.")
a("Pyro I","Lazarus Tithonus Research Lab","autre",acces="restreint/hostile",faction="ASD",notes="Labo de recherche ASD ; accès via les hubs de transport.")
a("Pyro I","Stag's Rut","avant-poste minier")
a("Pyro I","Rustville","base hostile",acces="restreint/hostile",faction=HH,notes="Casse (salvage yard) tenue par les Headhunters.")
for L in ["1-2","1-3","1-5"]:
    a("Pyro I",f"PYAM-FARSTAT-{L}",PYAM,notes=f"Station Pyrotechnic Amalgamated abandonnée au point L{L[-1]}.")
a("Pyro I","Akiro Cluster","autre",notes="Amas situé au point L3 de Pyro I.")
# Monox
a("Monox","Last Ditch","avant-poste minier")
a("Monox","Ostler's Claim","base hostile",acces="restreint/hostile",faction=HH,notes="Site minier tenu par les Headhunters.")
a("Monox","Yang's Place","avant-poste minier",acces="libre",faction=CFP)
a("Monox","Sunset Mesa","avant-poste",acces="libre",faction=CFP,notes="Casse (salvage yard).")
a("Monox","Slowburn Depot","colonie")
a("Monox","Arid Reach","base hostile",acces="restreint/hostile",faction=HH,notes="Comptoir commercial tenu par les Headhunters.")
a("Monox","Jackson's Swap","avant-poste",acces="libre",faction=CFP,notes="Comptoir commercial.")
a("Monox","Checkmate Station","station orbitale",acces="libre",faction=RR,services="clinique (T2), hangar, terminal de commerce, raffinerie, boutiques (armures, vêtements, armes, pièces de vaisseau), location de véhicules, restauration",notes="QG de Rough & Ready au point L4 ; zone contestée et course Fool's Run.")
# Bloom
for n in ["Bueno Ravine","Frigid Knot","Narena's Rest"]:
    a("Bloom",n,"colonie",acces="libre",faction=CFP)
a("Bloom","Shepherd's Rest","colonie",acces="libre",faction=CFP,notes="Avant-poste agricole.")
a("Bloom","Carver's Ridge","base hostile",acces="restreint/hostile",faction=HH,notes="« Stay out unless you're bringing creds. »")
for n in ["The Golden Riviera","The Yard","Windfall"]:
    a("Bloom",n,"base hostile",acces="restreint/hostile",faction=HH)
a("Bloom","Shadowfall","base hostile",acces="restreint/hostile",faction="XenoThreat",notes="Homestead XenoThreat.")
a("Bloom","Prospect Depot","avant-poste",acces="libre",notes="Dépôt de stockage, « Traders welcome ».")
a("Bloom","Orbituary","station orbitale",acces="libre",faction=RR,services="clinique, habitation, réparation/ravitaillement, raffinerie, boutiques (armures, armes, vêtements, pièces de vaisseau), bar",notes="Station en orbite de Bloom, plaque tournante hors-la-loi.")
a("Bloom","Starlight Service Station","station orbitale",acces="libre",faction=CFP,services="clinique, habitation, réparation, ravitaillement",notes="Point L1 de Bloom.")
a("Bloom","Patch City","station orbitale",acces="libre",faction=RR,services="clinique (T2), habitation, réparation, ravitaillement, hangar, terminal de commerce, boutiques (armures, armes, vêtements, pièces de vaisseau), bar, restauration",notes="Point L3 de Bloom.")
a("Bloom","PYAM-SUPVISR-3-4",PYAM,notes="Station abandonnée au point L4 de Bloom.")
a("Bloom","PYAM-FARSTAT-3-5",PYAM,notes="Station abandonnée au point L5 de Bloom.")
# Pyro IV
for n in ["Chawla's Beach","Dinger's Depot","Sacren's Plot"]:
    a("Pyro IV",n,"avant-poste")
for n in ["Fallow Field","Goner's Deal"]:
    a("Pyro IV",n,"base hostile",acces="restreint/hostile",faction=HH)
for n in ["I","II","III","IV","V","IX"]:
    a("Pyro IV",f"Farro Data Center {n}","autre",notes="Centre de données.")
# Pyro V
a("Pyro V","PYAM-FARSTAT-5-1",PYAM,notes="Station abandonnée au point L1.")
a("Pyro V","Gaslight","station orbitale",acces="libre",faction=RR,services="clinique, habitation, boutiques (armes, armures, pièces de vaisseau), pont cargo",notes="Point L2 de Pyro V.")
a("Pyro V","PYAM-FARSTAT-5-3",PYAM,notes="Station abandonnée au point L3.")
a("Pyro V","Rod's Fuel 'N Supplies","station orbitale",acces="libre",faction=CFP,services="clinique, habitation, réparation, ravitaillement",notes="Point L4 de Pyro V.")
a("Pyro V","Rat's Nest","station orbitale",acces="libre",faction=RR,notes="Point L5 de Pyro V.")
# Moons
a("Ignis","Ashland","base hostile",acces="restreint/hostile",faction=HH,notes="Comptoir commercial tenu par les Headhunters.")
a("Ignis","Kabir's Post","avant-poste",acces="libre",faction=CFP,notes="Comptoir commercial.")
a("Vatra","Seer's Canyon","base hostile",acces="restreint/hostile",faction=HH,notes="Casse Headhunters (« Scrap so fresh... »).")
a("Adir","Prophet's Peak","autre")
a("Adir","Derelict Outpost","installation abandonnée",notes="Avant-poste abandonné.")
a("Adir","Obsidian crack","autre",qt=False,notes="Coulée d'obsidienne de 700 km (repère géologique, non QT).")
a("Fairo","FEO Canyon Depot","avant-poste",notes="Dépôt.")
a("Fairo","YW-2455-WS","autre",notes="Type non précisé par la source.")
for n in ["RAB-Lamda","RAB-Over","RAB-Victory"]:
    a("Fuego",n,"base hostile",notes="Base astéroïde (Rough Asteroid Base) listée près de Fuego, sans détail.")
# Terminus
a("Terminus","Bullock's Reach","colonie",acces="libre",faction=CFP,notes="Ferme.")
a("Terminus","Kinder Plots","base hostile",acces="restreint/hostile",faction=HH,notes="Ferme tenue par les Headhunters.")
a("Terminus","Scarper's Turn","colonie",notes="Ferme.")
a("Terminus","Stonetree","colonie",notes="Homestead.")
a("Terminus","Last Landings","base hostile",acces="restreint/hostile",faction=HH,notes="Casse (salvage yard).")
a("Terminus","Supply Gap","avant-poste",notes="Casse (salvage yard).")
a("Terminus","Watcher's Depot","colonie")
a("Terminus","Blackrock Exchange","avant-poste",notes="Comptoir commercial.")
a("Terminus","Canard View","avant-poste",acces="libre",faction=CFP,notes="Comptoir commercial.")
a("Terminus","Rough Landing","base hostile",acces="restreint/hostile",faction=HH,notes="Comptoir commercial tenu par les Headhunters.")
a("Terminus","Ruin Station","station orbitale",acces="libre",faction="XenoThreat",services="clinique (T2), hangar, terminal de commerce, raffinerie, concessionnaire de vaisseaux, boutiques (armures, vêtements, armes, pièces de vaisseau), location de véhicules, restauration, bar Neutrality",notes="Repaire de gangs ; Ghost Arena ; contrôle pouvant changer.")
a("Terminus","PYAM-FARSTAT-6-2",PYAM,notes="Station abandonnée au point L2.")
a("Terminus","Endgame","station orbitale",acces="libre",faction=RR,services="clinique, habitation, réparation, ravitaillement, boutiques (armures, armes, vêtements, pièces de vaisseau), bar, restauration",notes="Point L3 de Terminus.")
a("Terminus","Dudley & Daughters","station orbitale",acces="libre",faction=CFP,services="clinique, habitation, réparation, ravitaillement",notes="Point L4 de Terminus.")
a("Terminus","Megumi Refueling","station orbitale",acces="libre",faction=RR,services="ravitaillement",notes="Point L5 de Terminus.")
# Nyx
a("Delamar","Levski","zone d'atterrissage",acces="libre",faction="People's Alliance",services="hôpital (Mercy Hospital), hangars XL, terminal de commerce, raffinerie, boutiques (armures, armes, vaisseaux/composants, bazar), bar Café Musain, location de véhicules, réparation, ravitaillement, habitations",notes="Ville franche bâtie dans l'ancienne mine QV Planet Services.")
out={"sites":S,"sources":["https://starcitizen.tools/"+p for p in ["Pyro_system","Nyx_system","Pyro_I","Monox","Bloom","Pyro_IV","Pyro_V","Terminus","Ignis","Vatra","Adir","Fairo","Fuego","Vuur","Delamar","Nyx_I","Nyx_II","Nyx_III","Levski","Ruin_Station","Orbituary","Starlight_Service_Station","Checkmate_Station","Patch_City","Gaslight","Rat%27s_Nest","Endgame","Rod%27s_Fuel_%27N_Supplies","Megumi_Refueling","Dudley_%26_Daughters","Shepherd%27s_Rest","Carver%27s_Ridge","Shadowfall","Prospect_Depot","Seer%27s_Canyon","Lazarus_Phoenix_Research_Lab","Citizens_for_Prosperity","Headhunters","Rough_%26_Ready","XenoThreat","Glaciem_Ring"]]}
json.dump(out,open("sites_pn.json","w"),ensure_ascii=False,indent=1)
from collections import Counter;print(Counter(s["body"] for s in S),len(S))
