# Appli mobiGlas d'Exo (PWA) — mode d'emploi pour la mettre à jour

- **Dépôt GitHub** : `Exo7-Seeker/Mobiglas` (M majuscule ; public, branche `main`, fichiers à la racine).
- **Adresse de l'appli** : https://exo7-seeker.github.io/Mobiglas/ — le M majuscule est obligatoire (avec `mobiglas` en minuscules : 404). En ligne depuis le 2 oct. 2026 (GitHub Pages, branche main, dossier racine).
- **Accès de Claude au dépôt** : lecture seule (clone public via le proxy git) pour vérifier les fichiers envoyés. Pas d'écriture : les fichiers sont envoyés dans la conversation et le joueur les dépose lui-même via https://github.com/Exo7-Seeker/Mobiglas/upload/main (puis bouton vert « Commit changes » tout en bas de la page).
- **Aperçu** : https://claude.ai/artifact/T8cccERSSEW2PEqJzMpDtS (Seeker n'y répond pas et les photos du wiki n'y chargent pas : il faut l'appli en ligne).
- **Style** : B · mobiGlas (hologramme cyan, coins coupés, Seeker en ambre). Maquettes : https://claude.ai/artifact/MXzc8JJHWDHuGQcNbeDW4i
- **Origine** : le journal de bord (https://claude.ai/artifact/MPGKKGSszAvhUaoLXsMTz9) reconstruit en appli autonome : la base claude.ai est remplacée par `data.json` + stockage local du téléphone.
- **Décision du joueur (2 oct. 2026)** : pas de nouvelles fonctions non demandées (contrats, portefeuille, minuteurs… écartés pour l'instant). Priorité : cohérence de ce qui est créé et généré.
- **Version actuelle** : v1.4 (cache `mg-v8`).
- **Icône** : le joueur peut envoyer l'image qu'il veut ; Claude en fait `icon-192.png` et `icon-512.png`.
- **Installer** : Chrome → ⋮ → « Ajouter à l'écran d'accueil » / « Installer l'application ». Pour un vrai fichier Android (APK) : pwabuilder.com avec l'adresse de l'appli (facultatif).

## Fichiers (10 + README)
`index.html` (appli complète), `data.json` (contenu évolutif), `manifest.webmanifest`, `sw.js` (installation + hors ligne ; version de cache à incrémenter à chaque mise à jour), `icon-192.png`, `icon-512.png`, `corsair.webp`, `f7c.webp`, `vulture.webp`, `exo.webp`.

## Mettre à jour l'histoire = remplacer seulement `data.json`
Une clé par collection, chaque document sous son id :
`{"journal":{"e-2026-10-01":{…}}, "cap":{…}, "hangar":{…}, "spectrum":{…}, "decouvertes":{…}, "contacts":{…}, "images":{…}}`.
- Entrée de journal : `images` = liste de `{src:"fichier.webp"}`, `{wiki:"Fichier.jpg"}` (catalogue), `{url,thumb,wikiname}` (ajoutée par Seeker) ou une clé `scene` du catalogue, + `legende`. Chaque image est placée automatiquement après le paragraphe qu'elle illustre.
- Spectrum : `titres` + `articles` (`source` = New United / Terra Gazette / Vox Populi / Crosshair, `rubrique`, `titre`, `texte`, `image:{wiki,legende}`).
Garder l'artefact journal et `data.json` synchronisés.
- **Attention** : ce que Seeker ajoute (images, exploration) est stocké sur le téléphone et remplace l'entrée entière côté téléphone. Avant de réécrire une entrée dans `data.json`, demander au joueur l'export (« Exporter mes changements » dans les réglages de Seeker) et l'intégrer, sinon ses ajouts masquent les modifications.

## Règles d'images (demandées par le joueur)
- **RÈGLE FERME (2 oct. 2026)** : aucune illustration générée par Claude dans l'appli sans validation préalable du joueur. Il les trouve « vraiment pas belles ». Si une nouvelle image générée semble utile : la montrer d'abord, ne l'intégrer qu'après son accord ; sinon ne pas en faire.
- Seulement de vraies images : captures du joueur d'abord, puis photos du Star Citizen Wiki. Le joueur a validé le rendu des photos du wiki (« c'est parfait »).
- Jamais deux fois la même image dans le journal.
- Une image par page du journal, cohérente avec l'action racontée sur la page : l'appli choisit dans le catalogue `CAT` de `revue.js` par mots-clés du texte (uniquement des entrées `wiki` ou `src`).
- Photos du wiki : Claude ne peut pas les télécharger (réseau bloqué). L'appli les charge directement depuis `media.starcitizen.tools` sur le téléphone (miniature 1280px webp, sinon l'original) et les garde en cache pour le hors-ligne. Si une photo ne charge pas, la figure est retirée. Légende suivie de « · Star Citizen Wiki ». URLs calculées par `wiki_urls.py` (md5 du nom de fichier) dans `wiki.js` ; ajouter le nom de fichier dans `FILES` pour une nouvelle photo.
- Pour trouver une photo : WebFetch de la page du wiki (ex. starcitizen.tools/Lorville) en demandant la liste des noms de fichiers ; vérifier un nom sur sa page `File:`.
- Photos du wiki utilisées (journal) : Lorville-buildings-3.19-CIG, Lorville-Teasa-Spaceport-Aerial, metro-center, Leavsden Square, L19 vista, L19 habroom, MV-bar, Hurston-strip-mine, Hurston_OuterDistricts_v002 (concept), Reclamation & Disposal, Teasa Spaceport de jour, Lorville-Teasa-Spaceport-3.19, RSI-Arccorp_03-Min (Area18), Streaking_Vulture, Magda en orbite, Vulture_flying_through_debris_field, Lorville_redesign_preview, MariaPureOfHeart, Maria hospital (Workers District), Hospital_Bed_Regeneration, Hurston-4.3.
- Spectrum : Crusader-orison-spaceport-exterior-01, Hospital_Bed_Regeneration, Quantum_Drive_Travel, The_Glaciem_ring_in_the_space_of_Nyx, metro-center.
- Photos du joueur : exo (couverture), vulture, f7c (années de contrats), corsair (années d'équipage).

## Carte
- Seuls Stanton, Pyro et Nyx sont en couleur : ce sont les systèmes jouables en jeu. Les autres (lore, pas encore dans le jeu) sont en gris.

## Ce que contient l'appli (v1)
- Onglets : Seeker, Carte, Hangar, Journal, Cap, Codex, Contacts, Spectrum (icônes compactes, tous visibles).
- Démarrage animé, fond étoilé en parallaxe, scintillement au changement d'onglet, sons et vibrations (désactivables).
- **Journal** : revue en pages plein écran (couverture, sommaire, prologue, souvenirs sépia, entrées), page tournée en glissant ou par les bords.
- **Spectrum** : une avec vignettes ; toucher une news ouvre l'article (image, journal source, texte, article suivant).
- **Carte** : moteur 3D maison sur les trois niveaux (galaxie, système, planète) ; glisser de côté = tourner, vertical = défiler vers la fiche, pincer = zoomer ; recentrage automatique.
- **Seeker** : micro ou texte, voix grave réglable ; API Claude appelée depuis le téléphone avec la clé du joueur (stockée seulement sur le téléphone, jamais dans le dépôt). Haiku 4.5 par défaut. Abandon propre après 35 s sans réponse. Ignore les phrases qui commencent par « Virgil ».
  - Outils : `chercher` (données de l'appli), `wiki_sc` (base Star Citizen en direct : API de starcitizen.tools, recherche + résumé), `chercher_image` (photos du wiki par nom de fichier), `ajouter_image` (ajoute une photo du wiki à une entrée du journal, dernière par défaut, avec légende ; le journal se remet en page tout seul), `tracer_route`, `afficher_carte`, `ouvrir_hangar`, `ouvrir_codex`, `marquer_explore`.
  - Seeker choisit les photos d'après leur nom de fichier (il ne les voit pas).
- Optimisations v1.1 : fond étoilé à 30 i/s et en pause en arrière-plan, mise en page stable au clavier et à la rotation, data.json et polices en cache hors ligne.
- Les changements faits dans l'appli restent sur le téléphone ; bouton « Exporter mes changements » (JSON).
