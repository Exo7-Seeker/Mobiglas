import json, html, re

# reuse peoples / factions data from annex builder
src = open('build_annexes.py', encoding='utf-8').read()
seg = src[src.index('peoples_h = ['):src.index('esc = html.escape')]
ns = {}
exec(seg, ns)
peoples_h, peoples_a, factions, elsewhere = ns['peoples_h'], ns['peoples_a'], ns['factions'], ns['elsewhere']

def G(a, b, bands=None, atmo=None, lights=None, seed=1):
    return dict(base=[a, b], bands=bands, atmo=atmo, lights=lights, seed=seed)

# utility tags
TAGS = {
  "vente":  ("Vente salvage", "#e0a347"),
  "minage": ("Minage", "#86cfc8"),
  "pvp":    ("PvP", "#e2624b"),
  "combat": ("Combat PvE", "#d98a5a"),
  "explo":  ("Découverte", "#a99be8"),
  "chasse": ("Chasse", "#8fc27a"),
  "achat":  ("Achats & équipement", "#7fb0e6"),
  "refuge": ("Hors-la-loi", "#b0a79c"),
  "service":("Services", "#c9c3b3"),
}

B = []
def body(sys, parent, name, desig, kind, climat, atmo, flore, faune, decouverte, faction, util, poi, planet):
    B.append(dict(sys=sys, parent=parent, name=name, desig=desig, kind=kind, climat=climat, atmo=atmo,
                  flore=flore, faune=faune, decouverte=decouverte, faction=faction,
                  util=[dict(tag=t, note=n) for t, n in util], poi=poi, planet=planet))

S = "Stanton"
body(S, None, "Hurston", "Stanton I", "Planète tellurique", "Chaud et sec, ancienne savane très dégradée", "Lourde, polluée par l'industrie",
     "Savane, arbres épars", "Kopion des savanes (meute, cornes précieuses) · Xiphopod, « crabe aveugle » flottant, invasif",
     "Système découvert en 2851 par Toshi Aaron ; planète achetée aux enchères par Hurston Dynamics", "Hurston Dynamics · Hurston Security",
     [("vente", "Lorville, CBD : RMC ~6 800 aUEC"), ("achat", "New Deal (vaisseaux), Tammany & Sons"), ("minage", "Aluminium, cuivre, corindon, étain, quantanium"), ("chasse", "Kopion : cornes (régénération osseuse)")],
     "Lorville · Everus Harbor (orbite)", G("#b89a78", "#4e3a2c", {"n": 14, "colors": ["#8c6f55", "#d1b590", "#6d5a48"]}, "rgba(230,180,120,A)", None, 5))
body(S, "Hurston", "Arial", "Lune de Hurston", "Lune brûlante", "78 à 171 °C, brume de chaleur", "Azote, toxique",
     "Prota (ressource récoltable)", "Aucune connue", "Rattachée à Hurston (2851)", "Hurston Dynamics",
     [("minage", "Avant-postes HDMS-Bezdek et Lathan"), ("combat", "Bases hors-la-loi Coven, Smokestack, The Dregs")],
     "HDMS-Bezdek · HDMS-Lathan · Coven · Smokestack · The Dregs", G("#d9a06a", "#5a2e1a", None, "rgba(255,170,110,A)", None, 21))
body(S, "Hurston", "Aberdeen", "Lune de Hurston", "Lune infernale", "170 à 237 °C", "Dioxyde de soufre, ciel jaune",
     "Écosystème effondré (anciennes prairies)", "Aucune", "Rattachée à Hurston ; essais d'antimatière supposés", "Hurston Dynamics",
     [("minage", "Aluminium, corindon, agricium, aslarite, titane, quantanium ; gemmes au ROC"), ("service", "Prison de Klescher (CrimeStat)")],
     "Klescher Rehabilitation Facility", G("#e4d06a", "#6b5a1c", {"n": 8, "colors": ["#f3e08a", "#a38f2c"]}, "rgba(240,220,110,A)", None, 22))
body(S, "Hurston", "Magda", "Lune de Hurston", "Lune rocheuse", "+5 à −80 °C", "Azote, toxique",
     "Aucune", "Aucune connue", "Porte le nom de Magda Hurston, patronne de Hurston Dynamics", "Hurston Dynamics",
     [("minage", "HDMS-Hahn, HDMS-Perlman"), ("explo", "Rocher de Sketto, lieu touristique")],
     "HDMS-Hahn · HDMS-Perlman · Sketto Rock", G("#8fa1b3", "#2b3542", None, None, None, 23))
body(S, "Hurston", "Ita", "Lune de Hurston", "Lune froide", "−10 à −22 °C", "Azote, traces de méthane",
     "Aucune", "Aucune connue", "Rattachée à Hurston", "Hurston Dynamics",
     [("minage", "Cuivre, étain, aluminium, corindon, agricium, titane"), ("combat", "Sites militaires The Shades, Thimblerig")],
     "HDMS-Ryder · HDMS-Woodruff · The Shades · Thimblerig", G("#9e8f86", "#3a322e", None, None, None, 24))

body(S, None, "Crusader", "Stanton II", "Géante gazeuse de faible masse", "Doux en haute altitude", "Respirable dans les couches hautes",
     "Aéroplancton, kiami", "Stormwal, « baleine du ciel » jusqu'à 100 m, sans doute menacée", "Achetée aux enchères par Crusader Industries", "Crusader Industries · Crusader Security",
     [("vente", "Orison, TDD Cloudview Center : RMC ~7 100 aUEC (meilleur prix de Stanton)"), ("achat", "Showroom Crusader, Cousin Crow's (tourelle F7C)"), ("combat", "Siege of Orison, mission FPS instanciée à 4"), ("explo", "Cité flottante, plateformes dans les nuages")],
     "Orison · Seraphim Station (orbite)", G("#f0c7a4", "#8a5a64", {"n": 20, "colors": ["#fbe3cb", "#c7858a", "#e9b28f"]}, "rgba(255,190,160,A)", None, 6))
body(S, "Crusader", "Cellin", "Lune de Crusader", "Lune volcanique", "−41 à 0 °C", "Dioxyde de soufre très fin",
     "Aucune", "Aucune connue", "Rattachée à Crusader", "Crusader Industries",
     [("minage", "Agricium, aslarite, titane, taranite, quantanium"), ("explo", "Plus de 100 volcans endormis ; geysers capables de détruire un véhicule")],
     "Volcans, geysers thermiques", G("#b7b09a", "#3f3b30", None, None, None, 31))
body(S, "Crusader", "Daymar", "Lune de Crusader", "Lune désertique", "−40 à 78 °C, tempêtes de poussière", "Azote-méthane, toxique",
     "Rare", "Valakkar (ver géant, dangereux ; dents et perles)", "Rattachée à Crusader", "Crusader Industries",
     [("chasse", "Valakkar : dents, perles"), ("explo", "Covalex Hub Gundo abandonné, épave de l'UEES Flyssa, Daymar Rally"), ("minage", "Hephaestanite, silicium, quartz, agricium, titane")],
     "Covalex Hub Gundo · épave UEES Flyssa · parcours de la Daymar Rally", G("#d79a62", "#5a3620", {"n": 6, "colors": ["#e8b27c", "#b3743f"]}, "rgba(240,170,110,A)", None, 32))
body(S, "Crusader", "Yela", "Lune de Crusader", "Lune de glace", "0 à −43 °C", "Oxygène mince, respirable (0,19 atm)",
     "Aucune", "Aucune connue", "Rattachée à Crusader ; seul corps de Stanton avec sa propre ceinture", "Crusader Industries (ceinture : hors-la-loi)",
     [("refuge", "Grim HEX : station des hors-la-loi, marché noir"), ("pvp", "Jumptown : labo de drogue disputé entre joueurs"), ("minage", "Agricium, aslarite, titane, hephaestanite, quartz, taranite")],
     "Grim HEX · Jumptown · ceinture de Yela", G("#e8eef3", "#6f8392", None, "rgba(210,230,245,A)", None, 33))

body(S, None, "ArcCorp", "Stanton III", "Planète-ville", "Urbain, pluies fréquentes", "Respirable, saturée",
     "Urbaine uniquement", "Aucune sauvage", "Achetée aux enchères par ArcCorp", "ArcCorp · ArcCorp Security",
     [("achat", "Astro Armada (vaisseaux), CenterMass (armes, tourelle F7C), Dumper's Depot"), ("service", "Riker Memorial Spaceport, hangars personnels")],
     "Area18 · Baijini Point (orbite)", G("#d98b57", "#5a2a1c", {"n": 10, "colors": ["#f0a76d", "#7a3a22"]}, None, {"n": 140, "color": "#ffd9a0"}, 7))
body(S, "ArcCorp", "Lyria", "Lune d'ArcCorp", "Lune de glace", "−20 à −4 °C, cryogeysers", "Oxygène très mince (0,09 atm)",
     "Aucune", "Aucune connue", "Rattachée à ArcCorp", "ArcCorp · exploitations Shubin",
     [("minage", "Cuivre, fer, étain, laranite, tungstène, quantanium : bon spot de quantanium")],
     "Mines Shubin · cryovolcans", G("#c9dbe6", "#4b5f70", None, "rgba(190,220,240,A)", None, 41))
body(S, "ArcCorp", "Wala", "Lune d'ArcCorp", "Lune rocheuse allongée", "−2 à −19 °C", "Trop fine pour respirer",
     "Ferme (installation agricole)", "Aucune connue", "Rattachée à ArcCorp", "ArcCorp",
     [("minage", "Mines et raffinerie"), ("explo", "Affleurements de géodes, forme étirée par les marées")],
     "Installations minières · ferme", G("#a9a39a", "#3e3a35", None, None, None, 42))

body(S, None, "microTech", "Stanton IV", "Planète tellurique", "Froid, couverture nuageuse dense (terraformation ratée)", "Respirable, glaciale",
     "Forêts et toundra enneigées", "Kopion des forêts et de la toundra · Boreal Stalker, prédateur créé par génie génétique", "Achetée aux enchères par microTech", "microTech · microTech Protection Services",
     [("vente", "New Babbage, TDD Commons : RMC ~6 000 aUEC"), ("achat", "CenterMass, Aparelli, Shubin"), ("chasse", "Kopion, Boreal Stalker"), ("minage", "Hephaestanite, glace, quartz, silicium, fer, quantanium")],
     "New Babbage · Port Tressler (orbite)", G("#eef4f8", "#5f7f9a", {"n": 10, "colors": ["#ffffff", "#a9c3d6"]}, "rgba(200,230,255,A)", None, 8))
body(S, "microTech", "Calliope", "Lune de microTech", "Lune de glace", "Jusqu'à −124 °C, vents violents, brouillard", "Riche en oxygène, rude",
     "Aucune", "Aucune connue", "Rattachée à microTech", "microTech · Shubin · Rayari",
     [("minage", "Fer, hephaestanite, quartz, silicium, quantanium"), ("explo", "Labos de recherche Rayari")],
     "Mines Shubin · labos Rayari", G("#dfe7ee", "#556675", None, "rgba(200,220,240,A)", None, 51))
body(S, "microTech", "Clio", "Lune de microTech", "Lune océanique gelée", "−32 à −77 °C", "Azote",
     "Aucune", "Aucune connue", "Rattachée à microTech", "microTech",
     [("explo", "Océans liquides, icebergs, ciel rose-vert, eaux jade : la plus belle lune de Stanton"), ("minage", "Cuivre, étain, taranite, quantanium")],
     "Océans, icebergs", G("#b8e2d6", "#2f6a66", None, "rgba(180,240,220,A)", None, 52))
body(S, "microTech", "Euterpe", "Lune de microTech", "Petite lune gelée", "−84 à −118 °C", "Azote, traces de vapeur d'eau",
     "Aucune", "Aucune connue", "Rattachée à microTech", "microTech",
     [("explo", "Océans gelés, archipels à cheminées rocheuses")],
     "Archipels", G("#d4dce6", "#4a5566", None, None, None, 53))
body(S, None, "Aaron Halo", "Ceinture d'astéroïdes", "Grande ceinture", "Vide spatial", "Aucune",
     "Aucune", "Aucune", "Porte le nom de Toshi Aaron, découvreur du système", "Aucune (espace de Stanton)",
     [("minage", "Béryl, agricium, aslarite, titane, quantanium : grande zone de quantanium"), ("combat", "Pirates occasionnels")],
     "Entre les orbites de Crusader et d'ArcCorp", G("#6a6660", "#1e1c1a", None, None, None, 91))

body(S, None, "Installations Onyx", "Réseau ASD", "Laboratoires abandonnés (~100)", "Intérieur, grottes profondes", "Variable",
     "—", "Yormandi, prédateur des grottes (yeux : anticorps ; langue : mets recherché) · Kopion irradiés", "Découvertes pendant la crise de la régénération (Alpha 4.3)", "ASD (Associated Sciences & Development)",
     [("combat", "Sécurité d'ASD, créatures, enquête Hockrow"), ("explo", "Ailes de recherche, secrets du Dr Jorrit"), ("chasse", "Yormandi")],
     "Réparties dans tout Stanton", G("#5a6a5a", "#141a14", None, "rgba(140,220,140,A)", None, 92))

P = "Pyro"
body(P, None, "Pyro I", "Pyro I", "Tellurique de silicates", "Extrêmement chaud, haute pression, tempêtes radioactives", "Dense, vents violents, foudre",
     "Plantes résistantes à la chaleur", "Valakkar irradiés (tempêtes) · faune résistante à la chaleur", "Anomalie détectée en 2469 (Raj MacEwan), système revendiqué en 2493 par Pyrotechnic Amalgamated", "Aucune · laboratoires d'ASD",
     [("chasse", "Valakkar irradiés : perles (Second Life Initiative)"), ("explo", "Labos ASD Lazarus et Tithonus, crise de la régénération")],
     "Lazarus Phoenix · Tithonus", G("#e0703a", "#4a1409", {"n": 8, "colors": ["#ff9a5a", "#8a2a12"]}, "rgba(255,120,60,A)", None, 61))
body(P, None, "Monox", "Pyro II", "Tellurique sans noyau", "Tempéré", "Oxygène + monoxyde de carbone, toxique",
     "Rare", "Valakkar (espèce invasive)", "Cicatrices minières de Pyrotechnic ; hors-la-loi depuis le XXVIe siècle", "Aucune · gangs",
     [("chasse", "Valakkar"), ("combat", "Avant-postes hors-la-loi")],
     "Anciennes mines", G("#9a8f7a", "#3a3326", None, None, None, 62))
body(P, None, "Bloom", "Pyro III", "Tellurique glacée", "Froid", "Azote-oxygène, naturellement respirable",
     "Présente (monde respirable)", "Kopion des cavernes", "Ancien épicentre minier de Pyrotechnic", "Aucune · squatters",
     [("minage", "Bexalite, borase, or, laranite, hephaestanite, fer"), ("chasse", "Kopion des cavernes"), ("explo", "Le seul monde de Pyro où l'on respire sans masque")],
     "Avant-postes de squatters", G("#c9d3cf", "#44504c", None, "rgba(200,230,220,A)", None, 63))
body(P, None, "Pyro IV", "Pyro IV", "Tellurique percutée", "Instable", "Récente, en formation",
     "Aucune", "Aucune connue", "Percutée par un corps planétaire ; en route de collision avec Pyro V", "Aucune",
     [("minage", "Laranite, tungstène, cuivre, bexalite, borase, or"), ("explo", "Installations de données (crise de la régénération)")],
     "Installations de données", G("#8a4a3a", "#2a100c", {"n": 6, "colors": ["#b3654e", "#4e1a12"]}, None, None, 64))
body(P, None, "Pyro V", "Pyro V", "Géante gazeuse (la plus grande)", "—", "Tourbillons verts et jaunes",
     "—", "—", "Plus grande planète du système", "Aucune",
     [("service", "Récolte et ravitaillement en hydrogène"), ("minage", "Lune Ignis : bexalite, borase, or, laranite")],
     "Lunes Ignis, Vatra, Adir, Fairo, Fuego, Vuur", G("#c7cf6a", "#3d4a1a", {"n": 18, "colors": ["#e0e38a", "#7f9a3a", "#b7b04a"]}, "rgba(210,220,120,A)", None, 65))
body(P, None, "Terminus", "Pyro VI", "Tellurique", "Glacial", "Azote-oxygène avec méthane (respirable mais malsain)",
     "Présente", "Non documentée", "Ancien hub de Pyrotechnic ; Ruin Station prise par XenoThreat en 2947", "XenoThreat (Ruin Station) · gangs",
     [("pvp", "Ruin Station : zone contestée (« Ghost Arena »)"), ("minage", "Bexalite, borase, or, agricium, titane"), ("combat", "Guerres de gangs")],
     "Ruin Station · nombreux avant-postes", G("#b9c4cc", "#3a4650", {"n": 6, "colors": ["#d8e0e6", "#7c8a95"]}, "rgba(200,215,230,A)", None, 66))
body(P, None, "Stations de Pyro", "Espace orbital", "Stations et zones contestées", "—", "Habitats pressurisés",
     "—", "—", "Stations construites par Pyrotechnic, reprises par les factions", "Rough & Ready · Citizens for Prosperity · XenoThreat",
     [("vente", "Admin d'Endgame, Patch City, Starlight Service : RMC ~7 700 aUEC (meilleur prix connu)"), ("pvp", "Zones contestées Checkmate, Orbituary, Ruin Station ; Executive Hangar PYAM-EXHANG-0-1 (vaisseaux, armes, composants A)"), ("refuge", "Aucune loi, aucun CrimeStat")],
     "R&R : Checkmate, Orbituary, Patch City, Gaslight, Rat's Nest, Endgame, Megumi · CFP : Starlight, Rod's, Dudley & Daughters · Stanton Gateway", G("#5a4a44", "#1a1210", None, None, {"n": 30, "color": "#ffb070"}, 67))

N = "Nyx"
body(N, None, "Nyx I", "Nyx I", "Monde sans noyau", "Aride", "Maigre",
     "En cours d'introduction (terraformation)", "Aucune connue", "Système découvert en 2582 par Carla Larry ; planète vidée par Gold Horizon", "Genesis Terraforming (depuis 2954)",
     [("combat", "Raids vanduul en hausse depuis la terraformation"), ("explo", "Terraformation expérimentale")],
     "Sites de Genesis Terraforming", G("#a38a74", "#35271d", None, None, None, 71))
body(N, None, "Nyx II", "Nyx II", "Monde à haute pression", "Étouffant", "Nuages toxiques",
     "Aucune", "Aucune connue", "Jugé non terraformable", "Aucune",
     [("explo", "À observer de loin")], "—", G("#c8b56a", "#4a3d18", {"n": 10, "colors": ["#e0cf8a", "#8a7430"]}, "rgba(220,200,120,A)", None, 72))
body(N, None, "Nyx III", "Nyx III", "Géante de glace", "Glacial", "Irrespirable",
     "—", "—", "Ni air ni ressources", "Aucune",
     [("explo", "Aux confins du système")], "—", G("#8fb4e8", "#1d2f5a", {"n": 12, "colors": ["#b7d0f5", "#4b6fb0"]}, "rgba(150,190,255,A)", None, 73))
body(N, None, "Delamar", "Glaciem Ring", "Grand astéroïde", "Vide spatial", "Aucune (habitat pressurisé)",
     "—", "—", "Levski fondée en 2618 par la People's Alliance", "People's Alliance",
     [("achat", "Teach's : seul vendeur de vaisseaux de Nyx"), ("service", "Raffinerie, hôpital Mercy, Grand Barter, Café Musain"), ("combat", "Missions InterSec et Recco Battaglia")],
     "Levski", G("#3a3a44", "#121218", None, None, {"n": 40, "color": "#ffc882"}, 74))
body(N, None, "Glaciem Ring", "Ceinture intérieure (~8 UA)", "Ceinture dense", "Vide spatial, nébuleuse sombre voisine", "Aucune",
     "—", "—", "Ancienne zone minière de QV", "People's Alliance (de fait)",
     [("minage", "Torite, glace, fer, bexalite, borase, or, lindinium, tungstène"), ("explo", "Centaines de stations QV abandonnées et d'épaves"), ("refuge", "La nébuleuse cache tout")],
     "Stations QV abandonnées · épaves", G("#4a5070", "#12141f", None, "rgba(140,160,230,A)", None, 75))
body(N, None, "Keeger Belt", "Ceinture extérieure", "Ceinture", "Vide spatial", "Aucune",
     "—", "Valakkar des glaces (stations QV Breaker)", "Bastions criminels supposés", "Criminels · QV Services",
     [("minage", "Torite, aluminium, corindon, bexalite, borase, or, lindinium, tungstène"), ("chasse", "Valakkar des glaces"), ("combat", "Repaires criminels, Vanduul")],
     "Stations QV Breaker", G("#556070", "#141a22", None, None, None, 76))

systems = [
  dict(name="Stanton", star="Étoile de type G, semblable au Soleil", disc="2851 · Toshi Aaron", status="Système corporatiste de l'UEE : planètes vendues aux enchères à quatre mégacorporations", law="Loi de l'UEE, police privée", factions="Hurston Dynamics · Crusader Industries · ArcCorp · microTech", note="Point de départ, le plus sûr. Stanton System Conference annuelle entre les quatre patrons."),
  dict(name="Pyro", star="Étoile éruptive de type K, ~11,3 milliards d'années", disc="2469 · Raj MacEwan (anomalie) ; 2493 · Pyrotechnic Amalgamated", status="Hors UEE, abandonné en 2563", law="Aucune loi, aucun CrimeStat", factions="XenoThreat · Rough & Ready · Citizens for Prosperity · Headhunters · Frontier Fighters · 73R Vipers · Fire Rats", note="La réputation remplace la loi. Radiations lors des éruptions."),
  dict(name="Nyx", star="Naine de type F · système de 11,2 UA", disc="2582 · Carla Larry", status="Non revendiqué par l'UEE", law="Contrôle de fait de la People's Alliance", factions="People's Alliance · InterSec · QV Services · Genesis Terraforming · Vanduul (frontière)", note="Nébuleuses, ceintures denses, raids vanduul. Saut depuis Stanton provisoire."),
]

data = dict(tags={k: {"label": v[0], "color": v[1]} for k, v in TAGS.items()}, systems=systems, bodies=B,
            peoples_h=[dict(n=a, t=b, d=c) for a, b, c in peoples_h], peoples_a=[dict(n=a, t=b, d=c) for a, b, c in peoples_a],
            factions=[dict(g=g, items=[dict(n=n, d=d) for n, d in it]) for g, it in factions],
            elsewhere=[dict(n=n, d=d) for n, d in elsewhere])
json.dump(data, open('bestiaire.json', 'w', encoding='utf-8'), ensure_ascii=False)

# ---------- markdown for project ----------
md = ["# Bestiaire du Verse — systèmes, planètes, peuples, factions", "",
      "> Base de référence du projet. État : Alpha 4.10.1 · année en jeu 2956 · 28/09/2026.",
      "> Hiérarchie : système → planète / lune → climat, atmosphère, flore, faune → découverte → appartenance → utilité → à voir.",
      "> Prix de vente indicatifs (sept. 2026), à revérifier après chaque patch.", ""]
for sy in systems:
    md += [f"## {sy['name']}", "", f"- **Étoile** : {sy['star']}", f"- **Découverte** : {sy['disc']}", f"- **Statut** : {sy['status']}", f"- **Loi** : {sy['law']}", f"- **Factions** : {sy['factions']}", f"- {sy['note']}", ""]
    for b in [x for x in B if x['sys'] == sy['name']]:
        lvl = "####" if b['parent'] else "###"
        md += [f"{lvl} {b['name']} ({b['desig']})", "",
               f"- **Type** : {b['kind']}", f"- **Climat** : {b['climat']}", f"- **Atmosphère** : {b['atmo']}",
               f"- **Flore** : {b['flore']}", f"- **Faune** : {b['faune']}", f"- **Découverte** : {b['decouverte']}",
               f"- **Appartenance** : {b['faction']}",
               "- **Utilité** : " + " ; ".join(f"[{TAGS[u['tag']][0]}] {u['note']}" for u in b['util']),
               f"- **À voir** : {b['poi']}", ""]
md += ["## Index par utilité", ""]
for k, (lab, _) in TAGS.items():
    items = [f"{b['name']} ({u['note']})" for b in B for u in b['util'] if u['tag'] == k]
    md += [f"- **{lab}** : " + " · ".join(items)]
md += ["", "## Peuples", ""]
for a, b, c in peoples_h + peoples_a: md += [f"- **{a}** ({b}) : {c}"]
md += ["", "## Factions", ""]
for g, it in factions:
    md += [f"### {g}"] + [f"- **{n}** : {d}" for n, d in it] + [""]
md += ["## Ailleurs", ""] + [f"- **{n}** : {d}" for n, d in elsewhere]
md += ["", "## Sources", "- starcitizen.tools (systèmes, lunes, faune : Valakkar, Kopion, Stormwal, Boreal Stalker, Xiphopod, Yormandi ; Contested Zones)",
       "- scminer.rocks (minerais par lieu, 4.10.1) · timesaver.gg (prix RMC, 02/09/2026)"]
open('sc-bestiaire.md', 'w', encoding='utf-8').write("\n".join(md))
print(len(B), "bodies")
