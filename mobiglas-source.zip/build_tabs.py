import re, json, html as H

J = open('journal-2956.html', encoding='utf-8').read().split('\n')
B = open('bestiaire.html', encoding='utf-8').read()
data = json.load(open('bestiaire.json', encoding='utf-8'))
L = lambda a, b: '\n'.join(J[a-1:b])  # 1-indexed inclusive
esc = H.escape

head_style = L(5, 184)  # <style> ... </style>
title_and_fonts = '\n'.join(J[0:4])
hud = L(187, 195)
hero = L(196, 206)
lede = L(208, 214)
empire = L(216, 241); stanton = L(243, 265); il1 = L(267, 270); hurston = L(272, 300)
lorville = L(302, 329); il2 = L(331, 334)
marg_cols1 = L(339, 365); seeker_cols = L(366, 386); dort_text = L(387, 390); fleet = L(391, 396)
il3 = L(399, 402); ombres = L(404, 426); audela = L(428, 443); il4 = L(445, 448)
lexique = L(450, 555); footer = L(556, 560)
script = L(563, 753)

# ---- split marginal: text vs aside
m = re.search(r'(<div class="text" data-read>.*?</div>)\s*(<aside class="data">.*?</aside>)', marg_cols1, re.S)
marg_text, exo_fiche = m.group(1), m.group(2)

# ---- HUD: add tabs
tabs = [("journal", "Journal"), ("carte", "Carte"), ("hangar", "Hangar"), ("contacts", "Contacts"), ("codex", "Codex"), ("spectrum", "Spectrum")]
tabnav = '  <nav class="tabs" role="tablist" aria-label="Sections du journal">\n' + '\n'.join(
    f'    <a class="tab" role="tab" href="#{k}" data-tab="{k}" aria-selected="false">{v}</a>' for k, v in tabs) + '\n  </nav>'
hud = hud.replace('<a class="btn" href="#lexique">Lexique</a>', '')
header = '  <div class="topbar">\n' + hud + '\n' + tabnav + '\n  </div>'

def panel(k, inner, label):
    return f'  <section class="tab-panel" id="tab-{k}" role="tabpanel" aria-label="{label}" hidden>\n{inner}\n  </section>'

# ---- JOURNAL
journal = f'''{hero}
{lede}
  <div class="tl-head"><span class="tl-mark">Passé</span><span class="tl-line"></span><span class="tl-note">Figé · ce qu'Exo a vécu avant le retour</span></div>
  <section class="chapter" id="passe">
    <div class="log"><span class="n">Origines</span><span class="loc">Lorville · 2921 → 2956</span><span>Mémoire de Seeker</span></div>
    {marg_text}
  </section>
  <div class="tl-head"><span class="tl-mark now">Présent</span><span class="tl-line"></span><span class="tl-note">Les sessions racontées, de la plus récente à la plus ancienne</span></div>
  <div id="entries" class="entries" aria-live="polite"><p class="empty-note">Aucune session racontée pour l'instant. À la fin d'une partie, dis « entrée de journal » à Seeker, puis colle le récit dans une conversation du projet : il apparaîtra ici.</p></div>
  <div class="tl-head"><span class="tl-mark">Cap</span><span class="tl-line"></span><span class="tl-note">Ce qu'Exo a décidé de viser. Il est le seul à l'écrire.</span></div>
  <div id="cap" class="cap"><p class="empty-note">Aucun cap déclaré.</p></div>'''

# ---- CARTE (bestiaire)
bstyle = re.search(r'<style>(.*?)</style>', B, re.S).group(1)
bbody = B[B.index('<div class="controls"'):B.index('<main id="out"></main>') + len('<main id="out"></main>')]
bscript = B[B.index('<script>') + len('<script>'):B.rindex('</script>')]
bscript = bscript.replace('document.getElementById("stats").textContent=', '(document.getElementById("stats")||{}).textContent=')
bscript = bscript.replace('if(!state.tags.size&&state.sys==="Tous"){', 'if(false){')

SKIP = (':root', '*', 'html', 'body', 'a{', 'a ', 'button', ':focus-visible', 'header.top', 'h1', '.lead', '.hier', 'footer', '.eyebrow', '.wrap')
def prefix_css(css, pre):
    out, i, n = [], 0, len(css)
    while i < n:
        j = css.find('{', i)
        if j < 0: break
        sel = css[i:j].strip()
        # find matching brace
        depth, k = 1, j + 1
        while k < n and depth:
            if css[k] == '{': depth += 1
            elif css[k] == '}': depth -= 1
            k += 1
        body = css[j + 1:k - 1]
        if sel.startswith('@media'):
            out.append(sel + '{' + prefix_css(body, pre) + '}')
        elif any(sel.startswith(s) for s in SKIP):
            pass
        else:
            sels = ','.join(pre + ' ' + s.strip() for s in sel.split(','))
            out.append(sels + '{' + body + '}')
        i = k
    return '\n'.join(out)
carte_css = prefix_css(bstyle, '#tab-carte')
carte = f'''  <div class="text"><h2>Carte</h2><p class="tab-intro">Figé · Chaque système, planète et lune : climat, atmosphère, faune, minerais, appartenance et usage en jeu. Cherche un mot ou filtre par usage.</p></div>
  <div class="carte-wrap">
{bbody}
  </div>'''

# ---- HANGAR
SHIPS = [
 dict(id="f7c", nom="F7C Hornet Mk II", maker="Anvil Aerospace", role="Chasseur civil", specs=[
   ("Équipage", "1"), ("Soute", "2 SCU (module central)"), ("Armes", "2 × S4 sur cardan"), ("Missiles", "2 racks S3 · 8 missiles S1"),
   ("Boucliers", "2 × S1"), ("Composants", "Centrales, refroidisseurs, quantique : S1"), ("Vitesse", "SCM 220 m/s · max 1 150 m/s"), ("Résistance", "Coque ~13 150 PV · bouclier ~6 300 PV")],
   evo=[("f7c-ball", "Tourelle boule F7C-M Mk II", "Remplace la boîte cargo : 2 armes S3 et un rack de missiles. On perd les 2 SCU.", "~115 330 aUEC · CenterMass (Area18, New Babbage), Cousin Crow's (Orison)"),
        ("f7c-nose", "Tourelle de nez S2", "Ajoute 2 armes S2 sous le nez.", "~20 250 aUEC · boutiques d'équipement (à vérifier)"),
        ("f7c-ad4b", "2 × AD4B (S4)", "Gatlings balistiques sur les ailes, conseillées pour le combat.", "Prix variable · voir UEX Corp"),
        ("f7c-mantis", "2 × GT-220 Mantis (S3)", "Gatlings pour la tourelle boule.", "Prix variable · voir UEX Corp")]),
 dict(id="vulture", nom="Vulture", maker="Drake Interplanetary · assuré à vie", role="Récupération solo", specs=[
   ("Équipage", "1"), ("Soute", "12 SCU + stockage interne des matériaux"), ("Outils", "Raclage de coque, fracture, désintégration"),
   ("Produits", "RMC (raclage) · Construction Materials (désintégration)"), ("Usage", "Contrats de salvage, épaves libres")],
   evo=[("vul-cinch", "Têtes Greycat Cinch", "Meilleur rendement en RMC, passes plus lentes.", "Boutiques de composants · voir UEX Corp"),
        ("vul-trawler", "Têtes Greycat Trawler", "Grande surface et rapidité, mais moins de RMC au total.", "Boutiques de composants · voir UEX Corp"),
        ("vul-abrade", "Têtes Greycat Abrade", "Polyvalentes, équilibrées.", "Boutiques de composants · voir UEX Corp")]),
 dict(id="corsair", nom="Corsair", maker="Drake Interplanetary", role="Fret · exploration · puissance de feu", specs=[
   ("Équipage", "1 à 4"), ("Soute", "72 SCU · conteneurs jusqu'à 32 SCU"), ("Armes", "2 × S5 + 4 × S4 sur cardan"), ("Tourelles", "1 télécommandée S4 · 2 habitées S2"),
   ("Missiles", "4 racks S3"), ("Composants", "Bouclier S3 · 2 centrales S2 · 2 refroidisseurs S2 · quantique S2"), ("Vitesse", "SCM 190 m/s · max 1 025 m/s"), ("À bord", "Rampe arrière (le Pulse y entre), ascenseur, 4 lits")],
   evo=[("cor-guns", "Armes S5 et S4", "Changer les canons d'origine selon l'usage (fret défensif ou combat).", "Configurer sur Erkul · acheter selon UEX Corp"),
        ("cor-shield", "Bouclier S3 de meilleure qualité", "Plus de tenue en fret à risque.", "À vérifier sur Erkul"),
        ("cor-qd", "Quantique S2 plus économe", "Utile avec le carburant plus cher de la 4.10.", "À vérifier sur Erkul")]),
 dict(id="pulse", nom="Pulse LX", maker="Mirai", role="Au sol", specs=[
   ("Type", "Moto antigrav"), ("Usage", "Avant-postes, canyons, épaves posées"), ("Transport", "Dans la soute du Corsair")], evo=[]),
]
hangar_cards = []
for s in SHIPS:
    specs = ''.join(f'<dt>{esc(a)}</dt><dd>{esc(b)}</dd>' for a, b in s["specs"])
    evo = ''.join(f'<li class="evo" data-evo="{e[0]}"><div class="evo-top"><span class="evo-name">{esc(e[1])}</span><span class="evo-status" data-status="possible">Possible</span></div><p>{esc(e[2])}</p><span class="evo-where">{esc(e[3])}</span><span class="evo-note"></span></li>' for e in s["evo"]) or '<li class="evo none">Aucune évolution connue.</li>'
    hangar_cards.append(f'''    <article class="shipcard" id="ship-{s["id"]}">
      <header><span class="mk">{esc(s["maker"])}</span><h3>{esc(s["nom"])}</h3><span class="tag">{esc(s["role"])}</span></header>
      <dl class="specs">{specs}</dl>
      <h4>Évolutions possibles</h4>
      <ul class="evos">{evo}</ul>
    </article>''')
hangar = f'''  <div class="text"><h2>Hangar</h2><p class="tab-intro">Caractéristiques figées · état des évolutions mis à jour au fil des sessions (installé, visé, possible).</p></div>
{dort_text}
{fleet}
  <div class="shipcards">
{chr(10).join(hangar_cards)}
  </div>
  <p class="small">Caractéristiques d'après starcitizen.tools et les guides 4.10.1. Prix indicatifs, à revérifier après chaque patch.</p>'''

# ---- DOSSIERS
known = [("Clovus Darneely", "Reclamation & Disposal · Lorville", "Celui qui payait les gamins au kilo de métal. Exo le connaît. Lui se souvient peut-être."),
         ("Miles Eckhart", "Eckhart Security · MacIntyre & Victor's", "Recrute pour des contrats de légalité variable. Connu de réputation."),
         ("Constantine Hurston", "Hurston Dynamics", "Jeune Hurston chargé de sous-traiter des contrats. Un nom sur les avis de mission."),
         ("Gavin E. Hurston", "PDG de Hurston Dynamics", "Celui dont le nom est en bas de la dette. Jamais vu.")]
known_html = ''.join(f'<article class="dossier known"><span class="mk">{esc(b)}</span><h4>{esc(a)}</h4><p>{esc(c)}</p></article>' for a, b, c in known)
dossiers = f'''  <div class="text"><h2>Contacts</h2><p class="tab-intro">Exo, Seeker, et ceux qui croisent leur route.</p></div>
  <section class="chapter" id="dos-exo">
    <div class="log"><span class="n">Dossier</span><span class="loc">Exo</span><span>Fiche figée</span></div>
    <div class="cols">
      <div class="text"><h2 class="h3">Exo</h2><p>Né en 2921 dans le Workers District de Lorville. Marginal, pilote indépendant, ni hors-la-loi ni respectueux des règles. Son histoire complète est dans l'onglet Journal, partie Passé.</p></div>
      {exo_fiche}
    </div>
  </section>
  <section class="chapter" id="dos-seeker">
    <div class="log"><span class="n">Dossier</span><span class="loc">Seeker</span><span>IA de bord · fiche figée</span></div>
{seeker_cols}
  </section>
  <section class="chapter" id="dos-known">
    <div class="log"><span class="n">Contacts</span><span class="loc">Connus de réputation</span><span>Lorville</span></div>
    <div class="dossiers">{known_html}</div>
  </section>
  <section class="chapter" id="dos-met">
    <div class="log"><span class="n">Contacts</span><span class="loc">Rencontres</span><span>Ajoutées au fil des sessions</span></div>
    <div id="met" class="dossiers"><p class="empty-note">Personne de nouveau pour l'instant.</p></div>
  </section>'''

# ---- LIFE FORMS
FAUNA = [
 ("Kopion", "Prédateur · danger élevé en meute", "Savanes de Hurston · forêts et toundra de microTech · cavernes de Bloom (Pyro) · versions irradiées dans les installations Onyx",
  "Prédateur agile qui chasse en meutes de 10 à 14, plus rapide qu'un humain qui sprinte. Ses cornes mêlent os et nanomatériaux de carbone naturels : une fois traitées, elles aident à la régénération osseuse, mieux que les produits de laboratoire. Elles se revendent bien."),
 ("Valakkar", "Ver géant · danger extrême", "Natif de Leir III · Daymar (Stanton) · Monox (espèce invasive) · Pyro I (irradiés) · variante des glaces près des stations QV Breaker (Nyx)",
  "Juvénile d'environ 5 m, adulte d'environ 15 m, apex jusqu'à 300 m. Il attaque les installations au point d'empêcher toute colonie permanente sur Leir III. On récupère ses dents et des formations semblables à des perles, au cœur des expériences d'ASD sur Pyro I."),
 ("Stormwal", "Géant des nuages · pacifique", "Atmosphère de Crusader",
  "Surnommé la « baleine du ciel », jusqu'à 100 m de long, rayé de rose pâle ou de gris-bleu. Ses nageoires captent les champs électriques, et des vessies d'hélium et d'hydrogène règlent son altitude. Il se nourrit d'aéroplancton et de kiami. Des affiches de protection laissent penser que l'espèce est menacée."),
 ("Boreal Stalker", "Prédateur de synthèse · dangereux", "Toundra de microTech",
  "Créé par les généticiens de microTech pour servir de super-prédateur à l'écosystème artificiel de la planète. Il n'existe nulle part ailleurs."),
 ("Xiphopod", "Invertébré · nuisible", "Natif de Leir I · invasif sur Hurston",
  "Surnommé « crabe aveugle d'Oni ». Il flotte en transformant l'air en mélange d'hydrogène et d'hélium dans son corps creux, et ne dépasse pas 300 grammes. Il prolifère sur les déchets des villes de Hurston, sans prédateur, et pond jusqu'à mille œufs par cycle. L'UEE en interdit le commerce."),
 ("Yormandi", "Prédateur des grottes · dangereux", "Réseaux de grottes sous les installations Onyx d'ASD",
  "Découvert pendant les fouilles d'ASD. Il a des points faibles qu'on peut briser. Ses yeux contiennent des anticorps très recherchés, et sa langue est un mets prisé des gourmets de l'Empire."),
 ("Marok", "Petite faune · inoffensif", "Mondes verts et terraformés",
  "Souvent introduit sur les mondes terraformés. Son gésier contient une pierre cristalline aux propriétés conductrices, recherchée pour fabriquer des puces électroniques."),
 ("Quasi Grazer", "Herbivore · inoffensif", "Natif des plaines de Quasi, sur Terra · présent sur la plupart des mondes terraformés",
  "L'un des animaux de base utilisés pour peupler les planètes terraformées de l'UEE."),
]
FLORA = [
 ("Aéroplancton et kiami", "Crusader", "Micro-organismes et matière végétale en suspension dans l'atmosphère de la géante gazeuse. Nourriture des Stormwal."),
 ("Prota", "Arial (lune de Hurston)", "Ressource récoltable sur une lune brûlante et toxique."),
 ("Savane dégradée", "Hurston", "Ancien biome dominant, presque entièrement remplacé par les zones industrielles. Seule une végétation coriace survit."),
 ("Forêts et toundra enneigées", "microTech", "Végétation froide autour de New Babbage, territoire des Kopion et du Boreal Stalker."),
 ("Flore de fournaise", "Pyro I", "Plantes résistantes à la chaleur, aux vents et à la foudre d'un monde extrême."),
]
life_html = ''.join(f'<article class="dossier lifeform"><span class="mk">{esc(c)}</span><h4>{esc(n)}</h4><span class="where">{esc(w)}</span><p>{esc(d)}</p></article>' for n, c, w, d in FAUNA)
flora_html = ''.join(f'<article class="dossier lifeform"><span class="mk">Flore · {esc(w)}</span><h4>{esc(n)}</h4><p>{esc(d)}</p></article>' for n, w, d in FLORA)

# ---- CODEX (lore + peoples + factions + lexique)
def people_cards(lst):
    return ''.join(f'<div class="ship"><span class="mk">{esc(p["t"])}</span><span class="nm">{esc(p["n"])}</span><p>{esc(p["d"])}</p></div>' for p in lst)
fac = ''.join('<div class="lex-group"><h3>' + esc(g["g"]) + '</h3><dl>' + ''.join(f'<div><dt>{esc(i["n"])}</dt><dd>{esc(i["d"])}</dd></div>' for i in g["items"]) + '</dl></div>' for g in data["factions"])
codex_nav = '<nav class="codex-nav" aria-label="Codex">' + ''.join(f'<a href="#{a}">{b}</a>' for a, b in [("empire", "Empire"), ("stanton", "Stanton"), ("hurston", "Hurston"), ("lorville", "Lorville"), ("ombres", "Ombres"), ("au-dela", "Au-delà"), ("peuples", "Peuples"), ("formes-de-vie", "Formes de vie"), ("factions", "Factions"), ("lexique", "Lexique")]) + '</nav>'
codex = f'''  <div class="text"><h2>Codex</h2><p class="tab-intro">Figé · L'univers de 2956 : histoire, Stanton, Hurston, Lorville, peuples, formes de vie, factions et lexique.</p></div>
  {codex_nav}
{empire}
{stanton}
{hurston}
{lorville}
{ombres}
{audela}
  <section class="chapter" id="peuples">
    <div class="log"><span class="n">Codex</span><span class="loc">Peuples et cultures</span><span>Humains · espèces connues</span></div>
    <div class="text"><h2>Peuples et cultures</h2></div>
    <h3 class="h3 powers-title">Humains</h3>
    <div class="fleet powers">{people_cards(data["peoples_h"])}</div>
    <h3 class="h3 powers-title">Autres espèces</h3>
    <div class="fleet powers">{people_cards(data["peoples_a"])}</div>
  </section>
  <section class="chapter" id="formes-de-vie">
    <div class="log"><span class="n">Codex</span><span class="loc">Formes de vie</span><span>Bestiaire · faune et flore</span></div>
    <div class="text"><h2>Formes de vie</h2><p class="tab-intro">Les animaux et plantes connus du Verse. Les peuples intelligents sont dans la section Peuples.</p></div>
    <h3 class="h3 powers-title">Faune</h3>
    <div class="dossiers">{life_html}</div>
    <h3 class="h3 powers-title">Flore</h3>
    <div class="dossiers">{flora_html}</div>
  </section>
  <section class="chapter" id="factions">
    <div class="log"><span class="n">Codex</span><span class="loc">Factions</span><span>Qui tient quoi en 2956</span></div>
    <div class="text"><h2>Factions</h2></div>
    <div class="lex-groups">{fac}</div>
  </section>
{lexique}'''
codex = codex.replace('<div class="log"><span class="n">Entrée 1</span>', '<div class="log"><span class="n">Codex</span>')
for n in range(2, 8):
    codex = codex.replace(f'<span class="n">Entrée {n}</span>', '<span class="n">Codex</span>')

# ---- SPECTRUM
spectrum = f'''  <div class="text"><h2>Spectrum</h2><p class="tab-intro">Les nouvelles de l'univers, édition par édition. Les plus récentes en haut.</p></div>
  <div id="editions" class="editions"><p class="empty-note">Aucune édition reçue pour l'instant.</p></div>
  <div class="tl-head"><span class="tl-mark">Archives</span><span class="tl-line"></span><span class="tl-note">Figé · annonces captées pendant le retour à Lorville</span></div>
{il1}
{il2}
{il3}
{il4}'''

body = '<div class="wrap">\n' + header + '\n' + '\n'.join([
    panel("journal", journal, "Journal"), panel("carte", carte, "Carte"), panel("hangar", hangar, "Hangar"),
    panel("contacts", dossiers, "Contacts"), panel("codex", codex, "Codex"), panel("spectrum", spectrum, "Spectrum")]) + '\n' + footer + '\n</div>'

# ---- scripts patches
script = script.replace('document.querySelectorAll(".chapter:not(.lexique) .text, .lede, .interlude, .chapter .ship p").forEach(scope=>{',
                        'const SEL=".chapter:not(.lexique) .text, .lede, .interlude, .chapter .ship p, .entry, .dossier, .edition, .capitem";\n    function linkScope(scope){if(scope.dataset.linked)return;scope.dataset.linked="1";')
script = script.replace('    });\n    pop.id="termpop";', '    }\n    window.__linkTerms=root=>root.querySelectorAll(SEL).forEach(linkScope);\n    document.querySelectorAll(SEL).forEach(linkScope);\n    pop.id="termpop";', 1)
assert 'window.__linkTerms' in script
script = script.replace('function drawAll(){canvases.forEach(draw);}', 'function drawAll(){canvases.forEach(draw);}\n  window.__redraw=drawAll;', 1)
assert 'window.__redraw' in script
script = script.replace('start([...document.querySelectorAll("[data-read]")])', 'start([...document.querySelector(".tab-panel:not([hidden])").querySelectorAll("[data-read], .entry")])')

tabjs = r'''
<script>
(function(){
  const TABS=["journal","carte","hangar","contacts","codex","spectrum"];
  const panels={};TABS.forEach(t=>panels[t]=document.getElementById("tab-"+t));
  const links=[...document.querySelectorAll(".tab")];
  function tabFor(id){if(TABS.includes(id))return id;const el=id&&document.getElementById(id);if(!el)return null;const p=el.closest(".tab-panel");return p?p.id.slice(4):null;}
  function show(t,anchor){TABS.forEach(k=>{panels[k].hidden=(k!==t);});links.forEach(a=>a.setAttribute("aria-selected",a.dataset.tab===t?"true":"false"));
    try{localStorage.setItem("exo-tab",t);}catch(e){}
    if(window.__redraw)window.__redraw();
    requestAnimationFrame(()=>{if(anchor&&anchor!==t){const el=document.getElementById(anchor);if(el)el.scrollIntoView({block:"start"});}else window.scrollTo(0,0);});}
  function route(){const h=decodeURIComponent(location.hash.slice(1));const t=tabFor(h);if(t)show(t,h);}
  window.addEventListener("hashchange",route);
  let start=null;try{start=localStorage.getItem("exo-tab");}catch(e){}
  const h=location.hash.slice(1);
  if(h&&tabFor(h))route();else show(TABS.includes(start)?start:"journal");
})();
</script>
<script>
(async function(){
  const $=id=>document.getElementById(id);
  const el=(tag,cls,txt)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e;};
  const link=root=>{if(window.__linkTerms)window.__linkTerms(root);};
  const db=(window.claude&&typeof window.claude.use==="function")?await window.claude.use("db").catch(()=>null):null;
  if(!db){document.querySelectorAll(".empty-note").forEach(p=>{p.textContent+=" (Les données s'affichent quand la page est ouverte dans claude.ai.)";});return;}
  const fail=box=>e=>{const b=$(box);if(b&&!b.querySelector(".entry,.capitem,.dossier,.edition"))b.innerHTML='<p class="empty-note">Impossible de charger ces données pour le moment.</p>';};
  // JOURNAL
  db.collection("journal").orderBy("ordre","desc").onSnapshot(s=>{const box=$("entries");if(s.empty)return;box.textContent="";
    s.docs.forEach(d=>{const v=d.data()||{};const a=el("article","entry");
      const lg=el("div","log");lg.append(el("span","n",v.numero||"Entrée"),el("span","loc",v.lieu||""),el("span",null,v.date||""));a.append(lg);
      a.append(el("h3","entry-title",v.titre||""));
      if(v.seeker){const q=el("p","voice-line",v.seeker);q.append(el("span",null,"Seeker, IA de bord"));a.append(q);}
      (Array.isArray(v.paragraphes)?v.paragraphes:[]).forEach(t=>a.append(el("p",null,t)));
      box.append(a);});link(box);},fail("entries"));
  // CAP
  db.collection("cap").orderBy("ordre","asc").onSnapshot(s=>{const box=$("cap");if(s.empty)return;box.textContent="";
    s.docs.forEach(d=>{const v=d.data()||{};const it=el("div","capitem"+(v.statut==="atteint"?" done":""));
      const top=el("div","cap-top");top.append(el("span","cap-title",v.titre||""),el("span","cap-status",v.statut||"en cours"));it.append(top);
      if(v.detail)it.append(el("p",null,v.detail));box.append(it);});link(box);},fail("cap"));
  // HANGAR
  const LABEL={installe:"Installé",vise:"Visé",possible:"Possible"};
  db.collection("hangar").onSnapshot(s=>{document.querySelectorAll(".evo[data-evo]").forEach(li=>{const st=li.querySelector(".evo-status");st.dataset.status="possible";st.textContent=LABEL.possible;li.querySelector(".evo-note").textContent="";});
    s.docs.forEach(d=>{const v=d.data()||{};const li=document.querySelector('.evo[data-evo="'+CSS.escape(d.id)+'"]');if(!li)return;const k=LABEL[v.statut]?v.statut:"possible";
      const st=li.querySelector(".evo-status");st.dataset.status=k;st.textContent=LABEL[k];li.querySelector(".evo-note").textContent=v.note||"";});},()=>{});
  // DOSSIERS
  db.collection("contacts").orderBy("ordre","asc").onSnapshot(s=>{const box=$("met");if(s.empty)return;box.textContent="";
    s.docs.forEach(d=>{const v=d.data()||{};const a=el("article","dossier");a.append(el("span","mk",[v.role,v.lieu].filter(Boolean).join(" · ")),el("h4",null,v.nom||""));
      if(v.relation)a.append(el("p","rel",v.relation));if(v.notes)a.append(el("p",null,v.notes));if(v.premiere)a.append(el("span","first","Première rencontre : "+v.premiere));box.append(a);});link(box);},fail("met"));
  // SPECTRUM
  db.collection("spectrum").orderBy("ordre","desc").onSnapshot(s=>{const box=$("editions");if(s.empty)return;box.textContent="";
    s.docs.forEach(d=>{const v=d.data()||{};const a=el("article","edition");a.append(el("span","il-tag","Spectrum · "+(v.edition||"")));
      const ul=el("ul");(Array.isArray(v.titres)?v.titres:[]).forEach(t=>{const li=el("li");li.append(el("span",null,t.rubrique||""),document.createTextNode(t.titre||""));ul.append(li);});a.append(ul);
      if(v.annonce){const p=el("p","ann",v.annonce);a.append(p);}box.append(a);});link(box);},fail("editions"));
})();
</script>'''

extra_css = '''
.topbar{position:sticky;top:env(safe-area-inset-top,0px);z-index:6;margin-inline:-16px;padding-inline:16px;background:color-mix(in srgb,var(--void) 92%,transparent);backdrop-filter:blur(6px);border-bottom:1px solid var(--line)}
.topbar .hud{position:static;margin:0;padding-inline:0;border-bottom:0;background:none;backdrop-filter:none}
.tabs{display:flex;gap:2px;overflow-x:auto;scrollbar-width:none;margin-top:-2px}
.tabs::-webkit-scrollbar{display:none}
.tab{flex:0 0 auto;font-family:var(--mono);font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);text-decoration:none;padding:10px 14px;border-bottom:2px solid transparent}
.tab:hover{color:var(--star)}
.tab[aria-selected="true"]{color:var(--amber);border-bottom-color:var(--amber)}
.tab-panel{padding-top:8px}
.tab-panel > .text:first-child{margin-top:32px}
.tab-intro{font-family:var(--mono);font-size:12px;letter-spacing:.04em;color:var(--dim);margin:6px 0 0}
.tl-head{display:flex;align-items:center;gap:14px;margin:72px 0 0;flex-wrap:wrap}
.tl-mark{font-family:var(--display);font-size:clamp(34px,6vw,56px);text-transform:uppercase;line-height:1;color:var(--star)}
.tl-mark.now{color:var(--amber)}
.tl-line{flex:1 1 40px;height:1px;background:var(--line);min-width:40px}
.tl-note{font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--faint)}
.empty-note{color:var(--dim);font-style:italic;border:1px dashed var(--line);padding:16px 18px;margin:20px 0 0;max-width:72ch}
.entries{display:grid;gap:28px;margin-top:24px}
.entry{display:grid;gap:10px;max-width:72ch;border-left:2px solid var(--line);padding-left:20px}
.entry p{margin:0}
.entry-title{margin:0;font-family:var(--display);font-weight:500;text-transform:uppercase;font-size:clamp(28px,4vw,40px);line-height:1}
.cap{display:grid;gap:10px;margin-top:20px;grid-template-columns:repeat(auto-fill,minmax(min(300px,100%),1fr))}
.capitem{border:1px solid var(--line);background:var(--panel);padding:14px 16px;display:grid;gap:6px;align-content:start}
.capitem p{margin:0;font-size:15px;color:var(--dim)}
.cap-top{display:flex;justify-content:space-between;gap:10px;align-items:baseline}
.cap-title{font-family:var(--display);font-size:22px;text-transform:uppercase;line-height:1}
.cap-status{font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--amber);white-space:nowrap}
.capitem.done{opacity:.7}.capitem.done .cap-status{color:var(--hud)}
.carte-wrap{margin-top:20px}
.shipcards{display:grid;gap:14px;margin-top:28px;grid-template-columns:repeat(auto-fill,minmax(min(440px,100%),1fr));align-items:start}
.shipcard{border:1px solid var(--line);background:var(--hull);padding:16px 18px;display:grid;gap:12px}
.shipcard header{display:grid;gap:2px}
.shipcard .mk,.dossier .mk{font-family:var(--mono);font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--faint)}
.shipcard h3{margin:0;font-family:var(--display);font-weight:500;font-size:34px;text-transform:uppercase;line-height:1}
.shipcard .tag{font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--amber)}
.shipcard h4{margin:0;font-family:var(--mono);font-weight:400;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--hud);border-top:1px solid var(--line);padding-top:10px}
.specs{margin:0;display:grid;grid-template-columns:auto minmax(0,1fr);gap:5px 14px;font-size:14.5px;line-height:1.4}
.specs dt{font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--faint);padding-top:3px}
.specs dd{margin:0}
.evos{list-style:none;margin:0;padding:0;display:grid;gap:8px}
.evo{border:1px solid var(--line);padding:10px 12px;display:grid;gap:4px}
.evo.none{color:var(--faint);font-style:italic}
.evo p{margin:0;font-size:14px;color:var(--dim);line-height:1.45}
.evo-top{display:flex;justify-content:space-between;gap:10px;align-items:baseline}
.evo-name{font-size:16px}
.evo-status{font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase;padding:2px 7px;border:1px solid var(--line);color:var(--faint);white-space:nowrap}
.evo-status[data-status="vise"]{color:var(--amber);border-color:var(--amber)}
.evo-status[data-status="installe"]{color:var(--void);background:var(--hud);border-color:var(--hud)}
.evo-where{font-family:var(--mono);font-size:10.5px;color:var(--faint)}
.evo-note{font-size:13.5px;color:var(--amber);font-style:italic}
.evo-note:empty{display:none}
.dossiers{display:grid;gap:12px;grid-template-columns:repeat(auto-fill,minmax(min(280px,100%),1fr))}
.dossier{border:1px solid var(--line);background:var(--hull);padding:14px 16px;display:grid;gap:6px;align-content:start}
.dossier h4{margin:0;font-family:var(--display);font-weight:500;font-size:26px;text-transform:uppercase;line-height:1}
.dossier p{margin:0;font-size:14.5px;color:var(--dim);line-height:1.5}
.dossier .rel{color:var(--star);font-style:italic}
.dossier .first{font-family:var(--mono);font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--faint)}
.dossier.known{background:var(--panel)}
.lifeform .where{font-family:var(--mono);font-size:10.5px;color:var(--hud);line-height:1.5}
.codex-nav{display:flex;flex-wrap:wrap;gap:6px;margin-top:16px}
.codex-nav a{font-family:var(--mono);font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--star);text-decoration:none;border:1px solid var(--line);padding:6px 10px}
.codex-nav a:hover{border-color:var(--hud);color:var(--hud)}
.editions{display:grid;gap:14px;margin-top:20px}
.edition{border:1px solid var(--line);background:var(--panel);padding:14px 18px;display:grid;gap:8px;max-width:760px}
.edition .il-tag{font-family:var(--mono);font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--amber)}
.edition ul{list-style:none;margin:0;padding:0;display:grid;gap:8px}
.edition li{font-size:16px;line-height:1.4}
.edition li span{display:block;font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--faint)}
.edition .ann{margin:0;font-style:italic;color:var(--dim);border-top:1px solid var(--line);padding-top:8px}
section.chapter,.tab-panel .chapter{scroll-margin-top:110px}
.lex-group > dl > div{scroll-margin-top:120px}
#tab-carte .group{font-family:var(--body);font-weight:400;text-transform:none;letter-spacing:normal;font-size:16px;margin:0}
#tab-carte .group + .group{margin-top:8px}
h3.powers-title{font-family:var(--display);font-weight:500;text-transform:uppercase;font-size:28px;letter-spacing:.03em;margin:18px 0 0}
'''
style = head_style.replace('</style>', extra_css + '\n/* carte (bestiaire) */\n' + carte_css + '\n</style>')

out = title_and_fonts + '\n' + style + '\n\n' + body + '\n\n' + script + '\n<script>\n' + bscript + '\n</script>' + tabjs + '\n'
open('journal-tabs.html', 'w', encoding='utf-8').write(out)
print(len(out))
