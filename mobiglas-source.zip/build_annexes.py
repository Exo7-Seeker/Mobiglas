import json, html, re

P = 'journal-2956.html'
s = open(P, encoding='utf-8').read()

# ---------- 1. text fixes ----------
s = s.replace(
    "<p>Il y a des siècles, l'Empire était ruiné. Pour payer ses dettes, il a fait quelque chose d'impensable : il a vendu un système entier. Quatre planètes, quatre acheteurs.</p>",
    "<p>En 2851, un navigateur nommé Toshi Aaron trouve un point de saut vers une étoile jaune, semblable au Soleil. Il revend les coordonnées à l'Empire, qui expulse aussitôt les prospecteurs déjà installés. Puis le Sénat fait quelque chose d'inédit : au lieu de vendre des parcelles, il met aux enchères des planètes entières. Quatre mégacorporations s'affrontent, des milliers de milliards de crédits changent de main. Stanton devient le seul système de l'Empire où des mondes appartiennent à des entreprises.</p>")
s = s.replace("Pyro · naine rouge éruptive", "Pyro · étoile éruptive de type K")
s = s.replace("Pyro</em> tourne autour d'une étoile malade qui crache du feu. Une compagnie minière l'a vidé puis abandonné,",
              "Pyro</em> tourne autour d'une vieille étoile malade, onze milliards d'années, qui crache du feu. Pyrotechnic Amalgamated l'a exploité à partir de 2493, puis a fait faillite en 2563, ruinée par les éruptions. Elle est partie")

# ---------- 2. remove chapter 6 (keep interlude before it) ----------
a = s.index('  <!-- 6 UNE JOURNEE -->')
b = s.index('  </section>', a) + len('  </section>')
s = s[:a] + '%%ANNEXES%%' + s[b:]

# remove carnet js
a = s.index('  /* ---------- carnet ---------- */')
b = s.index('  /* ---------- voice narration ---------- */')
s = s[:a] + s[b:]

# footer text
s = s.replace("Fin de l'entrée. <b>Moteurs au ralenti.</b>", "Fin du journal. <b>Moteurs au ralenti.</b>")

# ---------- 3. data ----------
def body(name, desig, kind, climat, atmo, place, mood, planet):
    return dict(name=name, desig=desig, kind=kind, climat=climat, atmo=atmo, place=place, mood=mood, planet=planet)

G = lambda a, b, bands=None, atmo=None, lights=None, seed=1: dict(base=[a, b], bands=bands, atmo=atmo, lights=lights, seed=seed)

stanton = [
  ("Hurston", "Stanton I · Hurston Dynamics", G("#b89a78", "#4e3a2c", {"n": 14, "colors": ["#8c6f55", "#d1b590", "#6d5a48"]}, "rgba(230,180,120,A)", None, 5), [
    body("Hurston", "Stanton I", "Planète tellurique", "Ancienne savane, très dégradée", "Lourde, polluée par l'industrie", "Lorville, mines, usines d'armement", "Ciel orange, air gris, sirènes de fin de poste. Ici, on naît avec la dette de ses parents.", None),
    body("Arial", "Lune", "Lune brûlante", "78 à 171 °C", "Azote, toxique, brume de chaleur", "Avant-postes miniers HDMS, bases hors-la-loi", "Le sol ondule sous la chaleur. Personne n'y reste plus longtemps que son contrat.", G("#d9a06a", "#5a2e1a", None, "rgba(255,170,110,A)", None, 21)),
    body("Aberdeen", "Lune", "Lune infernale", "170 à 237 °C", "Dioxyde de soufre, ciel jaune", "Prison de Klescher", "Il y avait des prairies. On murmure que Hurston y a testé ses ogives antimatière.", G("#e4d06a", "#6b5a1c", {"n": 8, "colors": ["#f3e08a", "#a38f2c"]}, "rgba(240,220,110,A)", None, 22)),
    body("Magda", "Lune", "Lune rocheuse", "+5 à −80 °C", "Azote, toxique", "Mines HDMS, rocher de Sketto", "Porte le nom de la patronne de Hurston Dynamics. Les touristes viennent photographier ses rochers.", G("#8fa1b3", "#2b3542", None, None, None, 23)),
    body("Ita", "Lune", "Lune froide", "−10 à −22 °C", "Azote, traces de méthane", "Mines, sites militaires The Shades et Thimblerig", "Un désert gris et silencieux, surveillé de loin.", G("#9e8f86", "#3a322e", None, None, None, 24)),
  ]),
  ("Crusader", "Stanton II · Crusader Industries", None, [
    body("Crusader", "Stanton II", "Géante gazeuse de faible masse", "Doux en haute altitude", "Respirable dans les couches hautes", "Orison, chantiers navals géants", "Des villes suspendues dans les nuages, construites par ceux qui fabriquent les plus grands vaisseaux de l'Empire.", G("#f0c7a4", "#8a5a64", {"n": 20, "colors": ["#fbe3cb", "#c7858a", "#e9b28f"]}, "rgba(255,190,160,A)", None, 6)),
    body("Cellin", "Lune", "Lune volcanique", "−41 à 0 °C", "Dioxyde de soufre très fin", "Plus de cent volcans endormis", "Ses geysers thermiques peuvent retourner un véhicule lourd. Les gaz rongent le matériel.", G("#b7b09a", "#3f3b30", None, None, None, 31)),
    body("Daymar", "Lune", "Lune désertique", "−40 à 78 °C", "Azote et méthane, toxique", "Hub Covalex Gundo abandonné, épave de l'UEES Flyssa", "Tempêtes de poussière orange. Chaque année, la Daymar Rally, course clandestine de 510 km.", G("#d79a62", "#5a3620", {"n": 6, "colors": ["#e8b27c", "#b3743f"]}, "rgba(240,170,110,A)", None, 32)),
    body("Yela", "Lune", "Lune de glace", "0 à −43 °C", "Oxygène mince, respirable (0,19 atm)", "Grim HEX et Jumptown dans sa ceinture", "Le seul corps de Stanton avec sa propre ceinture d'astéroïdes. Idéal pour disparaître.", G("#e8eef3", "#6f8392", None, "rgba(210,230,245,A)", None, 33)),
  ]),
  ("ArcCorp", "Stanton III · ArcCorp", None, [
    body("ArcCorp", "Stanton III", "Planète-ville", "Artificiel, pluies fréquentes", "Respirable, saturée", "Area18 ; quartiers résidentiels aux pôles, usines et sièges sociaux entre les deux", "Une seule ville sans fin, presque aussi dense que les mondes-usines xi'an.", G("#d98b57", "#5a2a1c", {"n": 10, "colors": ["#f0a76d", "#7a3a22"]}, None, {"n": 140, "color": "#ffd9a0"}, 7)),
    body("Lyria", "Lune", "Lune de glace", "−20 à −4 °C", "Oxygène très mince (0,09 atm)", "Mines Shubin", "Glace sale, cryogeysers et cryovolcans. La combinaison peut filtrer l'oxygène, pas les poumons.", G("#c9dbe6", "#4b5f70", None, "rgba(190,220,240,A)", None, 41)),
    body("Wala", "Lune", "Lune rocheuse", "−2 à −19 °C", "Trop fine pour respirer", "Mines, raffinerie, une ferme", "Étirée par les marées d'ArcCorp, couverte d'affleurements de géodes.", G("#a9a39a", "#3e3a35", None, None, None, 42)),
  ]),
  ("microTech", "Stanton IV · microTech", None, [
    body("microTech", "Stanton IV", "Planète tellurique", "Froid, couverture nuageuse dense", "Respirable, glaciale", "New Babbage sous son dôme", "Une terraformation ratée a créé le froid parfait pour les serveurs. microTech en a fait une force.", G("#eef4f8", "#5f7f9a", {"n": 10, "colors": ["#ffffff", "#a9c3d6"]}, "rgba(200,230,255,A)", None, 8)),
    body("Calliope", "Lune", "Lune de glace", "Jusqu'à −124 °C", "Riche en oxygène, rude", "Mines Shubin, laboratoires Rayari", "Vents violents, brouillard au ras du sol. On y voit rarement plus loin que son capot.", G("#dfe7ee", "#556675", None, "rgba(200,220,240,A)", None, 51)),
    body("Clio", "Lune", "Lune océanique gelée", "−32 à −77 °C", "Azote", "Océans liquides, icebergs", "Ciel rose et vert, eaux couleur jade. La plus belle lune du système, et la plus froide à contempler.", G("#b8e2d6", "#2f6a66", None, "rgba(180,240,220,A)", None, 52)),
    body("Euterpe", "Lune", "Petite lune gelée", "−84 à −118 °C", "Azote, traces de vapeur d'eau", "Océans gelés, archipels", "Des milliers d'îlots hérissés de cheminées rocheuses, souvenirs d'anciens volcans.", G("#d4dce6", "#4a5566", None, None, None, 53)),
  ]),
]

pyro = [
  body("Pyro I", "Pyro I", "Tellurique de silicates", "Extrêmement chaud, haute pression", "Dense, vents violents, foudre", "Faune résistante à la chaleur, Valakkar, laboratoires d'ASD", "Tout y est hostile, et pourtant la vie s'y accroche.", G("#e0703a", "#4a1409", {"n": 8, "colors": ["#ff9a5a", "#8a2a12"]}, "rgba(255,120,60,A)", None, 61)),
  body("Monox", "Pyro II", "Tellurique sans noyau", "Tempéré", "Oxygène et monoxyde de carbone toxique", "Cicatrices minières, repaires hors-la-loi", "Tempéré en apparence. Chaque respiration sans filtre est la dernière.", G("#9a8f7a", "#3a3326", None, None, None, 62)),
  body("Bloom", "Pyro III", "Tellurique glacée", "Froid", "Azote-oxygène naturellement respirable", "Ancien centre minier, squatters", "Le seul endroit de Pyro où l'on respire sans masque. Personne n'est parti.", G("#c9d3cf", "#44504c", None, "rgba(200,230,220,A)", None, 63)),
  body("Pyro IV", "Pyro IV", "Tellurique percutée", "Instable", "Récente, en formation", "Installations de données", "Un monde brisé par une collision, qui se dirige lentement vers Pyro V.", G("#8a4a3a", "#2a100c", {"n": 6, "colors": ["#b3654e", "#4e1a12"]}, None, None, 64)),
  body("Pyro V", "Pyro V", "Géante gazeuse", "—", "Tourbillons verts et jaunes", "Récolte d'hydrogène ; lunes Ignis, Vatra, Adir, Fairo, Fuego, Vuur", "La plus grande planète du système. Tout ce qui vole à Pyro finit par y faire le plein.", G("#c7cf6a", "#3d4a1a", {"n": 18, "colors": ["#e0e38a", "#7f9a3a", "#b7b04a"]}, "rgba(210,220,120,A)", None, 65)),
  body("Terminus", "Pyro VI", "Tellurique", "Glacial", "Azote-oxygène avec méthane, respirable mais malsain", "Ruin Station en orbite, nombreux avant-postes", "Le cœur battant de Pyro, et son champ de bataille permanent.", G("#b9c4cc", "#3a4650", {"n": 6, "colors": ["#d8e0e6", "#7c8a95"]}, "rgba(200,215,230,A)", None, 66)),
]

nyx = [
  body("Nyx I", "Nyx I", "Monde sans noyau", "Aride", "Maigre", "Terraformation expérimentale de Genesis Terraforming depuis 2954", "Vidé par Gold Horizon, puis choisi pour un pari. Les raids vanduul ont augmenté depuis.", G("#a38a74", "#35271d", None, None, None, 71)),
  body("Nyx II", "Nyx II", "Monde à haute pression", "Étouffant", "Nuages toxiques", "Aucune installation connue", "Jugé impossible à terraformer. On le regarde de loin.", G("#c8b56a", "#4a3d18", {"n": 10, "colors": ["#e0cf8a", "#8a7430"]}, "rgba(220,200,120,A)", None, 72)),
  body("Nyx III", "Nyx III", "Géante de glace", "Glacial", "Irrespirable", "Ni air ni ressources", "Une sentinelle bleue et vide aux confins du système.", G("#8fb4e8", "#1d2f5a", {"n": 12, "colors": ["#b7d0f5", "#4b6fb0"]}, "rgba(150,190,255,A)", None, 73)),
  body("Delamar", "Glaciem Ring", "Grand astéroïde", "Vide spatial", "Aucune (habitat pressurisé)", "Levski, fondée en 2618 par la People's Alliance", "Creusée dans la roche, près d'une nébuleuse sombre qui cache tout ce qui veut l'être.", G("#3a3a44", "#121218", None, None, {"n": 40, "color": "#ffc882"}, 74)),
]

peoples_h = [
  ("Terriens de Sol", "Humains · Terre", "Le vieux cœur de l'Empire. La Terre abrite le gouvernement, le Sénat et les grandes institutions. Ses habitants se voient comme les gardiens de la tradition impériale, et beaucoup de colons les trouvent lointains."),
  ("Terrans", "Humains · Terra", "Une super-Terre riche en oxygène, découverte en 2516. Sa capitale, Prime, est bâtie sur les deux vaisseaux-colonies d'origine. Culture forte, musique exportée partout, Song University, sièges de grands constructeurs comme Anvil. Le mouvement transitionnaliste y est né : pour lui, c'est Terra qui représente l'avenir, pas la Terre."),
  ("Gens de Stanton", "Humains · colonies corporatistes", "Des ouvriers endettés de Lorville aux ingénieurs aisés de New Babbage, en passant par les foules d'Area18 et les équipes de chantier d'Orison. Leur loyauté va souvent à l'entreprise qui les loge avant l'Empire."),
  ("Gens de Pyro", "Humains · hors de l'Empire", "Descendants des mineurs abandonnés en 2563, squatters, pirates et exilés. Une culture de la récupération et de la parole donnée, où la réputation vaut plus que la loi."),
  ("Peuple de Levski", "Humains · People's Alliance", "Des réfugiés du régime Messer installés à Nyx en 2618. Égalitaires, solidaires, méfiants envers l'UEE même après la chute des Messer."),
  ("Citoyens et Civils", "Humains · statut", "La grande fracture sociale de l'Empire. Seuls les Citoyens, qui ont servi (armée, service civique, contribution notable), votent et accèdent à certaines fonctions. Les Civils vivent, travaillent et paient comme les autres, sans voix au chapitre."),
]
peoples_a = [
  ("Banu", "Protectorat Banu · 7 systèmes", "Bipèdes robustes, à la vie plus courte que les humains, qui ne dorment qu'une dizaine de minutes. Leur société repose sur les Souli, des guildes sans lien de sang où l'on vit et travaille ensemble dès l'enfance. Une république de planètes-États autonomes, presque sans archives ni histoire écrite. Leur vraie religion est le commerce, avec des dieux comme Cassa (la chance) et Taernin (le voyage). Premiers amis de l'humanité en 2438, ils commercent avec tout le monde, même les Vanduul. Leurs systèmes servent de refuge aux fugitifs de l'UEE."),
  ("Xi'an", "Empire Xi'an · 12 à 14 systèmes", "Reptiloïdes à quatre doigts, à sang froid, capables de ralentir leur métabolisme, et d'une longévité immense : l'Empereur Kray, qui a signé la paix en 2789, règne toujours. Leur monde d'origine, RyiXy'an, a été ruiné par une guerre civile ; la capitale est aujourd'hui Ka'ua. Monarchie fédérale organisée en Maisons (Yii'ua), service impérial obligatoire entre 40 et 70 ans. Leur philosophie, le Li'tova, juge chaque acte par ses effets à travers le temps. Après des siècles de guerre froide et d'espionnage, l'accord Akari-Kray a ouvert les échanges. En 2956, la diplomatie piétine de nouveau."),
  ("Tevarin", "Diaspora · Branaugh II", "Un peuple guerrier guidé par le Rijora, un code d'honneur, de loyauté et de devoir. Vaincus en 2545, ils voient leur monde Kaleeth terraformé et rebaptisé Elysium IV. En 2610, le seigneur de guerre Corath'Thal et ses pilotes baissent leurs boucliers et plongent vers la planète perdue plutôt que de se rendre. Aujourd'hui, la diaspora vit surtout sur Branaugh II, hors de l'Empire, entre colère et deuil. Des groupes comme Nemesis les harcèlent, d'autres comme Stronger Together les défendent."),
  ("Vanduul", "Clans nomades · monde d'origine inconnu", "Ils survivent un temps dans le vide sans équipement et changent de couleur de peau selon leur humeur. À 13 ou 14 ans, chaque jeune mâle est chassé de sa famille avec un seul couteau fait main : pas d'héritage, que la valeur. Des clans sans chef suprême et sans communication entre eux, donc sans diplomatie possible. Ils ne créent pas de technologie, ils prennent celle des autres. Ils détruisent leurs vaisseaux plutôt que de se laisser capturer. Dates noires : Armitage en 2681, Orion détruite en 2712, Caliban en 2871, Vega II en 2945."),
  ("Hadesiens", "Éteints · système Hades", "Une civilisation qui s'est détruite elle-même. Il ne reste que des ruines dans le système Hades, et une question que les archéologues n'osent pas poser trop fort."),
  ("Kr'Thak", "Peu documentés", "Une espèce hostile et secrète, dont les contacts avec les autres peuples restent rares et violents. Les archives publiques n'en disent presque rien."),
]

factions = [
  ("Empire (UEE)", [
    ("Imperator", "Laylani Addison, élue en 2950. Chef de l'État, du gouvernement et des armées. Mandat de dix ans."),
    ("Sénat", "Un sénateur par territoire. Vote les lois et peut destituer l'Imperator à l'unanimité."),
    ("Navy, Marines, Army", "Les forces armées. La Navy tient la ligne face aux Vanduul."),
    ("Advocacy", "La police fédérale : crimes inter-systèmes, mandats, grandes enquêtes."),
    ("CDF", "Civilian Defense Force, milice de volontaires. A repris Orison aux Nine Tails."),
  ]),
  ("Corporations", [
    ("Hurston Dynamics", "Armes et munitions. Propriétaire de Hurston, gouverne Lorville d'une main de fer."),
    ("Crusader Industries", "Grands vaisseaux civils. Propriétaire de Crusader et d'Orison."),
    ("ArcCorp", "Moteurs et énergie. Propriétaire d'ArcCorp et d'Area18."),
    ("microTech", "Informatique, mobiGlas. Propriétaire de microTech et New Babbage."),
    ("Shubin Interstellar", "Minage à grande échelle, très présent sur les lunes de Stanton."),
    ("ASD", "Associated Sciences & Development. Recherche controversée, au cœur de la crise de la régénération."),
    ("Genesis Terraforming", "Terraformation expérimentale de Nyx I depuis 2954."),
    ("Pyrotechnic Amalgamated", "Défunte. A exploité Pyro de 2493 à sa faillite en 2563."),
  ]),
  ("Sécurité et mercenaires", [
    ("Bounty Hunters Guild", "La guilde des chasseurs de primes."),
    ("Mercenary Guild", "Contrats d'escorte, de défense et d'assaut."),
    ("InterSec Defense Solutions", "Mercenaires liés à la Navy, actifs à Nyx contre le marché noir et les Vanduul."),
    ("Hockrow Agency", "Enquêteurs privés, mandatés sur les laboratoires Onyx d'ASD."),
    ("Foxwell, Northrock", "Sociétés de sécurité privée qui sous-traitent la violence légale."),
  ]),
  ("Pyro", [
    ("XenoThreat", "Anti-aliens radicaux. Tiennent Ruin Station depuis 2947, de fait les maîtres du système."),
    ("Rough & Ready", "Pragmatiques. Sept stations : Checkmate, Orbituary, Patch City, Gaslight, Rat's Nest, Endgame, Megumi Refueling."),
    ("Citizens for Prosperity", "Veulent reconstruire Pyro. Starlight Service Station, Rod's Fuel 'N Supplies, Dudley & Daughters."),
    ("Headhunters", "Gang violent, commerce et drogues."),
    ("Frontier Fighters", "Anciens militaires qui jugent Pyro perdu et veulent le purger."),
    ("73R Vipers, Fire Rats", "Petits gangs qui survivent entre les grands."),
  ]),
  ("Nyx", [
    ("People's Alliance", "Maîtres de fait du système depuis Levski (2618). Stations People's Service Alpha, Delta, Lambda, Theta."),
    ("QV Services", "Stations de service et de minage (QV Breaker) dans les ceintures."),
    ("Repaires du Keeger Belt", "Bastions criminels supposés dans la ceinture extérieure."),
  ]),
  ("Hors-la-loi et militants", [
    ("Nine Tails", "Anarchistes aux armures néon, actifs depuis 2938, venus de Prime. Auteurs de l'assaut sur Orison."),
    ("Grim HEX", "Pas une faction, un refuge : la station des hors-la-loi de Stanton, dans la ceinture de Yela."),
    ("Nemesis", "Groupe xénophobe qui harcèle la diaspora tevarin."),
    ("Stronger Together", "Association de soutien aux Tevarin."),
    ("Transitionalists", "Mouvement politique terran qui veut déplacer le centre de l'Empire vers Terra."),
  ]),
]

elsewhere = [
  ("Sol", "Berceau de l'humanité. La Terre, siège du gouvernement, et Mars, première planète terraformée."),
  ("Terra", "Super-Terre riche en oxygène : tropiques, crête magnétique, sud froid. Prime, capitale culturelle et commerciale."),
  ("Vega", "Front vanduul. La chute de Vega II en 2945 a déclenché la guerre ouverte."),
  ("Orion", "Planète détruite à l'antimatière par les Vanduul en 2712."),
  ("Caliban", "Système tombé aux mains des Vanduul en 2871."),
  ("Branaugh", "Hors de l'Empire. Refuge principal de la diaspora tevarin."),
  ("Hades", "Ruines des Hadesiens, peuple éteint."),
  ("Magnus", "Voisin de Stanton, vieux système industriel."),
]

esc = html.escape

def planet_canvas(p, size_cls="thumb"):
    return f'<canvas class="{size_cls}" data-planet="{esc(json.dumps(p))}" aria-hidden="true"></canvas>'

def card(b, planet):
    return f'''<article class="body">
  <div class="body-head">{planet_canvas(planet)}<div><div class="b-desig">{esc(b["desig"])}</div><h4>{esc(b["name"])}</h4><div class="b-kind">{esc(b["kind"])}</div></div></div>
  <dl><dt>Climat</dt><dd>{esc(b["climat"])}</dd><dt>Atmosphère</dt><dd>{esc(b["atmo"])}</dd><dt>Sur place</dt><dd>{esc(b["place"])}</dd></dl>
  <p class="mood">{esc(b["mood"])}</p>
</article>'''

out = []
out.append('''  <!-- ANNEXES -->
  <nav class="annex-nav" aria-label="Annexes du journal">
    <span class="il-tag">Annexes du journal</span>
    <a href="#atlas-stanton">Stanton</a><a href="#atlas-pyro">Pyro</a><a href="#atlas-nyx">Nyx</a><a href="#atlas-ailleurs">Ailleurs</a><a href="#peuples">Peuples</a><a href="#factions">Factions</a>
  </nav>

  <section class="annex" id="atlas-stanton">
    <div class="log"><span class="n">Annexe A · 1</span><span class="loc">Atlas · Stanton</span><span>Étoile de type G · découverte en 2851</span></div>
    <div class="text" data-read>
      <h2>Atlas de Stanton</h2>
      <p>Quatre planètes, douze lunes, deux ceintures d'astéroïdes : l'Aaron Halo, entre les orbites de Crusader et d'ArcCorp, et la ceinture de Yela. Les planètes obéissent au droit commun de l'Empire, mais la police y est privée. Chaque année, les quatre patrons se retrouvent à la Stanton System Conference pour se partager ce qui reste à partager.</p>
    </div>''')
for owner, sub, _, bodies in stanton:
    out.append(f'    <h3 class="group">{esc(owner)} <span>{esc(sub)}</span></h3>\n    <div class="bodies">')
    for i, bdy in enumerate(bodies):
        pl = bdy["planet"] if bdy["planet"] else stanton[[x[0] for x in stanton].index(owner)][2]
        out.append(card(bdy, pl))
    out.append('    </div>')
out.append('  </section>')

out.append('''  <section class="annex" id="atlas-pyro">
    <div class="log"><span class="n">Annexe A · 2</span><span class="loc">Atlas · Pyro</span><span>Étoile éruptive de type K · 11,3 milliards d'années</span></div>
    <div class="text" data-read>
      <h2>Atlas de Pyro</h2>
      <p>En 2469, l'officier Raj MacEwan remarque une anomalie gravitationnelle. En 2493, Pyrotechnic Amalgamated trouve le point de saut et réclame le système pour ses mines. L'étoile, entrée dans une longue phase de novæ, bombarde tout de radiations : réparations, pertes, faillite en 2563. Les mineurs restés sur place deviennent des squatters, puis des gangs. Aujourd'hui, la règle est simple : celui qui a le plus d'armes gagne.</p>
    </div>
    <div class="bodies">''')
for bdy in pyro: out.append(card(bdy, bdy["planet"]))
out.append('    </div>\n  </section>')

out.append('''  <section class="annex" id="atlas-nyx">
    <div class="log"><span class="n">Annexe A · 3</span><span class="loc">Atlas · Nyx</span><span>Étoile naine de type F · découverte en 2582</span></div>
    <div class="text" data-read>
      <h2>Atlas de Nyx</h2>
      <p>Découvert en 2582 par la navigatrice Carla Larry, jugé sans intérêt, jamais revendiqué par l'Empire. Deux ceintures l'encerclent : le Glaciem Ring, vers huit unités astronomiques, collé à une nébuleuse sombre qui cache tout, et le Keeger Belt, plus loin, où l'on soupçonne des bastions criminels et où tournent les stations QV Breaker. Économie maigre, population plus nombreuse qu'on ne le croit, et les Vanduul juste derrière la porte.</p>
    </div>
    <div class="bodies">''')
for bdy in nyx: out.append(card(bdy, bdy["planet"]))
out.append('    </div>\n  </section>')

out.append('''  <section class="annex" id="atlas-ailleurs">
    <div class="log"><span class="n">Annexe A · 4</span><span class="loc">Atlas · Au-delà de la carte</span><span>Systèmes non visités</span></div>
    <div class="text"><h2>Ailleurs dans la galaxie</h2></div>
    <dl class="elsewhere">''')
for n, d in elsewhere: out.append(f'      <dt>{esc(n)}</dt><dd>{esc(d)}</dd>')
out.append('    </dl>\n  </section>')

out.append('''  <section class="annex" id="peuples">
    <div class="log"><span class="n">Annexe B</span><span class="loc">Peuples et cultures</span><span>Humains · espèces connues</span></div>
    <div class="text" data-read>
      <h2>Peuples et cultures</h2>
      <p>L'humanité n'est pas un seul peuple. Quatre siècles d'expansion ont fait naître des accents, des fiertés et des rancunes d'un système à l'autre. Et autour de l'Empire vivent d'autres espèces, chacune avec sa propre idée de ce que vaut une vie.</p>
    </div>
    <h3 class="group">Humains <span>Cultures de l'Empire et de ses marges</span></h3>
    <div class="peoples">''')
for n, t, d in peoples_h: out.append(f'      <article class="people"><div class="b-desig">{esc(t)}</div><h4>{esc(n)}</h4><p>{esc(d)}</p></article>')
out.append('    </div>\n    <h3 class="group">Autres espèces <span>Alliés, rivaux, ennemis, disparus</span></h3>\n    <div class="peoples wide">')
for n, t, d in peoples_a: out.append(f'      <article class="people" data-read><div class="b-desig">{esc(t)}</div><h4>{esc(n)}</h4><p>{esc(d)}</p></article>')
out.append('    </div>\n  </section>')

out.append('''  <section class="annex" id="factions">
    <div class="log"><span class="n">Annexe C</span><span class="loc">Factions</span><span>Qui tient quoi en 2956</span></div>
    <div class="text"><h2>Factions</h2></div>
    <div class="factions">''')
for grp, items in factions:
    out.append(f'      <div class="fgroup"><h3>{esc(grp)}</h3><dl>')
    for n, d in items: out.append(f'        <dt>{esc(n)}</dt><dd>{esc(d)}</dd>')
    out.append('      </dl></div>')
out.append('    </div>\n  </section>')

s = s.replace('%%ANNEXES%%', '\n'.join(out))

# ---------- 4. CSS ----------
css = '''.annex-nav{margin:88px 0 0;display:flex;flex-wrap:wrap;gap:8px 10px;align-items:center;border-top:1px solid var(--line);padding-top:14px}
.annex-nav .il-tag{margin-right:8px}
.annex-nav a{font-family:var(--mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--star);text-decoration:none;border:1px solid var(--line);padding:6px 10px}
.annex-nav a:hover{border-color:var(--hud);color:var(--hud)}
.annex{margin-top:64px;display:grid;gap:22px;scroll-margin-top:60px}
.group{font-family:var(--display);font-weight:500;text-transform:uppercase;font-size:28px;letter-spacing:.03em;margin:10px 0 0;display:flex;flex-wrap:wrap;gap:4px 14px;align-items:baseline}
.group span{font-family:var(--mono);font-size:11px;font-weight:400;letter-spacing:.08em;color:var(--faint)}
.bodies{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:1px;background:var(--line);border:1px solid var(--line)}
.body{background:var(--hull);padding:14px 16px;display:grid;gap:10px;align-content:start}
.body-head{display:flex;gap:14px;align-items:center}
canvas.thumb{width:64px;height:64px;flex:0 0 64px;display:block}
.b-desig{font-family:var(--mono);font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--faint)}
.body h4,.people h4{margin:0;font-family:var(--display);font-weight:500;font-size:26px;text-transform:uppercase;line-height:1}
.b-kind{font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--amber);margin-top:3px}
.body dl{margin:0;display:grid;grid-template-columns:auto 1fr;gap:4px 12px;font-size:14px;line-height:1.4}
.body dt{font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--faint);padding-top:3px}
.body dd{margin:0;color:var(--star)}
.mood{margin:0;font-style:italic;font-size:15px;line-height:1.45;color:var(--dim);border-top:1px solid var(--line);padding-top:8px}
.elsewhere{margin:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px 28px}
.elsewhere dt{font-family:var(--display);font-size:22px;text-transform:uppercase;color:var(--hud);line-height:1}
.elsewhere dd{margin:2px 0 0;font-size:15px;line-height:1.45;color:var(--dim)}
.elsewhere dt,.elsewhere dd{grid-column:auto}
.peoples{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1px;background:var(--line);border:1px solid var(--line)}
.peoples.wide{grid-template-columns:repeat(auto-fill,minmax(360px,1fr))}
@media (max-width:420px){.peoples.wide{grid-template-columns:1fr}}
.people{background:var(--hull);padding:16px 18px;display:grid;gap:6px;align-content:start}
.people p{margin:0;font-size:15px;line-height:1.55;color:var(--dim)}
.factions{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px}
.fgroup{border:1px solid var(--line);background:var(--panel)}
.fgroup h3{margin:0;padding:10px 14px;border-bottom:1px solid var(--line);font-family:var(--mono);font-weight:400;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--hud)}
.fgroup dl{margin:0;padding:12px 14px;display:grid;gap:2px}
.fgroup dt{font-family:var(--body);font-weight:400;font-size:16px;color:var(--star);margin-top:8px}
.fgroup dt:first-child{margin-top:0}
.fgroup dd{margin:0;font-size:14px;line-height:1.45;color:var(--dim)}
.reveal{animation'''
s = s.replace('.reveal{animation', css, 1)

# elsewhere dl pairs: wrap each pair — simpler: make dl a 2-col grid of dt/dd stacked via display:contents? use divs instead
s = re.sub(r'      <dt>([^<]*)</dt><dd>([^<]*)</dd>\n(?=      <dt>|    </dl>\n  </section>)',
           lambda m: f'      <div><dt>{m.group(1)}</dt><dd>{m.group(2)}</dd></div>\n', s)

# ---------- 5. JS: draw planet thumbnails ----------
js = '''  const thumbs=[...document.querySelectorAll("canvas[data-planet]")];
  function drawThumb(c){const dpr=Math.min(window.devicePixelRatio||1,2);const w=64,h=64;c.width=w*dpr;c.height=h*dpr;const ctx=c.getContext("2d");ctx.setTransform(dpr,0,0,dpr,0,0);
    let p;try{p=JSON.parse(c.dataset.planet);}catch(e){return;}const r=rng(p.seed||1);ctx.fillStyle="#06080c";ctx.fillRect(0,0,w,h);stars(ctx,w,h,r,18,0.7);
    try{planet(ctx,{x:w/2,y:h/2,r:w*0.34,base:p.base,bands:p.bands,atmo:p.atmo,lights:p.lights,light:-2.4,seed:p.seed});}catch(e){console.error(e);}}
  thumbs.forEach(drawThumb);
'''
s = s.replace('  /* ---------- voice narration ---------- */', js + '  /* ---------- voice narration ---------- */', 1)
open(P, 'w', encoding='utf-8').write(s)
print("done", s.count('class="body"'), s.count('data-planet'))
