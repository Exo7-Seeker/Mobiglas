# merged into build_v3.py namespace: data, MAP
import json as _j, math as _m, random as _r
_L=_j.load(open('lore_systems.json',encoding='utf-8'))
FR={"Mercury":"Mercure","Venus":"Vénus","Earth":"Terre","Herschel Belt":"Ceinture de Herschel","Saturn":"Saturne","Kuiper Belt":"Ceinture de Kuiper","Pluto":"Pluton"}
PAL=[("ceinture",None),("amas",None),("champ",None),("station",None),
 ("gazeuse",["#d9b48a","#6b4a2e"]),("glace",["#bfe3ee","#3c6474"]),("océan",["#5fa3d6","#13314f"]),
 ("smog",["#b8a76a","#4a4228"]),("volcan",["#e0703a","#3a1208"]),("désert",["#d9b878","#5a4126"]),
 ("terraform",["#7fb38a","#24453a"]),("super-terre",["#86b98f","#2a4a3c"]),("habitable",["#7fb38a","#24453a"]),
 ("naine",["#9d978f","#38342f"])]
def pcol(name,kind):
  if name=="Terre":return ["#6aa6dc","#1d3d2a"]
  if name=="Mars":return ["#d0784a","#4a1c10"]
  k=kind.lower()
  for w,c in PAL:
    if w in k and c:return c
  return ["#a49d94","#3d3935"]
used={b["name"] for b in data["bodies"]}
ZC={"UEE":"#8fb4e0","frontière":"#e0a347","vanduul":"#e2624b","non revendiqué":"#b0a79c","banu":"#c9a6e8","xian":"#86cfc8"}
for s in _L["systems"]:
  data["systems"].append(dict(name=s["name"],star=s.get("star",""),disc=s.get("disc",""),status=s.get("status",""),law=s.get("law",""),factions=s.get("factions",""),note=s.get("note",""),lore=True,zone=s.get("zone","")))
  lay={};tops=[];
  for b in s["bodies"]:
    n=FR.get(b["name"],b["name"])
    if n in used:n=f'{n} ({s["name"]})'
    used.add(n)
    kind=b.get("kind","");k=kind.lower()
    body=dict(sys=s["name"],parent=None,name=n,desig=b.get("desig",""),kind=kind,climat=b.get("climat",""),atmo=b.get("atmo",""),notes=b.get("notes",""),lore=True,util=[],planet=dict(base=pcol(n,kind)))
    data["bodies"].append(body);tops.append((body,k))
    if b.get("city"):MAP["cities"][n]={"name":b["city"]}
  N=len(tops);ri=0;nplan=sum(1 for _,k in tops if not any(w in k for w in("ceinture","amas","champ","station")))
  orbit_n=max(1,N)
  for i,(body,k) in enumerate(tops):
    r=round(70+i*(270/max(1,N-1))) if N>1 else 150
    if any(w in k for w in("ceinture","amas","champ")):lay[body["name"]]=dict(ring=True,r=r,la=80+i*23%120)
    elif "station" in k:lay[body["name"]]=dict(special=True,x=860,y=560)
    else:
      s_=20 if "géante" in k else 16 if "super" in k else 7 if ("naine" in k or "proto" in k or "petite" in k) else 11
      lay[body["name"]]=dict(r=r,a=(i*137.5+20)%360,s=s_)
  MAP["layout"][s["name"]]=lay
# galaxy: force layout with Stanton pinned
nodes=MAP["galaxy"]["nodes"]
for n in ("Magnus","Terra","Hadrian"):nodes.pop(n,None)
links=[tuple(l) for l in _L["links"]]
names=["Stanton","Pyro","Nyx"]+[s["name"] for s in _L["systems"]]
_r.seed(4)
P={n:[500+_r.uniform(-300,300),310+_r.uniform(-200,200)] for n in names}
P["Stanton"]=[500,310];P["Pyro"]=[330,400];P["Nyx"]=[640,220]
for it in range(1500):
  F={n:[0.0,0.0] for n in names}
  for i,a in enumerate(names):
    for b in names[i+1:]:
      dx=P[a][0]-P[b][0];dy=(P[a][1]-P[b][1])*1.4;d=max(1,_m.hypot(dx,dy));f=9000/d/d
      F[a][0]+=f*dx/d;F[a][1]+=f*dy/d;F[b][0]-=f*dx/d;F[b][1]-=f*dy/d
  for a,b in links:
    dx=P[b][0]-P[a][0];dy=P[b][1]-P[a][1];d=max(1,_m.hypot(dx,dy));f=(d-120)*0.04
    F[a][0]+=f*dx/d;F[a][1]+=f*dy/d;F[b][0]-=f*dx/d;F[b][1]-=f*dy/d
  for n in names:
    F[n][0]+=(500-P[n][0])*0.004;F[n][1]+=(310-P[n][1])*0.008
    if n=="Stanton":continue
    st=max(0.05,1-it/1500)*0.6
    P[n][0]=min(950,max(50,P[n][0]+F[n][0]*st));P[n][1]=min(565,max(45,P[n][1]+F[n][1]*st))
for s in _L["systems"]:
  x,y=P[s["name"]];nodes[s["name"]]=dict(x=round(x),y=round(y),r=7,color="#7d8590",lore=True)
nodes["Stanton"]["x"],nodes["Stanton"]["y"]=500,310
for n in ("Pyro","Nyx"):nodes[n]["x"],nodes[n]["y"]=round(P[n][0]),round(P[n][1])
MAP["galaxy"]["links"]=[[a,b,(a,b) in(("Stanton","Nyx"),)] for a,b in links]
MAP["zones"]=ZC

# ---- moons
def _moon(sys,parent,name,desig,kind,climat="",atmo="",flore="",notes="",col=None,lore=False,util=None,faction=""):
  b=dict(sys=sys,parent=parent,name=name,desig=desig,kind=kind,climat=climat,atmo=atmo,flore=flore,faune="",decouverte="",faction=faction,util=util or [],poi="",notes=notes,planet=dict(base=col or pcol(name,kind)))
  if lore:b["lore"]=True
  data["bodies"].append(b)
P5="Pyro V"
_moon("Pyro",P5,"Ignis","Pyro V-a","Lune rocheuse à canyons",climat="Glacial",atmo="Dioxyde de soufre très toxique",notes="Petites réserves d'oxygène exploitables pour les réservoirs d'air.",col=["#c9b48a","#4a3a22"],faction="Aucune (Pyro)")
_moon("Pyro",P5,"Vatra","Pyro V-b","Lune sombre",atmo="Épaisse, haute pression, azote-méthane",flore="Plantes vivant des hydrocarbures plutôt que du CO₂",col=["#5d5a6e","#1d1b26"],faction="Aucune (Pyro)")
_moon("Pyro",P5,"Adir","Pyro V-c","Lune cratérisée",notes="Collines rocheuses et montagnes déchiquetées.",col=["#9d978f","#38342f"],faction="Aucune (Pyro)")
_moon("Pyro",P5,"Fairo","Pyro V-d","Lune océanique",notes="Mers saumâtres ; séismes fréquents qui lèvent des vagues spectaculaires. Écosystème inhabituel en surface et en profondeur.",col=["#5fa3d6","#13314f"],faction="Aucune (Pyro)")
_moon("Pyro",P5,"Fuego","Pyro V-e","Lune tellurique",notes="Sol jaune et noir. Cache des contrebandiers Headhunters au début des années 2600.",col=["#c9b04a","#2a2614"],faction="Aucune (Pyro)")
_moon("Pyro",P5,"Vuur","Pyro V-f","Lune tellurique",climat="Plus chaude que la moyenne",flore="Plantes à carbone cristallin ; ancien site prisé de recherche botanique",col=["#7a6a5a","#2a221c"],faction="Aucune (Pyro)")
for n,p,d,k,notes in [("Lune","Terre","Terre I","Satellite naturel","Le satellite de la Terre."),
  ("Phobos","Mars","Mars I","Petite lune rocheuse",""),("Deimos","Mars","Mars II","Petite lune rocheuse",""),
  ("Io","Jupiter","Jupiter I","Lune volcanique",""),("Europe","Jupiter","Jupiter II","Lune glacée",""),
  ("Ganymède","Jupiter","Jupiter III","Lune glacée","La plus grande lune de Sol."),("Callisto","Jupiter","Jupiter IV","Lune glacée",""),
  ("Titan","Saturne","Saturne VI","Lune à atmosphère épaisse","")]:
  _moon("Sol",p,n,d,k,notes=notes,lore=True,col=["#e0703a","#3a1208"] if "volcan" in k else None)
