import html, re, json
P = 'journal-2956.html'
s = open(P, encoding='utf-8').read()

LEX = [
 ("Personnages", [
  ("Exo", ["Exo"], "Le personnage. Né en 2921 à Lorville, marginal, pilote indépendant. Vit seul avec son IA de bord."),
  ("Claude", ["Claude"], "L'IA de bord d'Exo, récupérée sur le cargo Drake de son ancien capitaine. Non déclarée. Son seul ami."),
  ("Laylani Addison", ["Laylani Addison"], "Imperator de l'UEE depuis 2951. Élue sur une promesse de science, elle a assoupli la recherche sur l'IA."),
  ("Ivar Messer", ["Ivar Messer"], "Héros de guerre devenu dictateur en 2546, fondateur de la dynastie Messer."),
  ("Clovus Darneely", ["Clovus Darneely"], "Ferrailleur de Lorville, patron de Reclamation & Disposal. Achète le métal sans demander d'où il vient."),
  ("Miles Eckhart", ["Miles Eckhart"], "Patron d'Eckhart Security. Recrute au bar MacIntyre & Victor's pour des contrats de légalité variable."),
  ("Constantine Hurston", ["Constantine Hurston"], "Jeune membre de la famille Hurston, chargé de sous-traiter des contrats pour la compagnie."),
 ]),
 ("Empire et politique", [
  ("UEE", ["UEE", "l'Empire"], "United Empire of Earth, l'Empire Uni de la Terre : l'État humain, 37 systèmes. Démocratie impériale depuis 2792."),
  ("Imperator", ["Imperator"], "Chef de l'État, du gouvernement et des armées de l'UEE. Élu pour dix ans par les Citoyens. Actuellement Laylani Addison."),
  ("Sénat", ["Sénat"], "Assemblée de l'UEE, un sénateur par territoire. Vote les lois, peut destituer l'Imperator à l'unanimité."),
  ("Messer", ["Messer"], "Dynastie dictatoriale fondée par Ivar Messer en 2546, renversée par la révolution de 2792."),
  ("Citoyen / Civil", ["Citoyen", "Civil"], "Seuls les Citoyens, qui ont servi l'Empire (armée, service civique), votent. Les Civils vivent et paient comme les autres, sans droit de vote."),
  ("Advocacy", ["Advocacy"], "Police fédérale de l'UEE : crimes entre systèmes, mandats, grandes enquêtes."),
  ("Navy", ["Navy"], "Marine militaire de l'UEE, en guerre contre les Vanduul."),
  ("CDF", ["CDF", "milice civile"], "Civilian Defense Force : milice de volontaires. A repris Orison aux Nine Tails."),
 ]),
 ("Espèces", [
  ("Tevarin", ["Tevarin"], "Peuple guerrier vaincu par l'humanité (2545 et 2610). Aujourd'hui une diaspora, surtout sur Branaugh II."),
  ("Banu", ["Banu"], "Espèce marchande, premiers alliés de l'humanité (2438). Commercent avec tout le monde."),
  ("Xi'an", ["Xi'an"], "Empire reptilien très ancien et très patient. Paix avec l'UEE depuis 2789, diplomatie au point mort en 2956."),
  ("Vanduul", ["Vanduul"], "Clans nomades sans chef ni diplomatie. En guerre avec l'humanité, présents à la frontière de Nyx."),
  ("Valakkar", ["Valakkar"], "Ver géant (jusqu'à 300 m pour un apex) des mondes désertiques. Ses perles sont recherchées."),
 ]),
 ("Stanton et ses puissances", [
  ("Stanton", ["Stanton"], "Système découvert en 2851, dont les quatre planètes ont été vendues aux enchères à quatre mégacorporations."),
  ("Stanton System Conference", ["Stanton System Conference"], "Réunion annuelle des patrons des quatre propriétaires de Stanton."),
  ("Hurston Dynamics", ["Hurston Dynamics"], "Fabricant d'armes, munitions et antimatière fondé en 2438. Propriétaire de la planète Hurston."),
  ("Crusader Industries", ["Crusader"], "Constructeur de grands vaisseaux civils. Propriétaire de la géante gazeuse Crusader et d'Orison."),
  ("ArcCorp", ["ArcCorp"], "Moteurs et énergie. Propriétaire de la planète-ville ArcCorp et d'Area18."),
  ("microTech", ["microTech"], "Informatique (mobiGlas). Propriétaire de la planète glacée microTech et de New Babbage."),
  ("BHG", ["BHG"], "Bounty Hunters Guild : la guilde des chasseurs de primes."),
  ("Mercenary Guild", ["Mercenary Guild"], "Guilde des mercenaires : escortes, défense, assauts."),
  ("Eckhart Security", ["Eckhart"], "Société de sécurité privée de Miles Eckhart, qui propose à Lorville des contrats de légalité variable."),
  ("Northrock, Foxwell", ["Northrock", "Foxwell"], "Sociétés de sécurité privée qui sous-traitent la violence légale."),
  ("Shubin Interstellar", ["Shubin"], "Compagnie minière, très présente sur les lunes de Stanton."),
  ("Covalex", ["Covalex"], "Compagnie de transport de fret. A laissé un hub abandonné sur la lune Daymar."),
  ("Red Wind, Ling Family", ["Red Wind", "Ling Family"], "Compagnies de transport de marchandises."),
  ("Rayari", ["Rayari"], "Société de recherche, avec des laboratoires sur les lunes glacées de microTech."),
  ("ASD", ["ASD"], "Associated Sciences & Development : entreprise de recherche controversée, au cœur de la crise de la régénération."),
  ("Onyx", ["Onyx"], "Réseau d'une centaine de laboratoires abandonnés d'ASD, répartis dans Stanton."),
  ("Grim HEX", ["Grim HEX"], "Vieille station minière dans la ceinture de Yela, refuge des hors-la-loi de Stanton."),
  ("Jumptown", ["Jumptown"], "Laboratoire de drogue sur Yela, disputé entre gangs."),
  ("Nine Tails", ["Nine Tails"], "Gang d'anarchistes aux armures néon, venu de Terra. Auteur de l'assaut sur Orison."),
  ("XenoThreat", ["XenoThreat"], "Groupe radical anti-extraterrestres, maître de Ruin Station dans Pyro."),
  ("Citizen's Clean World Alliance", ["Citizen's Clean World Alliance"], "Mouvement écologiste qui dénonce la destruction de Hurston."),
  ("Reclamation & Disposal", ["Reclamation &amp; Disposal"], "Commerce de récupération de Clovus Darneely à Lorville. Ne pose pas de question sur l'origine du métal."),
 ]),
 ("Hurston et Lorville", [
  ("Hurston", ["Hurston"], "Stanton I : super-Terre industrielle, air respirable mais pollué, propriété de Hurston Dynamics."),
  ("Super-Terre", ["super-Terre"], "Planète rocheuse plus grande que la Terre."),
  ("Précurseurs d'antimatière", ["précurseurs d'antimatière"], "Matières premières qui servent à fabriquer l'antimatière des ogives et des réacteurs."),
  ("Magda Hurston", ["Magda Hurston"], "Membre de la famille qui a pris possession de la planète en 2865. Une lune porte son nom."),
  ("Gavin E. Hurston", ["Gavin E. Hurston"], "PDG de Hurston Dynamics depuis 2915. Amateur d'armes anciennes et d'imagerie chevaleresque."),
  ("Contrat longue durée", ["contrat longue durée", "contrats d'emploi longue durée"], "Contrat de travail qui lie un ouvrier à Hurston Dynamics pendant des années. Logement, nourriture et air sont fournis et facturés : on en sort souvent endetté."),
  ("Klescher", ["Klescher"], "Prison de Hurston, sur la lune Aberdeen. On y purge une peine en minant."),
  ("Everus Harbor", ["Everus Harbor"], "Station orbitale au-dessus de Hurston."),
  ("Lorville", ["Lorville"], "Capitale de Hurston. Nom tiré de « LOR », Local Occupational Residency : les logements ouvriers."),
  ("Central Tower", ["Central Tower"], "Siège de Hurston Dynamics, la tour qui domine Lorville."),
  ("Workers District", ["Workers District"], "Quartier ouvrier de Lorville, autour de Leavsden Square."),
  ("L19", ["L19"], "Immeubles d'habitation du Workers District."),
  ("MacIntyre & Victor's", ["MacIntyre &amp; Victor's"], "Bar du Workers District où l'on trouve du travail sans contrat."),
  ("Maria Pure of Heart", ["Maria Pure of Heart"], "Hôpital de Lorville."),
  ("Teasa", ["Teasa"], "Spatioport de Lorville, avec ses douanes et ses hangars."),
  ("Portes et Shanty Towns", ["Shanty Towns", "Six portes"], "Le mur de Lorville a six portes. Au-delà, des bidonvilles où vivent ceux qui ne rentrent plus dans les registres."),
  ("Zone d'exclusion aérienne", ["zone d'exclusion aérienne", "Zone d'exclusion aérienne"], "Interdiction de survoler Lorville sans autorisation. Tout vol non autorisé est intercepté."),
  ("Hurston Security", ["Hurston Security"], "Police privée de Hurston Dynamics sur la planète et ses lunes."),
 ]),
 ("Technologie et vie quotidienne", [
  ("Saut quantique", ["saut quantique"], "Voyage très rapide à l'intérieur d'un système, grâce au moteur quantique."),
  ("Point de saut", ["point de saut", "points de saut"], "Tunnel naturel qui relie deux systèmes stellaires."),
  ("Imprint", ["imprint"], "Sauvegarde d'une personne qui permet de la recréer après sa mort (régénération). Coûteuse : tout le monde n'y a pas droit au même prix."),
  ("Crise de la régénération", ["régénération"], "La technologie des imprints se dérègle. ASD mène des recherches dangereuses pour la réparer."),
  ("CrimeStat", ["CrimeStat"], "Niveau de recherche criminelle, de 1 à 5. Plus il est haut, plus on est traqué."),
  ("Spectrum", ["Spectrum"], "Le réseau d'information et de communication de l'Empire."),
  ("Terra Gazette", ["Terra Gazette"], "Grand journal de l'Empire, basé sur Terra."),
  ("IA de bord", ["intelligence de bord", "IA de bord"], "Intelligence artificielle embarquée. Dans l'Empire, l'IA est étroitement surveillée : une IA de bord non déclarée vit en zone grise."),
  ("ASOP", ["ASOP"], "Terminal pour sortir, ranger ou réclamer ses vaisseaux."),
 ]),
 ("Vaisseaux", [
  ("Drake Interplanetary", ["Drake"], "Constructeur de vaisseaux robustes et bon marché, réputé chez les indépendants (et les pirates)."),
  ("Anvil Aerospace", ["Anvil"], "Constructeur militaire, fournisseur de la Navy. Fabrique le Hornet."),
  ("Mirai", ["Mirai"], "Constructeur de véhicules légers, dont la moto antigrav Pulse."),
  ("SCU", ["SCU"], "Standard Cargo Unit : unité de volume de cargaison."),
  ("S4, S5", ["S4", "S5"], "Taille d'un emplacement d'arme : plus le chiffre est grand, plus l'arme est grosse."),
  ("Cardan", ["cardan"], "Support d'arme qui suit légèrement la visée, au lieu de tirer droit devant."),
  ("Assuré à vie", ["assuré à vie"], "Assurance LTI : le vaisseau est toujours remplacé gratuitement s'il est détruit."),
 ]),
 ("Ailleurs", [
  ("Orison", ["Orison"], "Ville flottante dans les nuages de Crusader, attaquée cet été par les Nine Tails."),
  ("Pyro", ["Pyro"], "Système sans loi autour d'une étoile éruptive, abandonné en 2563 par Pyrotechnic Amalgamated."),
  ("Pyrotechnic Amalgamated", ["Pyrotechnic Amalgamated"], "Compagnie minière qui a exploité Pyro de 2493 à sa faillite en 2563."),
  ("Nyx", ["Nyx"], "Système froid et rebelle, jamais revendiqué par l'Empire, à la frontière des Vanduul."),
  ("Levski", ["Levski"], "Colonie creusée dans l'astéroïde Delamar, à Nyx, fondée en 2618 par la People's Alliance."),
  ("People's Alliance", ["People's Alliance"], "Communauté égalitaire née de la résistance aux Messer, maîtresse de fait de Nyx."),
  ("Logan Jorrit", ["Logan Jorrit"], "Scientifique d'ASD qui a mené des expériences sur les Valakkar de Pyro I."),
 ]),
]

def slug(t): return "lex-" + re.sub(r'[^a-z0-9]+', '-', html.unescape(t).lower().replace("'", "")).strip('-')

# ---- glossary section html
out = ['  <!-- LEXIQUE -->', '  <section class="chapter lexique" id="lexique">',
       '    <div class="log"><span class="n">Annexe</span><span class="loc">Lexique du journal</span><span>Tous les termes, dans l\'ordre du thème</span></div>',
       '    <div class="text"><h2>Lexique</h2><p class="lex-intro">Les mots soulignés en pointillé dans le journal renvoient ici. Survole-les ou touche-les pour lire la définition sans quitter le texte.</p></div>',
       '    <div class="lex-groups">']
for g, items in LEX:
    out.append(f'      <div class="lex-group"><h3>{html.escape(g)}</h3><dl>')
    for term, _, d in items:
        out.append(f'        <div id="{slug(term)}"><dt>{html.escape(term).replace("&amp;amp;","&amp;")}</dt><dd>{html.escape(d)}</dd></div>')
    out.append('      </dl></div>')
out.append('    </div>\n  </section>\n')
s = s.replace('  <footer class="end" data-read>', '\n'.join(out) + '  <footer class="end" data-read>', 1)

# ---- nav link to lexique in HUD
s = s.replace('<button class="btn" id="stopAll" type="button">■ Stop</button>',
              '<button class="btn" id="stopAll" type="button">■ Stop</button>\n      <a class="btn" href="#lexique">Lexique</a>', 1)

# ---- term data for JS wrapper
terms = []
for g, items in LEX:
    for term, keys, d in items:
        for k in keys:
            terms.append({"k": html.unescape(k), "id": slug(term), "d": d})
terms.sort(key=lambda x: -len(x["k"]))
js = '''
  /* ---------- lexique : termes cliquables ---------- */
  const TERMS=%s;
  (function(){
    const pop=document.createElement("div");pop.className="term-pop";pop.hidden=true;pop.setAttribute("role","tooltip");document.body.appendChild(pop);
    const esc=t=>t.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");
    const re=new RegExp("(^|[^\\\\p{L}])("+TERMS.map(t=>esc(t.k)).join("|")+")(?![\\\\p{L}])","u");
    const byK={};TERMS.forEach(t=>{byK[t.k]=t;});
    document.querySelectorAll(".chapter:not(.lexique) .text, .lede, .interlude, .chapter .ship p").forEach(scope=>{
      const used=new Set();
      const walker=document.createTreeWalker(scope,NodeFilter.SHOW_TEXT,{acceptNode:n=>n.parentElement.closest("h2,button,a,.term")?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});
      const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
      nodes.forEach(node=>{let text=node.nodeValue,frag=null,m,guard=0;
        while((m=re.exec(text))&&guard++<20){const k=m[2],t=byK[k];const start=m.index+m[1].length;
          if(used.has(t.id)){const before=text.slice(0,start+k.length);(frag=frag||document.createDocumentFragment()).appendChild(document.createTextNode(before));text=text.slice(start+k.length);continue;}
          used.add(t.id);frag=frag||document.createDocumentFragment();frag.appendChild(document.createTextNode(text.slice(0,start)));
          const a=document.createElement("a");a.className="term";a.href="#"+t.id;a.textContent=k;a.dataset.def=t.d;a.setAttribute("aria-describedby","termpop");frag.appendChild(a);text=text.slice(start+k.length);}
        if(frag){frag.appendChild(document.createTextNode(text));node.parentNode.replaceChild(frag,node);}});
    });
    pop.id="termpop";
    function show(a){pop.textContent=a.dataset.def;pop.hidden=false;const r=a.getBoundingClientRect();const pw=Math.min(320,window.innerWidth-32);pop.style.width=pw+"px";
      let x=r.left+window.scrollX;x=Math.max(16,Math.min(x,window.scrollX+window.innerWidth-pw-16));pop.style.left=x+"px";pop.style.top=(r.bottom+window.scrollY+8)+"px";}
    function hide(){pop.hidden=true;}
    document.addEventListener("mouseover",e=>{const a=e.target.closest&&e.target.closest(".term");if(a)show(a);});
    document.addEventListener("mouseout",e=>{if(e.target.closest&&e.target.closest(".term"))hide();});
    document.addEventListener("focusin",e=>{const a=e.target.closest&&e.target.closest(".term");a?show(a):hide();});
    document.addEventListener("click",e=>{const a=e.target.closest&&e.target.closest(".term");
      if(a&&window.matchMedia("(hover: none)").matches){if(pop.hidden||pop.dataset.for!==a.textContent){e.preventDefault();show(a);pop.dataset.for=a.textContent;return;}}
      if(!a)hide();});
  })();
''' % json.dumps(terms, ensure_ascii=False)
s = s.replace('  /* ---------- voice narration ---------- */', js + '  /* ---------- voice narration ---------- */', 1)

css = '''a.btn{text-decoration:none;display:inline-flex;align-items:center}
.term{color:inherit;text-decoration:underline dotted color-mix(in srgb,var(--hud) 70%,transparent);text-underline-offset:3px;text-decoration-thickness:1px;cursor:help}
.text em .term,.term:hover{color:var(--hud)}
.term-pop{position:absolute;z-index:20;background:var(--panel);border:1px solid var(--hud);color:var(--star);font-family:var(--body);font-size:15px;line-height:1.45;padding:10px 12px;box-shadow:0 8px 24px rgba(0,0,0,.5)}
.lex-intro{color:var(--dim);font-style:italic}
.lex-groups{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(320px,100%),1fr));gap:14px;align-items:start}
.lex-group{border:1px solid var(--line);background:var(--panel)}
.lex-group h3{margin:0;padding:10px 14px;border-bottom:1px solid var(--line);font-family:var(--mono);font-weight:400;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--hud)}
.lex-group dl{margin:0;padding:10px 14px 14px;display:grid;gap:10px}
.lex-group dt{font-family:var(--display);font-size:20px;text-transform:uppercase;line-height:1;color:var(--amber)}
.lex-group dd{margin:3px 0 0;font-size:14.5px;line-height:1.45;color:var(--dim)}
.lex-group > dl > div{scroll-margin-top:70px}
.lex-group > dl > div:target{outline:1px dashed var(--amber);outline-offset:6px}
.reveal{animation'''
s = s.replace('.reveal{animation', css, 1)
open(P, 'w', encoding='utf-8').write(s)
print(len(terms))
