import hashlib,json
FILES=["Lorville-buildings-3.19-CIG.jpg","Lorville-Teasa-Spaceport-Aerial.jpg","Lorville-workers-district-metro-center-3.4.1.jpg",
"Lorville-workers-district-leavsden-square01-3.4.1.jpg","Hurston-strip-mine-3.4.1.jpg","Hurston_OuterDistricts_v002.jpg",
"Lorville-workers-district-reclamation-3.4.1.jpg","Lorville-TeasaSpaceport-Overview-Daytime-Alpha3.17.jpg",
"Stanton-hurston-magda-orbit-3.17.jpg","Lorville_redesign_preview_2022-11-22.jpg","MariaPureOfHeart.jpg",
"Lorville-workers-district-maria-hospital-3.4.1.jpg","Maria_pure_of_heart_statue.jpg","Hurston-4.3.jpg","Lorville-maria-hospital-entrance-01.jpg","Lorville-workers-district-L19-vista-3.4.1.jpg","Lorville-workers-district-L19-habroom-3.4.1.jpg","RSI-Arccorp_03-Min.jpg","Streaking_Vulture.png","Vulture_flying_through_debris_field.jpg","Lorville-Teasa-Spaceport-3.19.jpg","Hospital_Bed_Regeneration.png","Lorville-workers-district-MV-bar-3.4.1.jpg","Crusader-orison-spaceport-exterior-01.jpg","Quantum_Drive_Travel.png","The_Glaciem_ring_in_the_space_of_Nyx.png"]
out={}
for f in FILES:
    n=f.replace(' ','_');h=hashlib.md5(n.encode()).hexdigest()
    base="https://media.starcitizen.tools/"
    out[f]={"full":base+h[0]+"/"+h[:2]+"/"+n,"thumb":base+"thumb/"+h[0]+"/"+h[:2]+"/"+n+"/1280px-"+n+".webp"}
open('pwa_src/wiki.js','w').write("window.__WIKI="+json.dumps(out)+";")
print(json.dumps(out)[:300])
