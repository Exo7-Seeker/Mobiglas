import json, os, re, glob, shutil
from PIL import Image, ImageDraw, ImageFilter

S = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(S, 'pwa')
SRC = os.path.join(S, 'pwa_src')
os.makedirs(OUT, exist_ok=True)
rd = lambda p: open(os.path.join(SRC, p), encoding='utf-8').read()

h = open(os.path.join(S, 'journal-v3.html'), encoding='utf-8').read()

def R(a, b, cnt=1):
    global h
    assert a in h, 'missing: ' + a[:80]
    h = h.replace(a, b, cnt)

# --- images : chemins locaux au lieu de /_blob/
R('<img src="/_blob/${esc(id)}"', '<img src="${esc(id.indexOf("/")>=0||id.indexOf(".")>=0?id:"/_blob/"+id)}"')
# --- exposer les données et les commandes pour Seeker
R('\nconst esc=s=>', '\nwindow.__APP=APP;\nconst esc=s=>')
R('window.__codexSelect=id=>codex.select(id,false);', 'window.__codexSelect=id=>codex.select(id,false);\nwindow.__hangarSelect=id=>hangar.select(id,false);')
R('  function draw(){const P=mq.matches;', '''  let _pv=null;const DEP={galaxy:0,system:1,body:2};
  mount.addEventListener("pointerdown",e=>{const r=svg.getBoundingClientRect();if(!r.width)return;svg.style.transformOrigin=((e.clientX-r.left)/r.width*100).toFixed(1)+"% "+((e.clientY-r.top)/r.height*100).toFixed(1)+"%";},true);
  function zoomFx(){if(_pv!==null&&_pv!==st.view){const c=DEP[st.view]>DEP[_pv]?"zin":"zout";svg.classList.remove("zin","zout");void svg.getBoundingClientRect();svg.classList.add(c);}_pv=st.view;}
  function draw(){zoomFx();const P=mq.matches;''')
R('window.__drawCanvas=draw;', 'window.__drawCanvas=draw;window.__scenes=scenes;window.__kit={rng,bg,stars,glow,nebula,planet};')
R('  draw();refreshers.push(draw);', '''  window.__map={state:()=>({view:st.view,sys:st.sys,body:st.body,sel:st.sel}),sel:n=>{st.sel=n;draw();return true;},go:t=>{go(t);return true;},place:n=>{const p=plByName[n];if(!p)return false;st.sys=p.sys;const v=placeView(p);if(v==="body"){st.view="body";st.body=topOf(p.parent);}else st.view="system";st.sel="pl:"+p.name;draw();return true;},site:n=>{const x=siteByName[n];if(!x)return false;st.sys=byName[x.body].sys;st.view="body";st.body=x.body;st.sel="si:"+x.name;draw();return true;}};
  draw();refreshers.push(draw);''')
# --- onglet Seeker
R('const TABS=["journal","cap",', 'const TABS=["journal","cap","seeker",')
R('<a class="tab" role="tab" href="#cap" data-tab="cap" aria-selected="false">Cap</a>', '<a class="tab" role="tab" href="#cap" data-tab="cap" aria-selected="false">Cap</a>\n    <a class="tab" role="tab" href="#seeker" data-tab="seeker" aria-selected="false">S̷eeker</a>')
order = ["seeker", "carte", "hangar", "journal", "cap", "codex", "contacts", "spectrum"]
links = {mm.group(1): mm.group(0) for mm in re.finditer(r'<a class="tab" role="tab" href="#(\w+)"[^<]*</a>', h)}
assert set(links) == set(order), links.keys()
first = min(h.index(v) for v in links.values()); last = max(h.index(v) + len(v) for v in links.values())
h = h[:first] + "\n    ".join(links[k] for k in order) + h[last:]
R('else show(TABS.includes(start)?start:"journal")', 'else show(TABS.includes(start)?start:"seeker")')
m = re.search(r'  <section class="tab-panel" id="tab-spectrum"', h)
assert m
h = h[:m.start()] + rd('seeker.html') + '\n' + h[m.start():]
h = h.replace('window.claude', 'window.__mgClaude')
# --- textes liés à claude.ai
h = h.replace("(Les données s'affichent quand la page est ouverte dans claude.ai.)", "")
# --- polices mobiGlas
R('family=Saira+Extra+Condensed', 'family=Chakra+Petch:wght@300;400;600&family=IBM+Plex+Mono:wght@300;400&family=Saira+Extra+Condensed')

# --- découpe : tête (title+fonts+style) / reste
i = h.index('</style>') + len('</style>')
head_part, body_part = h[:i], h[i:]
head_part = head_part.replace('<title>Journal de bord 2956</title>', '')

doc = f'''<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>mobiGlas · Exo</title>
<meta name="theme-color" content="#020a10">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" href="icon-192.png">
<link rel="apple-touch-icon" href="icon-192.png">
<script>{rd('shim.js')}</script>
{head_part}
<style>{rd('mg.css')}</style>
</head>
<body>
{body_part}
<script>{rd('mg.js')}</script>
<script>{rd('wiki.js')}</script>
<script>{rd('scenes2.js')}</script>
<script>{rd('revue.js')}</script>
<script>{rd('book.js')}</script>
<script>{rd('mapfx.js')}</script>
<script>{rd('codex2.js')}</script>
<script>{rd('holo3d.js')}</script>
<script>{rd('hangar3d.js')}</script>
<script>{rd('seeker.js')}</script>
</body>
</html>
'''
open(os.path.join(OUT, 'index.html'), 'w', encoding='utf-8').write(doc)

# --- data.json (contenu évolutif)
data = {}
for col in ['journal', 'cap', 'hangar', 'spectrum', 'decouvertes', 'contacts']:
    data[col] = {}
    for f in sorted(glob.glob(os.path.join(S, 'dbexport', col, '*.json'))):
        data[col][os.path.splitext(os.path.basename(f))[0]] = json.load(open(f, encoding='utf-8'))
data['images'] = {
    'ship-corsair': {'asset': 'corsair.webp'}, 'ship-f7c': {'asset': 'f7c.webp'},
    'ship-vulture': {'asset': 'vulture.webp'}, 'ct-exo': {'asset': 'exo.webp'}}
json.dump(data, open(os.path.join(OUT, 'data.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

for src, dst in [('corsair-2000.webp', 'corsair.webp'), ('f7c-2000.webp', 'f7c.webp'), ('vulture-2000.webp', 'vulture.webp'), ('exo-vulture.webp', 'exo.webp')]:
    shutil.copy(os.path.join(S, src), os.path.join(OUT, dst))

# --- manifest
json.dump({
    "name": "mobiGlas · Exo", "short_name": "mobiGlas", "description": "Journal de bord, carte et Seeker, l'IA d'Exo.",
    "start_url": "./", "scope": "./", "display": "fullscreen", "display_override": ["fullscreen", "standalone"],
    "orientation": "portrait", "background_color": "#020a10", "theme_color": "#020a10", "lang": "fr",
    "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
              {"src": "icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}]},
    open(os.path.join(OUT, 'manifest.webmanifest'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# --- service worker
open(os.path.join(OUT, 'sw.js'), 'w', encoding='utf-8').write('''const V="mg-v13";
const SHELL=["./","index.html","data.json","manifest.webmanifest","icon-192.png","icon-512.png","corsair.webp","f7c.webp","vulture.webp","exo.webp"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()));});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==V&&k!=="mg-fonts").map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener("fetch",e=>{const u=new URL(e.request.url);if(e.request.method!=="GET")return;
  if(/fonts\.(googleapis|gstatic)\.com$|media\.starcitizen\.tools$/.test(u.hostname)){e.respondWith(caches.open("mg-fonts").then(c=>c.match(e.request).then(hit=>{const net=fetch(e.request).then(r=>{if(r.ok||r.type==="opaque")c.put(e.request,r.clone());return r;}).catch(()=>hit||Response.error());return hit||net;})));return;}
  if(u.origin!==location.origin)return;
  if(u.pathname.endsWith("data.json")||u.pathname.endsWith("/")||u.pathname.endsWith("index.html")){
    e.respondWith(fetch(new Request(e.request.url,{cache:"no-store",credentials:"same-origin"})).then(r=>{const cp=r.clone();caches.open(V).then(c=>c.put(e.request,cp));return r;}).catch(()=>caches.match(e.request,{ignoreSearch:true})));return;}
  e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));});
''')

# --- icônes
def icon(sz):
    im = Image.new('RGB', (sz, sz), (2, 10, 16))
    glow = Image.new('RGB', (sz, sz), (0, 0, 0))
    d = ImageDraw.Draw(glow)
    import math
    def hexa(r, w, col, dd):
        pts = [(sz/2 + r*math.cos(math.radians(a)), sz/2 + r*math.sin(math.radians(a))) for a in range(-90, 270, 60)]
        dd.line(pts + [pts[0]], fill=col, width=w, joint='curve')
    hexa(sz*0.36, max(2, sz//60), (95, 227, 240), d)
    hexa(sz*0.26, max(1, sz//110), (42, 169, 196), d)
    d.ellipse([sz*0.44, sz*0.44, sz*0.56, sz*0.56], fill=(255, 179, 71))
    im.paste(Image.blend(im, glow.filter(ImageFilter.GaussianBlur(sz/40)), 0.9))
    d2 = ImageDraw.Draw(im)
    hexa(sz*0.36, max(2, sz//70), (191, 246, 255), d2)
    hexa(sz*0.26, max(1, sz//120), (95, 227, 240), d2)
    d2.ellipse([sz*0.455, sz*0.455, sz*0.545, sz*0.545], fill=(255, 200, 120))
    return im
icon(192).save(os.path.join(OUT, 'icon-192.png'))
icon(512).save(os.path.join(OUT, 'icon-512.png'))
print('ok', len(doc))
