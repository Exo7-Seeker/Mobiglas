/* Hologramme 3D d'un vaisseau à partir du vrai modèle de la visionneuse RSI (fichier .holo converti).
   Un doigt = tourner dans tous les sens, deux doigts = zoomer. Rendu additif cyan avec bords lumineux. */
(function(){
  async function inflate(u8){var ds=new DecompressionStream("deflate");var s=new Blob([u8]).stream().pipeThrough(ds);return new Uint8Array(await new Response(s).arrayBuffer());}
  function unplane(b,n){var o=new Uint32Array(n),p0=0,p1=n,p2=2*n,p3=3*n;for(var i=0;i<n;i++)o[i]=b[p0+i]|(b[p1+i]<<8)|(b[p2+i]<<16)|(b[p3+i]<<24)>>>0;return o;}
  function unz(x){return (x>>>1)^-(x&1);}
  async function decode(buf){
    var dv=new DataView(buf),m=String.fromCharCode(dv.getUint8(0),dv.getUint8(1),dv.getUint8(2),dv.getUint8(3));if(m!=="HOLO")throw new Error("format inconnu");
    var nv=dv.getUint32(4,true),nt=dv.getUint32(8,true),mn=[dv.getFloat32(12,true),dv.getFloat32(16,true),dv.getFloat32(20,true)],ext=dv.getFloat32(24,true),la=dv.getUint32(28,true),lb=dv.getUint32(32,true);
    var A=await inflate(new Uint8Array(buf,36,la)),B=await inflate(new Uint8Array(buf,36+la,lb));
    var pd=unplane(A,nv*3),id=unplane(B,nt*3);
    var P=new Float32Array(nv*3),x=0,y=0,z=0,s=ext/65535;
    for(var i=0;i<nv;i++){x+=unz(pd[i*3]);y+=unz(pd[i*3+1]);z+=unz(pd[i*3+2]);P[i*3]=mn[0]+x*s;P[i*3+1]=mn[1]+y*s;P[i*3+2]=mn[2]+z*s;}
    var I=new Uint32Array(nt*3),prev=0;
    for(var t=0;t<nt;t++){var a=prev+unz(id[t*3]);I[t*3]=a;I[t*3+1]=a+unz(id[t*3+1]);I[t*3+2]=a+unz(id[t*3+2]);prev=a;}
    var N=new Float32Array(nv*3);
    for(t=0;t<nt;t++){var i0=I[t*3]*3,i1=I[t*3+1]*3,i2=I[t*3+2]*3,ux=P[i1]-P[i0],uy=P[i1+1]-P[i0+1],uz=P[i1+2]-P[i0+2],vx=P[i2]-P[i0],vy=P[i2+1]-P[i0+1],vz=P[i2+2]-P[i0+2],
      nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;N[i0]+=nx;N[i0+1]+=ny;N[i0+2]+=nz;N[i1]+=nx;N[i1+1]+=ny;N[i1+2]+=nz;N[i2]+=nx;N[i2+1]+=ny;N[i2+2]+=nz;}
    for(i=0;i<nv;i++){var l=Math.hypot(N[i*3],N[i*3+1],N[i*3+2])||1;N[i*3]/=l;N[i*3+1]/=l;N[i*3+2]/=l;}
    var c=[0,0,0],r=0;for(i=0;i<nv;i++){c[0]+=P[i*3];c[1]+=P[i*3+1];c[2]+=P[i*3+2];}c=c.map(function(v){return v/nv;});
    for(i=0;i<nv;i++)r=Math.max(r,Math.hypot(P[i*3]-c[0],P[i*3+1]-c[1],P[i*3+2]-c[2]));
    return {P:P,N:N,I:I,c:c,r:r};}
  var VS="attribute vec3 p;attribute vec3 n;uniform mat4 mvp;uniform mat3 nm;varying vec3 vn;varying float vy;uniform float r;uniform vec3 c;void main(){vn=normalize(nm*n);vy=(p.y-c.y)/r;gl_Position=mvp*vec4(p,1.0);}";
  var FS="precision mediump float;varying vec3 vn;varying float vy;uniform float t;uniform float pass;void main(){vec3 n=normalize(vn);float f=1.0-abs(n.z);float lam=max(dot(n,normalize(vec3(-0.4,0.7,0.6))),0.0);"+
    "float scan=0.9+0.1*sin(vy*160.0-t*3.0);"+
    "if(pass<0.5){vec3 col=vec3(0.08,0.40,0.58)*(0.3+0.7*lam)+vec3(0.45,0.88,1.0)*pow(f,3.0)*0.75;gl_FragColor=vec4(col*scan,0.82);}"+
    "else{gl_FragColor=vec4(vec3(0.05,0.16,0.24)*(0.3+pow(f,2.0))*0.07,1.0);}}";
  function mat(){return new Float32Array(16);}
  function persp(fov,a,nr,fr){var f=1/Math.tan(fov/2),m=mat();m[0]=f/a;m[5]=f;m[10]=(fr+nr)/(nr-fr);m[11]=-1;m[14]=2*fr*nr/(nr-fr);return m;}
  function mul(a,b){var o=mat();for(var i=0;i<4;i++)for(var j=0;j<4;j++){var s=0;for(var k=0;k<4;k++)s+=a[k*4+j]*b[i*4+k];o[i*4+j]=s;}return o;}
  function rotY(a){var m=mat(),c=Math.cos(a),s=Math.sin(a);m[0]=c;m[2]=-s;m[5]=1;m[8]=s;m[10]=c;m[15]=1;return m;}
  function rotX(a){var m=mat(),c=Math.cos(a),s=Math.sin(a);m[0]=1;m[5]=c;m[6]=s;m[9]=-s;m[10]=c;m[15]=1;return m;}
  function trans(x,y,z){var m=mat();m[0]=m[5]=m[10]=m[15]=1;m[12]=x;m[13]=y;m[14]=z;return m;}
  function sh(gl,t,src){var s=gl.createShader(t);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s;}

  async function mount(el,src,label){
    el.classList.add("h3d");el.innerHTML='<canvas></canvas><div class="h3d-grid"></div><div class="h3d-scan"></div><div class="holo-c"><i></i><i></i><i></i><i></i></div><div class="holo-l"><b>HOLO</b> · '+label+'</div><div class="h3d-msg">Chargement du modèle…</div><div class="holo-h">Un doigt : tourner · deux doigts : zoomer</div>';
    var cv=el.querySelector("canvas"),msg=el.querySelector(".h3d-msg");
    var gl=cv.getContext("webgl",{antialias:true,alpha:true,premultipliedAlpha:false,depth:true});
    if(!gl||!gl.getExtension("OES_element_index_uint")){msg.textContent="WebGL indisponible sur cet appareil";return;}
    var buf;try{buf=src instanceof ArrayBuffer?src:await (await fetch(src)).arrayBuffer();var M=await decode(buf);}catch(e){msg.textContent="Modèle illisible : "+e.message;return;}
    var pr=gl.createProgram();gl.attachShader(pr,sh(gl,gl.VERTEX_SHADER,VS));gl.attachShader(pr,sh(gl,gl.FRAGMENT_SHADER,FS));gl.linkProgram(pr);gl.useProgram(pr);
    function ab(d,loc){var b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,d,gl.STATIC_DRAW);var l=gl.getAttribLocation(pr,loc);gl.enableVertexAttribArray(l);gl.vertexAttribPointer(l,3,gl.FLOAT,false,0,0);}
    ab(M.P,"p");ab(M.N,"n");var ib=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,M.I,gl.STATIC_DRAW);
    var U={pass:gl.getUniformLocation(pr,"pass"),mvp:gl.getUniformLocation(pr,"mvp"),nm:gl.getUniformLocation(pr,"nm"),t:gl.getUniformLocation(pr,"t"),r:gl.getUniformLocation(pr,"r"),c:gl.getUniformLocation(pr,"c")};
    gl.uniform1f(U.r,M.r);gl.uniform3fv(U.c,M.c);
    gl.enable(gl.BLEND);gl.clearColor(0,0,0,0);
    msg.remove();el.classList.add("on");
    var yaw=-0.7,pitch=0.38,dist=2.3,auto=true,pts={},last=null,pinch=null,idle=0;
    el.style.touchAction="none";
    el.addEventListener("pointerdown",function(e){pts[e.pointerId]={x:e.clientX,y:e.clientY};el.setPointerCapture(e.pointerId);auto=false;});
    el.addEventListener("pointermove",function(e){if(!pts[e.pointerId])return;var p=pts[e.pointerId],ids=Object.keys(pts);
      if(ids.length===2){var a=pts[ids[0]],b=pts[ids[1]],d0=Math.hypot(a.x-b.x,a.y-b.y);p.x=e.clientX;p.y=e.clientY;var d1=Math.hypot(pts[ids[0]].x-pts[ids[1]].x,pts[ids[0]].y-pts[ids[1]].y);if(d1>0)dist=Math.max(1.1,Math.min(5,dist*d0/d1));return;}
      yaw+=(e.clientX-p.x)*0.01;pitch=Math.max(-1.45,Math.min(1.45,pitch+(e.clientY-p.y)*0.01));p.x=e.clientX;p.y=e.clientY;});
    function up(e){delete pts[e.pointerId];if(!Object.keys(pts).length){idle=performance.now();}}
    el.addEventListener("pointerup",up);el.addEventListener("pointercancel",up);
    el.addEventListener("wheel",function(e){e.preventDefault();dist=Math.max(1.1,Math.min(5,dist*(e.deltaY>0?1.1:0.9)));},{passive:false});
    var t0=performance.now(),vis=true,lastF=0;
    if("IntersectionObserver" in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;}).observe(el);
    (function frame(now){requestAnimationFrame(frame);if(!el.isConnected||document.hidden||!el.offsetParent||!vis||now-lastF<30)return;lastF=now;
      var w=el.clientWidth,h=el.clientHeight,dpr=Math.min(2,window.devicePixelRatio||1);if(cv.width!==Math.round(w*dpr)){cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);}
      if(!auto&&!Object.keys(pts).length&&now-idle>2500)auto=true;if(auto)yaw+=0.004;
      gl.viewport(0,0,cv.width,cv.height);gl.clear(gl.COLOR_BUFFER_BIT);
      var model=mul(rotX(pitch),mul(rotY(yaw),trans(-M.c[0],-M.c[1],-M.c[2])));
      var view=trans(0,0,-dist*M.r),P=persp(0.62,w/h,M.r*0.1,M.r*10),mvp=mul(P,mul(view,model));
      var nm=new Float32Array([model[0],model[1],model[2],model[4],model[5],model[6],model[8],model[9],model[10]]);
      gl.uniformMatrix4fv(U.mvp,false,mvp);gl.uniformMatrix3fv(U.nm,false,nm);gl.uniform1f(U.t,(now-t0)/1000);
      gl.clear(gl.DEPTH_BUFFER_BIT);
      /* passe 1 : surfaces visibles, ombrées en cyan avec bords lumineux */
      gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.uniform1f(U.pass,0);gl.drawElements(gl.TRIANGLES,M.I.length,gl.UNSIGNED_INT,0);
      /* passe 2 : structure intérieure en transparence, comme un hologramme */
      gl.disable(gl.DEPTH_TEST);gl.blendFunc(gl.ONE,gl.ONE);gl.uniform1f(U.pass,1);gl.drawElements(gl.TRIANGLES,M.I.length,gl.UNSIGNED_INT,0);})(t0);
  }
  window.mgHolo3D=mount;
})();
