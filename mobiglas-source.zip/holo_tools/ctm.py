import struct,lzma,numpy as np,sys
class R:
    def __init__(s,d):s.d=d;s.p=0
    def u(s,f):v=struct.unpack_from(f,s.d,s.p);s.p+=struct.calcsize(f);return v
    def tag(s):t=s.d[s.p:s.p+4];s.p+=4;return t
    def packed(s,count,size,signed,flt=False):
        (ps,)=s.u('<I');props=s.d[s.p:s.p+5];s.p+=5;data=s.d[s.p:s.p+ps];s.p+=ps
        n=count*size*4
        hdr=props+struct.pack('<q',n)
        raw=lzma.decompress(hdr+data,format=lzma.FORMAT_ALONE)
        b=np.frombuffer(raw[:n],dtype=np.uint8).reshape(4,size,count)  # planes, component, element
        v=(b[0].astype(np.uint32)<<24)|(b[1].astype(np.uint32)<<16)|(b[2].astype(np.uint32)<<8)|b[3].astype(np.uint32)
        v=v.T.copy()  # count x size
        if flt:return v.view(np.float32)
        v=v.astype(np.int64)
        if signed:v=np.where(v&1,-((v+1)>>1),v>>1)
        return v
def load(path):
    d=open(path,'rb').read();r=R(d)
    assert r.tag()==b'OCTM';(ver,)=r.u('<i');meth=r.tag();nv,nt,nuv,na,flags=r.u('<5i');(cl,)=r.u('<i');r.p+=cl
    assert meth==b'MG2\x00',meth
    assert r.tag()==b'MG2H'
    vp,np_=r.u('<2f');mn=r.u('<3f');mx=r.u('<3f');div=r.u('<3i')
    assert r.tag()==b'VERT';iv=r.packed(nv,3,False)
    assert r.tag()==b'GIDX';gi=r.packed(nv,1,False)[:,0];gi=np.cumsum(gi)
    mn=np.array(mn,np.float64);mx=np.array(mx,np.float64);div=np.array(div);size=(mx-mn)/div
    z=gi//(div[0]*div[1]);rem=gi-z*div[0]*div[1];y=rem//div[0];x=rem-y*div[0]
    origin=np.stack([x,y,z],1)*size+mn
    # delta X restore when same grid box as previous
    dx=iv[:,0].copy()
    same=np.concatenate([[False],gi[1:]==gi[:-1]])
    out=np.empty_like(dx)
    prev=0
    for i in range(nv):
        v=dx[i]+(prev if same[i] else 0);out[i]=v;prev=v
    V=np.stack([vp*out+origin[:,0],vp*iv[:,1]+origin[:,1],vp*iv[:,2]+origin[:,2]],1).astype(np.float32)
    assert r.tag()==b'INDX';ix=r.packed(nt,3,False)
    I=ix.copy()
    for i in range(nt):
        if i>=1:I[i,0]+=I[i-1,0]
        I[i,2]+=I[i,0]
        if i>=1 and I[i,0]==I[i-1,0]:I[i,1]+=I[i-1,1]
        else:I[i,1]+=I[i,0]
    return V,I.astype(np.uint32),(mn,mx)
if __name__=='__main__':
    import time;t=time.time()
    V,I,b=load(sys.argv[1]);print(V.shape,I.shape,V.min(0),V.max(0),b,I.max(),I.min(),time.time()-t)
    np.save('V.npy',V);np.save('I.npy',I)
