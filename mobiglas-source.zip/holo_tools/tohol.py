import numpy as np,zlib,struct,sys
from ctm import load
V,I,_=load(sys.argv[1]);I=I.astype(np.int64)
mn=V.min(0).astype(np.float32);ext=float((V.max(0)-mn).max())
q=np.round((V-mn)/ext*65535).astype(np.int64)
qd=np.diff(q,axis=0,prepend=np.zeros((1,3),np.int64))
zz=lambda x:((x<<1)^(x>>63)).astype(np.uint32)
d=I.copy();d[:,1]-=I[:,0];d[:,2]-=I[:,0];d[1:,0]=I[1:,0]-I[:-1,0]
def planes(a):return a.view(np.uint8).reshape(-1,4).T.copy().tobytes()
A=zlib.compress(planes(zz(qd).reshape(-1)),9);B=zlib.compress(planes(zz(d).reshape(-1)),9)
hdr=b'HOLO'+struct.pack('<II3ff II',len(V),len(I),*mn,ext,len(A),len(B))
open(sys.argv[2],'wb').write(hdr+A+B);print(sys.argv[2],len(hdr)+len(A)+len(B))
