(function(){
const APP=__APP__;
const esc=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const norm=s=>String(s||"").normalize("NFD").replace(/[̀-ͯ]/g,"").toLowerCase();
const slug=s=>norm(s).replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
let IMAGES={},HSTAT={},MET=[],DISC={},ASSETS=null,DB=null;
const refreshers=[];
const refreshAll=()=>refreshers.forEach(f=>{try{f();}catch(e){console.error(e);}});
const post=root=>{if(window.__linkTerms)window.__linkTerms(root);root.querySelectorAll("canvas[data-scene]").forEach(c=>{if(window.__drawCanvas)window.__drawCanvas(c);});};

/* ---------------- schematic icons (original line art) ---------------- */
const IC={
 fighter:'<path d="M50 8 L58 38 L88 62 L88 70 L58 64 L56 84 L66 92 L34 92 L44 84 L42 64 L12 70 L12 62 L42 38 Z"/><ellipse cx="50" cy="32" rx="4" ry="9"/><path d="M46 92 v4 M54 92 v4 M20 66 v-10 M80 66 v-10"/>',
 salvager:'<rect x="34" y="22" width="32" height="66" rx="6"/><rect x="42" y="12" width="16" height="12" rx="3"/><path d="M36 34 L16 14 M64 34 L84 14"/><circle cx="14" cy="12" r="7"/><circle cx="86" cy="12" r="7"/><path d="M40 50 h20 M40 60 h20 M40 70 h20 M44 88 v6 M56 88 v6"/>',
 heavy:'<path d="M50 6 L64 20 L66 46 L92 54 L92 66 L66 70 L62 92 L38 92 L34 70 L8 66 L8 54 L34 46 L36 20 Z"/><rect x="44" y="18" width="12" height="14" rx="3"/><path d="M40 6 v14 M60 6 v14 M20 54 v-10 M80 54 v-10 M42 92 v5 M58 92 v5"/><circle cx="50" cy="58" r="6"/>',
 bike:'<path d="M12 62 Q18 40 50 40 L80 44 Q92 48 90 58 L82 64 L18 66 Z"/><path d="M40 40 L46 30 L60 30"/><ellipse cx="28" cy="72" rx="12" ry="3"/><ellipse cx="72" cy="72" rx="12" ry="3"/>',
 turret:'<path d="M22 72 A28 28 0 0 1 78 72 Z"/><path d="M44 50 V12 M56 50 V12 M40 12 h8 M52 12 h8"/><path d="M14 72 h72 M30 80 h40"/><circle cx="50" cy="60" r="5"/>',
 noseturret:'<path d="M30 40 A20 20 0 0 1 70 40 Z"/><path d="M42 40 L34 78 M58 40 L66 78"/><path d="M22 40 h56"/><circle cx="50" cy="32" r="4"/>',
 gatling:'<circle cx="50" cy="50" r="32"/><circle cx="50" cy="50" r="6"/><circle cx="50" cy="28" r="6"/><circle cx="69" cy="39" r="6"/><circle cx="69" cy="61" r="6"/><circle cx="50" cy="72" r="6"/><circle cx="31" cy="61" r="6"/><circle cx="31" cy="39" r="6"/>',
 guns:'<rect x="10" y="36" width="44" height="14" rx="3"/><rect x="10" y="56" width="44" height="14" rx="3"/><path d="M54 40 H92 M54 46 H92 M54 60 H92 M54 66 H92 M18 70 v10 h20"/>',
 shield:'<path d="M50 10 L84 30 L84 70 L50 90 L16 70 L16 30 Z"/><path d="M50 26 L70 38 L70 62 L50 74 L30 62 L30 38 Z"/>',
 quantum:'<circle cx="50" cy="50" r="34"/><circle cx="50" cy="50" r="20"/><circle cx="50" cy="50" r="6"/><path d="M50 8 v10 M50 82 v10 M8 50 h10 M82 50 h10"/>',
 head_cinch:'<rect x="30" y="58" width="40" height="30" rx="5"/><path d="M50 58 V20"/><path d="M46 20 L50 8 L54 20"/><circle cx="50" cy="44" r="4"/>',
 head_trawler:'<rect x="30" y="58" width="40" height="30" rx="5"/><path d="M50 58 L14 14 M50 58 L86 14 M50 58 L32 10 M50 58 L68 10 M50 58 V8"/>',
 head_abrade:'<rect x="30" y="58" width="40" height="30" rx="5"/><path d="M50 58 L34 16 M50 58 L66 16 M50 58 V12"/><path d="M34 16 Q50 6 66 16"/>',
 person:'<circle cx="50" cy="34" r="16"/><path d="M18 90 Q20 58 50 56 Q80 58 82 90"/>',
 ai:'<rect x="26" y="26" width="48" height="48" rx="6"/><circle cx="50" cy="50" r="10"/><circle cx="50" cy="50" r="3"/><path d="M36 26 v-12 M50 26 v-12 M64 26 v-12 M36 74 v12 M50 74 v12 M64 74 v12 M26 40 h-12 M26 60 h-12 M74 40 h12 M74 60 h12"/>',
 book:'<path d="M50 24 Q34 14 14 18 V82 Q34 78 50 88 Q66 78 86 82 V18 Q66 14 50 24 Z"/><path d="M50 24 V88"/>',
 people:'<circle cx="34" cy="38" r="11"/><circle cx="66" cy="38" r="11"/><path d="M12 84 Q14 58 34 56 Q46 57 50 66 Q54 57 66 56 Q86 58 88 84"/>',
 fauna:'<path d="M20 70 Q30 30 50 40 Q70 50 80 30"/><path d="M28 78 l-4 10 M44 74 l-2 10 M60 66 l2 10"/><circle cx="78" cy="32" r="4"/>',
 flora:'<path d="M50 90 V40"/><path d="M50 60 Q20 56 18 26 Q46 28 50 60 Z"/><path d="M50 48 Q78 44 82 14 Q54 18 50 48 Z"/>',
 faction:'<path d="M22 12 H78 V58 Q78 80 50 92 Q22 80 22 58 Z"/><path d="M36 40 h28 M50 26 v36"/>',
 term:'<text x="50" y="64" text-anchor="middle" font-size="40" font-family="Georgia,serif" fill="currentColor" stroke="none">Aa</text>',
 planet:'<circle cx="50" cy="50" r="24"/><ellipse cx="50" cy="50" rx="42" ry="12"/>'
};
const ico=(n,cls)=>`<svg class="ico ${cls||""}" viewBox="0 0 100 100" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">${IC[n]||IC.book}</svg>`;

/* ---------------- image slot (schematic or uploaded capture) ---------------- */
function imageSlot(key,icon,caption){
  const id=IMAGES[key];
  const img=id?`<img src="/_blob/${esc(id)}" alt="${esc(caption)}" loading="lazy">`:`<div class="schem">${ico(icon)}<span>Schéma de bord</span></div>`;
  const btn=ASSETS?`<div class="up"><label class="btn small-btn">${id?"Remplacer la capture":"Ajouter ta capture"}<input type="file" accept="image/png,image/jpeg,image/webp" data-upload="${esc(key)}" hidden></label><span class="up-msg" role="status"></span></div>`:"";
  return `<figure class="slot">${img}${btn}</figure>`;
}
document.addEventListener("change",async e=>{
  const inp=e.target.closest&&e.target.closest("input[data-upload]");if(!inp||!inp.files||!inp.files[0])return;
  const key=inp.dataset.upload,file=inp.files[0],msg=inp.closest(".slot").querySelector(".up-msg");
  if(!ASSETS||!DB){msg.textContent="Import indisponible ici.";return;}
  msg.textContent="Envoi…";
  try{const prev=IMAGES[key];const r=await ASSETS.upload(file);await DB.collection("images").doc(key).set({asset:r.id});
    if(prev){try{await ASSETS.delete(prev);}catch(_){}}msg.textContent="Capture enregistrée.";}
  catch(err){const c=err&&err.code;msg.textContent=c==="too_large"?"Image trop lourde (20 Mo max).":c==="unsupported_type"?"Format non pris en charge (PNG, JPEG ou WebP).":"L'envoi a échoué. Réessaie plus tard.";}
});

/* ---------------- inventory component ---------------- */
function Inventory(mount,opt){
  mount.innerHTML=`<div class="inv"><aside class="inv-side"><input class="inv-search" type="search" placeholder="${esc(opt.placeholder||"Rechercher…")}" aria-label="Rechercher"><div class="inv-cats" role="group" aria-label="Catégories"></div><div class="inv-list"></div></aside><article class="inv-detail" tabindex="-1" aria-live="polite"></article></div>`;
  const side=mount.querySelector(".inv-side"),list=mount.querySelector(".inv-list"),cats=mount.querySelector(".inv-cats"),det=mount.querySelector(".inv-detail"),search=mount.querySelector(".inv-search");
  const st={q:"",cat:"Tout",sel:null};
  let saved=null;try{saved=localStorage.getItem("inv-"+opt.key);}catch(e){}
  function items(){return opt.items();}
  function renderCats(){const all=["Tout",...opt.cats.filter(c=>items().some(i=>i.cat===c))];
    cats.hidden=all.length<=2;cats.innerHTML=all.map(c=>`<button type="button" class="inv-cat" aria-pressed="${c===st.cat}" data-cat="${esc(c)}">${esc(c)}</button>`).join("");}
  function renderList(){const q=norm(st.q);let html="",n=0;
    opt.cats.forEach(c=>{if(st.cat!=="Tout"&&st.cat!==c)return;const its=items().filter(i=>i.cat===c&&(!q||norm(i.title+" "+(i.sub||"")+" "+(i.text||"")).includes(q)));
      if(!its.length)return;n+=its.length;
      html+=`<div class="inv-group"><h3>${esc(c)} <span>${its.length}</span></h3>`+its.map(i=>`<button type="button" class="inv-item${i.dim?" dim":""}" data-id="${esc(i.id)}" aria-current="${i.id===st.sel}">${ico(i.icon)}<span class="t">${esc(i.title)}</span>${i.badge?`<span class="b b-${esc(i.badge)}">${esc(i.badgeText||i.badge)}</span>`:""}<span class="s">${esc(i.sub||"")}</span></button>`).join("")+`</div>`;});
    list.innerHTML=html||`<p class="empty-note">Rien ne correspond. Essaie un autre mot.</p>`;}
  function renderDetail(){const it=items().find(i=>i.id===st.sel)||items()[0];if(!it){det.innerHTML="";return;}st.sel=it.id;
    det.innerHTML=`<button type="button" class="inv-back">↑ Retour à la liste</button>`+opt.detail(it);post(det);}
  function select(id,scroll){st.sel=id;try{localStorage.setItem("inv-"+opt.key,id);}catch(e){}renderList();renderDetail();
    if(scroll&&window.matchMedia("(max-width: 820px)").matches)det.scrollIntoView({block:"start"});}
  cats.addEventListener("click",e=>{const b=e.target.closest(".inv-cat");if(!b)return;st.cat=b.dataset.cat;renderCats();renderList();});
  list.addEventListener("click",e=>{const b=e.target.closest(".inv-item");if(b)select(b.dataset.id,true);});
  det.addEventListener("click",e=>{const g=e.target.closest("[data-goto]");if(g){e.preventDefault();select(g.dataset.goto,true);det.scrollIntoView({block:"start"});return;}
    if(e.target.closest(".inv-back"))side.scrollIntoView({block:"start"});});
  let t;search.addEventListener("input",()=>{clearTimeout(t);t=setTimeout(()=>{st.q=search.value.trim();renderList();},120);});
  st.sel=(saved&&items().some(i=>i.id===saved))?saved:(opt.first||null);
  renderCats();renderList();renderDetail();
  const api={select,refresh(){renderCats();renderList();renderDetail();}};refreshers.push(api.refresh);return api;
}

/* ---------------- HANGAR ---------------- */
const LABEL={installe:"Installé",vise:"Visé",possible:"Possible"};
const evoItems=()=>APP.ships.flatMap(s=>s.evo.map(e=>({id:"evo-"+e.id,cat:"Évolutions · "+s.short,title:e.nom,sub:e.effet,icon:e.icon,badge:HSTAT[e.id]&&HSTAT[e.id].statut||"possible",badgeText:LABEL[(HSTAT[e.id]&&HSTAT[e.id].statut)||"possible"],evo:e,ship:s,text:e.ou})));
const stOf=e=>(HSTAT[e.id]&&LABEL[HSTAT[e.id].statut])?HSTAT[e.id].statut:"possible";
const hangarItems=()=>APP.ships.map(s=>{const v=s.evo.filter(e=>stOf(e)==="vise").length,i=s.evo.filter(e=>stOf(e)==="installe").length;
  return {id:"ship-"+s.id,cat:"Vaisseaux",title:s.nom,sub:s.role,icon:s.icon,ship:s,text:s.maker+" "+s.evo.map(e=>e.nom).join(" "),badge:v?"vise":i?"installe":"",badgeText:v?v+" visé"+(v>1?"s":""):i?i+" installé"+(i>1?"s":""):""};});
const EGRP=[["Tourelles",["turret","noseturret"]],["Armes",["gatling","guns"]],["Défense",["shield"]],["Propulsion",["quantum"]],["Têtes de récupération",["head_cinch","head_trawler","head_abrade"]]];
const grpOf=e=>(EGRP.find(g=>g[1].includes(e.icon))||["Autres"])[0];
function evoCard(e,s){const k=stOf(e),note=HSTAT[e.id]&&HSTAT[e.id].note;
  return `<details class="evo-card" data-status="${k}" id="evo-${esc(e.id)}"><summary>${ico(e.icon)}<span class="t">${esc(e.nom)}</span><span class="evo-status" data-status="${k}">${LABEL[k]}</span><span class="s">${esc(e.effet)}</span></summary>
  <div class="evo-body">${imageSlot("evo-"+e.id,e.icon,e.nom)}<dl class="specs"><dt>Effet</dt><dd>${esc(e.effet)}</dd><dt>Où et combien</dt><dd>${esc(e.ou)}</dd>${note?`<dt>Note</dt><dd>${esc(note)}</dd>`:""}</dl></div></details>`;}
function evoSection(s){if(!s.evo.length)return `<h4>Systèmes d'armes et évolutions</h4><p class="muted">Aucune évolution connue.</p>`;
  const order=["installe","vise","possible"],ev=[...s.evo].sort((a,b)=>order.indexOf(stOf(a))-order.indexOf(stOf(b)));
  const counts=order.map(k=>[k,ev.filter(e=>stOf(e)===k).length]).filter(x=>x[1]);
  let h=`<h4>Systèmes d'armes et évolutions</h4><div class="evo-filter" role="group" aria-label="Filtrer par statut"><button type="button" class="inv-cat" aria-pressed="true" data-ef="tout">Tout ${ev.length}</button>${counts.map(([k,n])=>`<button type="button" class="inv-cat" aria-pressed="false" data-ef="${k}">${LABEL[k]} ${n}</button>`).join("")}</div>`;
  const groups=[...new Set(ev.map(grpOf))];
  groups.forEach(g=>{h+=`<div class="evo-group"><h5>${esc(g)}</h5>${ev.filter(e=>grpOf(e)===g).map(e=>evoCard(e,s)).join("")}</div>`;});
  return h;}
document.addEventListener("click",e=>{const b=e.target.closest("[data-ef]");if(!b)return;const root=b.closest(".inv-detail");if(!root)return;
  root.querySelectorAll("[data-ef]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
  root.querySelectorAll(".evo-card").forEach(c=>{c.hidden=b.dataset.ef!=="tout"&&c.dataset.status!==b.dataset.ef;});
  root.querySelectorAll(".evo-group").forEach(g=>{g.hidden=![...g.querySelectorAll(".evo-card")].some(c=>!c.hidden);});});
function shipDetail(it){
  if(it.ship&&!it.evo){const s=it.ship;
    return `<header class="d-head"><span class="mk">${esc(s.maker)}</span><h2>${esc(s.nom)}</h2><span class="tag">${esc(s.role)}</span></header>
    ${imageSlot("ship-"+s.id,s.icon,s.nom)}
    <p class="d-story">${esc(s.story)}</p>
    <h4>Caractéristiques</h4><dl class="specs">${s.specs.map(([a,b])=>`<dt>${esc(a)}</dt><dd>${esc(b)}</dd>`).join("")}</dl>
    ${evoSection(s)}`;}
  const e=it.evo,s=it.ship,k=(HSTAT[e.id]&&HSTAT[e.id].statut)||"possible",note=HSTAT[e.id]&&HSTAT[e.id].note;
  return `<header class="d-head"><span class="mk">Évolution · ${esc(s.nom)}</span><h2>${esc(e.nom)}</h2><span class="evo-status big" data-status="${k}">${LABEL[k]}</span></header>
  ${imageSlot("evo-"+e.id,e.icon,e.nom)}
  <dl class="specs"><dt>Effet</dt><dd>${esc(e.effet)}</dd><dt>Où et combien</dt><dd>${esc(e.ou)}</dd>${note?`<dt>Note</dt><dd>${esc(note)}</dd>`:""}</dl>
  <p><button type="button" class="btn" data-goto="ship-${esc(s.id)}">← ${esc(s.nom)}</button></p>`;
}

/* ---------------- CONTACTS ---------------- */
const contactItems=()=>[...APP.contacts.map(c=>({...c,text:c.mk})),...MET.map(m=>({id:"met-"+m.id,cat:"Rencontres",title:m.nom||"Inconnu",sub:[m.role,m.lieu].filter(Boolean).join(" · "),icon:"person",met:m}))];
function contactDetail(c){
  if(c.met){const m=c.met;return `<header class="d-head"><span class="mk">${esc([m.role,m.lieu].filter(Boolean).join(" · "))}</span><h2>${esc(m.nom)}</h2></header>${imageSlot("ct-met-"+m.id,"person",m.nom)}${m.relation?`<p class="d-story">${esc(m.relation)}</p>`:""}${m.notes?`<p>${esc(m.notes)}</p>`:""}${m.premiere?`<p class="muted">Première rencontre : ${esc(m.premiere)}</p>`:""}`;}
  return `<header class="d-head"><span class="mk">${esc(c.mk)}</span><h2>${esc(c.title)}</h2>${c.tag?`<span class="tag">${esc(c.tag)}</span>`:""}</header>${imageSlot("ct-"+c.id,c.icon,c.title)}<div class="d-html">${c.html}</div>`;
}

/* ---------------- CODEX ---------------- */
function codexDetail(c){
  if(c.html)return `<div class="d-html">${c.html}</div>`;
  return `<header class="d-head"><span class="mk">${esc(c.mk||c.cat)}</span><h2>${esc(c.title)}</h2>${c.tag?`<span class="tag">${esc(c.tag)}</span>`:""}</header>${c.where?`<p class="where">${esc(c.where)}</p>`:""}<div class="d-text">${(c.paras||[]).map(p=>`<p>${esc(p)}</p>`).join("")}</div>`;
}

/* ---------------- MAP ---------------- */
const M=APP.map;
const bodies=APP.bodies, byName={};bodies.forEach(b=>byName[b.name]=b);
const sysByName={};APP.systems.forEach(s=>sysByName[s.name]=s);
const dkS=n=>"sys-"+slug(n),dkB=n=>"b-"+slug(n);
function discRow(key,lore){if(lore)return "";const on=!!DISC[key],d=DISC[key];
  return `<div class="disc-row${on?" on":""}"><span class="disc-state">${on?"✓ Exploré par Exo":"Pas encore exploré"}${on&&d&&d.date?` · ${esc(d.date)}`:""}</span>${DB?`<button type="button" class="btn small-btn" data-disc="${esc(key)}" data-on="${on?1:0}">${on?"Retirer":"Marquer comme exploré"}</button>`:""}<span class="disc-msg" role="status"></span></div>`;}
const LORE=`<p class="lore-note">Lore · système pas encore jouable en jeu</p>`;
const row=(k,v)=>v?`<dt>${k}</dt><dd>${esc(v)}</dd>`:"";
function bodyDetail(b){const T=APP.tags;if(!b.lore)return bodyDetailP(b).replace("<!--DISC-->",discRow(dkB(b.name),false));return bodyDetailP(b);}
function bodyDetailP(b){const T=APP.tags;
  if(b.lore){const c=M.cities[b.name];return `<header class="d-head"><span class="mk">${esc(b.sys)} · ${esc(b.desig)}</span><h2>${esc(b.name)}</h2><span class="tag">${esc(b.kind)}</span></header>${LORE}
  ${c?`<p class="city">◎ ${esc(c.name)}</p>`:""}<dl class="specs">${row("Climat",b.climat)}${row("Atmosphère",b.atmo)}${row("Flore",b.flore)}</dl>${b.notes?`<p class="d-story">${esc(b.notes)}</p>`:""}
  <p><button type="button" class="btn" data-map="${b.parent?"body:"+esc(b.parent):"sys:"+esc(b.sys)}">← ${b.parent?esc(b.parent):"Système "+esc(b.sys)}</button></p>`;}
  return `<header class="d-head"><span class="mk">${esc([b.sys,b.parent].filter(Boolean).join(" › "))} · ${esc(b.desig)}</span><h2>${esc(b.name)}</h2><span class="tag">${esc(b.kind)}</span></header><!--DISC-->
  ${M.cities[b.name]?`<p class="city${M.cities[b.name].home?" home":""}">◎ ${esc(M.cities[b.name].name)}${M.cities[b.name].home?" · port d'attache d'Exo":""}</p>`:""}
  <dl class="specs">${row("Climat",b.climat)}${row("Atmosphère",b.atmo)}${row("Flore",b.flore)}${row("Faune",b.faune)}${row("Découverte",b.decouverte)}${row("Appartenance",b.faction)}</dl>${b.notes?`<p class="d-story">${esc(b.notes)}</p>`:""}
  ${b.util&&b.util.length?`<h4>Utilité</h4>`:""}<div class="utils">${b.util.map(u=>`<div class="u"><span class="tagc" style="--c:${T[u.tag].color}">${esc(T[u.tag].label)}</span><span>${esc(u.note)}</span></div>`).join("")}</div>
  ${b.poi&&b.poi!=="—"?`<p class="muted">À voir : ${esc(b.poi)}</p>`:""}`;}
function systemDetail(s){const tops=bodies.filter(b=>b.sys===s.name&&!b.parent);
  return `<header class="d-head"><span class="mk">Système</span><h2>${esc(s.name)}</h2><span class="tag">${esc(s.status)}</span></header>${discRow(dkS(s.name),s.lore)}${s.lore?`<p class="lore-note">Lore · pas encore en jeu${s.zone?" · zone : "+esc(s.zone):""}</p>`:""}
  <dl class="specs">${row("Étoile",s.star)}${row("Découverte",s.disc)}${row("Loi",s.law)}${row("Factions",s.factions)}</dl>
  ${s.note?`<p class="d-story">${esc(s.note)}</p>`:""}<h4>Corps du système</h4><div class="evo-grid">${tops.map(b=>`<button type="button" class="evo-chip" data-map="body:${esc(b.name)}">${ico("planet")}<span>${esc(b.name)}</span><span class="evo-status">${esc(b.desig)}</span>${!b.lore&&DISC[dkB(b.name)]?`<span class="chip-disc">✓</span>`:""}</button>`).join("")}</div>`;}
function grad(id,b){const p=b.planet||{base:["#888","#333"]};return `<radialGradient id="${id}" cx="35%" cy="35%" r="75%"><stop offset="0" stop-color="${p.base[0]}"/><stop offset="1" stop-color="${p.base[1]}"/></radialGradient>`;}
function planetGlyph(b,x,y,r,act,extra){const id="g-"+slug(b.name);const atmo=b.planet&&b.planet.atmo?b.planet.atmo.replace("A","0.55"):null;
  const dc=b.lore?"":DISC[dkB(b.name)]?" explored":" unexplored";
  return `<g class="node${act?" act":""}${dc}" data-pick="${esc(b.name)}" role="button" tabindex="0" aria-label="${esc(b.name)}"><defs>${grad(id,b)}</defs><circle cx="${x}" cy="${y}" r="${+r+16}" fill="transparent"/>${atmo?`<circle cx="${x}" cy="${y}" r="${r+4}" fill="none" stroke="${atmo}" stroke-width="3"/>`:""}<circle class="body" cx="${x}" cy="${y}" r="${r}" fill="url(#${id})"/>${dc===" explored"?`<circle class="disc" cx="${x}" cy="${y}" r="${+r+6}"/>`:""}<circle class="sel" cx="${x}" cy="${y}" r="${r+9}"/><text x="${x}" y="${+y+r+24}" text-anchor="middle" class="lbl">${esc(b.name)}</text>${extra||""}</g>`;}
async function toggleDisc(btn){const key=btn.dataset.disc,on=btn.dataset.on==="1",msg=btn.parentNode.querySelector(".disc-msg");if(!DB){msg.textContent="Indisponible ici.";return;}
  btn.disabled=true;try{const ref=DB.collection("decouvertes").doc(key);if(on)await ref.delete();else await ref.set({explore:true,date:new Date().toLocaleDateString("fr-FR")});}
  catch(e){btn.disabled=false;msg.textContent="Enregistrement impossible (droits d'écriture ?).";}}
function MapView(mount){
  mount.innerHTML=`<div class="map"><div class="map-bar"><nav class="crumbs" aria-label="Position sur la carte"></nav><button type="button" class="btn" data-home>◎ Lorville</button></div><div class="map-body"><div class="map-stage"><svg viewBox="0 0 1000 620" role="img" aria-label="Carte du Verse"></svg></div><p class="map-hint">← Fais glisser la carte pour voir tout le Verse →</p><aside class="map-detail" aria-live="polite"></aside></div></div>`;
  const svg=mount.querySelector("svg"),det=mount.querySelector(".map-detail"),crumbs=mount.querySelector(".crumbs");
  const st={view:"galaxy",sys:"Stanton",body:null,sel:"sys:Stanton"};
  function setDetail(){if(st.sel.startsWith("sys:"))det.innerHTML=systemDetail(sysByName[st.sel.slice(4)]);else det.innerHTML=bodyDetail(byName[st.sel]);post(det);}
  function setCrumbs(){let h=`<button type="button" data-map="galaxy">Galaxie</button>`;if(st.view!=="galaxy")h+=` › <button type="button" data-map="sys:${esc(st.sys)}">${esc(st.sys)}</button>`;if(st.view==="body")h+=` › <span>${esc(st.body)}</span>`;crumbs.innerHTML=h;}
  function stars(){let s="";let seed=7;const r=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};for(let i=0;i<160;i++)s+=`<circle cx="${(r()*1000).toFixed(1)}" cy="${(r()*620).toFixed(1)}" r="${(r()*1.3+0.3).toFixed(2)}" class="star"/>`;return s;}
  function galaxy(){const G=M.galaxy;let s=stars();
    G.links.forEach(([a,b,dash])=>{const A=G.nodes[a],B=G.nodes[b];s+=`<line x1="${A.x}" y1="${A.y}" x2="${B.x}" y2="${B.y}" class="jump${dash?" dash":""}${A.lore||B.lore?" faded":""}"/>`;});
    Object.entries(G.nodes).forEach(([n,p])=>{const act=st.sel==="sys:"+n;
      const ex=!p.lore&&DISC[dkS(n)];s+=`<g class="node sysnode${p.lore?" lore":ex?" explored":" unexplored"}${act?" act":""}" data-sys="${esc(n)}" role="button" tabindex="0" aria-label="${esc(n)}${p.lore?" (lore)":""}"><circle cx="${p.x}" cy="${p.y}" r="${p.r+14}" fill="transparent"/><circle cx="${p.x}" cy="${p.y}" r="${p.r*2.4}" fill="${p.color}" opacity=".12"/><circle class="body" cx="${p.x}" cy="${p.y}" r="${p.r}" fill="${p.color}"/>${ex?`<circle class="disc" cx="${p.x}" cy="${p.y}" r="${p.r+6}"/>`:""}<circle class="sel" cx="${p.x}" cy="${p.y}" r="${p.r+10}"/><text x="${p.x}" y="${p.y+p.r+(p.lore?18:24)}" text-anchor="middle" class="lbl ${p.lore?"small":"big"}">${esc(n)}</text></g>`;});
    const S=G.nodes.Stanton;s+=`<g class="home" data-home role="button" tabindex="0" aria-label="Lorville"><circle cx="${S.x}" cy="${S.y}" r="40" class="pulse"/><text x="${S.x}" y="${mq.matches?S.y+70:S.y-30}" text-anchor="middle" class="lbl home-l">◎ LORVILLE · PORT D'ATTACHE</text></g>`;
    s+=`<text x="20" y="600" class="lbl tiny legend">En couleur : jouable · En gris : lore, pas en jeu · Anneau cyan : exploré par Exo · Pointillé : saut provisoire</text>`;return s;}
  function system(name){const L=M.layout[name],cx=500,cy=305,ky=.6,K=1.4;let s=stars(),nodes="";
    const star=sysByName[name];s+=`<circle cx="${cx}" cy="${cy}" r="56" fill="${M.galaxy.nodes[name].color}" opacity=".15"/><circle cx="${cx}" cy="${cy}" r="24" fill="${M.galaxy.nodes[name].color}"/>`;
    Object.entries(L).forEach(([bn,o])=>{const b=byName[bn];if(!b)return;
      if(o.ring){s+=`<ellipse cx="${cx}" cy="${cy}" rx="${o.r*K}" ry="${o.r*K*ky}" class="belt"/>`;nodes+=`<g class="node ringnode${st.sel===bn?" act":""}" data-pick="${esc(bn)}" role="button" tabindex="0" aria-label="${esc(bn)}"><ellipse cx="${cx}" cy="${cy}" rx="${o.r*K}" ry="${o.r*K*ky}" class="hit"/><text x="${cx+o.r*K*Math.cos(o.la*Math.PI/180)}" y="${cy+o.r*K*ky*Math.sin(o.la*Math.PI/180)+4}" text-anchor="middle" class="lbl ring-l">${esc(bn)}</text></g>`;return;}
      if(o.special){nodes+=`<g class="node specnode${st.sel===bn?" act":""}" data-pick="${esc(bn)}" role="button" tabindex="0" aria-label="${esc(bn)}"><rect x="${o.x-70}" y="${o.y-16}" width="140" height="32" rx="2" class="spec"/><text x="${o.x}" y="${o.y+5}" text-anchor="middle" class="lbl">${esc(bn)}</text></g>`;return;}
      s+=`<ellipse cx="${cx}" cy="${cy}" rx="${o.r*K}" ry="${o.r*K*ky}" class="orbit"/>`;
      const x=cx+o.r*K*Math.cos(o.a*Math.PI/180),y=cy+o.r*K*ky*Math.sin(o.a*Math.PI/180),ps=Math.round((o.s||12)*1.35);
      const moons=bodies.filter(m=>m.parent===bn).length;
      for(let j=0;j<moons;j++){const a=(j/moons)*Math.PI*2-Math.PI/2,mr=ps+11;s+=`<circle cx="${(x+mr*Math.cos(a)).toFixed(1)}" cy="${(y+mr*Math.sin(a)).toFixed(1)}" r="2.6" class="moondot"/>`;}
      nodes+=planetGlyph(b,x.toFixed(1),y.toFixed(1),ps,st.sel===bn,moons?`<text x="${x.toFixed(1)}" y="${(y+ps+40).toFixed(1)}" text-anchor="middle" class="lbl tiny">${moons} lune${moons>1?"s":""}</text>`:"")+(M.cities[bn]&&M.cities[bn].home?`<circle cx="${x}" cy="${y}" r="${ps+18}" class="pulse"/>`:"");});
    s+=nodes;s+=`<text x="20" y="600" class="lbl tiny legend">Clique une planète pour l'ouvrir · une ceinture ou un lieu pour sa fiche</text>`;return s;}
  function body(name){const b=byName[name],moons=bodies.filter(m=>m.parent===name),cx=moons.length?400:500,cy=300,R=moons.length?120:150;let s=stars();
    moons.forEach((m,i)=>{const a=(-60+i*(240/Math.max(1,moons.length-1||1)))*Math.PI/180,mx=cx+260*Math.cos(a)+40,my=cy+200*Math.sin(a);s+=`<line x1="${cx}" y1="${cy}" x2="${mx.toFixed(1)}" y2="${my.toFixed(1)}" class="orbit"/>`;});
    s+=planetGlyph(b,cx,cy,R,st.sel===name,"");
    const c=M.cities[name];if(c){const px=cx+R*.25,py=cy-R*.2;s+=`<g class="citymark${c.home?" home":""}"><circle cx="${px}" cy="${py}" r="5"/>${c.home?`<circle cx="${px}" cy="${py}" r="16" class="pulse"/>`:""}<text x="${px+14}" y="${py-10}" class="lbl${c.home?" home-l":""}">${esc(c.name)}${c.home&&!mq.matches?" · port d'attache":""}</text></g>`;}
    moons.forEach((m,i)=>{const a=(-60+i*(240/Math.max(1,moons.length-1||1)))*Math.PI/180,mx=cx+260*Math.cos(a)+40,my=cy+200*Math.sin(a);
      s+=planetGlyph(m,mx.toFixed(1),my.toFixed(1),22,st.sel===m.name,"");});
    s+=`<text x="20" y="600" class="lbl tiny legend">${moons.length?"Clique une lune pour sa fiche":"Fiche à droite"}</text>`;return s;}
  const mq=window.matchMedia("(max-width: 700px) and (orientation: portrait)");
  const sw=(el,a,b)=>{const va=el.getAttribute(a),vb=el.getAttribute(b);if(va==null||vb==null)return;el.setAttribute(a,vb);el.setAttribute(b,va);};
  function transpose(){svg.setAttribute("viewBox","0 0 620 1000");
    [...svg.children].forEach(el=>{const t=el.tagName.toLowerCase();
      if(t==="g"){
        if(el.classList.contains("ringnode")){el.querySelectorAll("ellipse").forEach(e=>{sw(e,"cx","cy");sw(e,"rx","ry");});el.querySelectorAll("text").forEach(e=>sw(e,"x","y"));return;}
        const c=el.querySelector("circle:not(.sel)")||el.querySelector("circle"),r=el.querySelector("rect");let ax,ay;
        if(c){ax=+c.getAttribute("cx");ay=+c.getAttribute("cy");}else if(r){ax=+r.getAttribute("x")+ +r.getAttribute("width")/2;ay=+r.getAttribute("y")+ +r.getAttribute("height")/2;}else return;
        let nx=ay,ny=ax;if(r&&!c){nx=310;ny=950;r.setAttribute("x",+r.getAttribute("x")-40);r.setAttribute("width",+r.getAttribute("width")+80);}
        el.setAttribute("transform",`translate(${(nx-ax).toFixed(1)} ${(ny-ay).toFixed(1)})`);return;}
      if(t==="text"){if(el.classList.contains("legend"))el.remove();else sw(el,"x","y");return;}
      sw(el,"cx","cy");sw(el,"rx","ry");sw(el,"x1","y1");sw(el,"x2","y2");});}
  function draw(){const P=mq.matches;mount.querySelector(".map").classList.toggle("portrait",P);svg.setAttribute("viewBox","0 0 1000 620");
    svg.innerHTML=st.view==="galaxy"?galaxy():st.view==="system"?system(st.sys):body(st.body);if(P)transpose();setCrumbs();setDetail();}
  if(mq.addEventListener)mq.addEventListener("change",()=>draw());
  function go(t){if(t==="galaxy"){st.view="galaxy";st.sel="sys:"+st.sys;}else if(t.startsWith("sys:")){st.view="system";st.sys=t.slice(4);st.sel="sys:"+st.sys;}else if(t.startsWith("body:")){const n=t.slice(5),b=byName[n];st.sys=b.sys;if(bodies.some(m=>m.parent===n)||!M.layout[b.sys][n]||!(M.layout[b.sys][n].ring||M.layout[b.sys][n].special)){st.view="body";st.body=n;}else st.view="system";st.sel=n;}draw();}
  function pick(n){const b=byName[n];if(st.view==="system"&&bodies.some(m=>m.parent===n)){go("body:"+n);return;}if(st.view==="system"&&M.layout[b.sys][n]&&!M.layout[b.sys][n].ring&&!M.layout[b.sys][n].special){st.view="body";st.body=n;}st.sel=n;draw();}
  function act(t){const dz=t.closest("[data-disc]");if(dz){toggleDisc(dz);return true;}
    const g=t.closest("[data-sys],[data-pick],[data-home],[data-map]");if(!g)return false;
    if(g.dataset.home!==undefined){st.sys="Stanton";st.view="body";st.body="Hurston";st.sel="Hurston";draw();}
    else if(g.dataset.map)go(g.dataset.map);else if(g.dataset.sys){go("sys:"+g.dataset.sys);}
    else if(g.dataset.pick)pick(g.dataset.pick);return true;}
  mount.addEventListener("click",e=>{act(e.target);});
  mount.addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&act(e.target)){e.preventDefault();}});
  mount.addEventListener("dblclick",e=>{const g=e.target.closest("[data-sys]");if(g)go("sys:"+g.dataset.sys);});
  draw();refreshers.push(draw);
  const stage=mount.querySelector(".map-stage");const center=()=>{stage.scrollLeft=(stage.scrollWidth-stage.clientWidth)/2;};requestAnimationFrame(center);window.addEventListener("hashchange",()=>{if(location.hash==="#carte")requestAnimationFrame(center);});
}

/* ---------------- mount ---------------- */
MapView(document.getElementById("map-mount"));
const hangar=Inventory(document.getElementById("hangar-mount"),{key:"hangar",items:hangarItems,cats:["Vaisseaux"],detail:shipDetail,first:"ship-f7c",placeholder:"Chercher un vaisseau, une arme, un composant…"});
Inventory(document.getElementById("contacts-mount"),{key:"contacts",items:contactItems,cats:["Équipage","Connus de réputation","Rencontres"],detail:contactDetail,first:"exo",placeholder:"Chercher un nom, un lieu…"});
const codex=Inventory(document.getElementById("codex-mount"),{key:"codex",items:()=>APP.codex,cats:APP.codexCats,detail:codexDetail,first:"ch-empire",placeholder:"Chercher : Kopion, Messer, Nine Tails, imprint…"});
window.__codexSelect=id=>codex.select(id,false);

/* ---------------- data ---------------- */
(async()=>{
  const cl=window.claude;if(!cl||typeof cl.use!=="function")return;
  DB=await cl.use("db").catch(()=>null);if(!DB)return;
  ASSETS=await cl.use("assets").catch(()=>null);
  DB.collection("images").onSnapshot(s=>{const m={};s.docs.forEach(d=>{const v=d.data();if(v&&v.asset)m[d.id]=v.asset;});IMAGES=m;refreshAll();},()=>{});
  DB.collection("decouvertes").onSnapshot(s=>{const m={};s.docs.forEach(d=>{const v=d.data()||{};if(v.explore)m[d.id]=v;});DISC=m;refreshAll();},()=>{});
  DB.collection("hangar").onSnapshot(s=>{const m={};s.docs.forEach(d=>m[d.id]=d.data()||{});HSTAT=m;refreshAll();},()=>{});
  DB.collection("contacts").orderBy("ordre","asc").onSnapshot(s=>{MET=s.docs.map(d=>({id:d.id,...(d.data()||{})}));refreshAll();},()=>{});
  if(ASSETS)refreshAll();
})();
})();
