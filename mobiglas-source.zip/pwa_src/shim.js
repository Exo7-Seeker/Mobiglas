/* mobiGlas · stockage local à la place de la base claude.ai */
(function(){
  var LS="mg-overlay-v1",DATA={},listeners=[];
  var ready=fetch("data.json",{cache:"no-cache"}).then(function(r){return r.json();}).catch(function(){return {};}).then(function(d){DATA=d||{};return DATA;});
  function ov(){try{return JSON.parse(localStorage.getItem(LS)||"{}");}catch(e){return {};}}
  function saveOv(o){try{localStorage.setItem(LS,JSON.stringify(o));}catch(e){}}
  function merged(col){var base={},src=DATA[col]||{},k;for(k in src)base[k]=src[k];var o=ov()[col]||{};for(k in o){if(o[k]===null)delete base[k];else base[k]=o[k];}return base;}
  function snap(col,ord){var m=merged(col),d=Object.keys(m).map(function(id){var v=m[id];return {id:id,data:function(){return v;}};});
    if(ord)d.sort(function(a,b){var x=a.data()[ord.f],y=b.data()[ord.f];return (x>y?1:x<y?-1:0)*(ord.dir==="desc"?-1:1);});
    return {empty:!d.length,size:d.length,docs:d};}
  function fire(col){listeners.forEach(function(l){if(l.col===col)l.run();});}
  function coll(col,ord){return {
    orderBy:function(f,dir){return coll(col,{f:f,dir:dir||"asc"});},
    onSnapshot:function(cb){var l={col:col,run:function(){try{cb(snap(col,ord));}catch(e){console.error(e);}}};listeners.push(l);ready.then(function(){l.run();});return function(){};},
    get:function(){return ready.then(function(){return snap(col,ord);});},
    doc:function(id){return {
      set:function(v){var o=ov();(o[col]=o[col]||{})[id]=v;saveOv(o);fire(col);return Promise.resolve();},
      update:function(v){var cur=merged(col)[id]||{},n={},k;for(k in cur)n[k]=cur[k];for(k in v)n[k]=v[k];var o=ov();(o[col]=o[col]||{})[id]=n;saveOv(o);fire(col);return Promise.resolve();},
      delete:function(){var o=ov();(o[col]=o[col]||{})[id]=null;saveOv(o);fire(col);return Promise.resolve();}
    };}
  };}
  var db={collection:function(c){return coll(c);}};
  window.__mgDB=db;window.__mgReady=ready;
  window.__mgGet=function(col){return merged(col);};
  window.__mgOverlay=function(){return ov();};
  window.__mgClaude={use:function(n){return ready.then(function(){return n==="db"?db:null;});}};
})();
