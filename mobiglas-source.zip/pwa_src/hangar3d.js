/* Hangar : hologrammes 3D importés une fois depuis le téléphone, gardés dans le téléphone (jamais sur GitHub) */
(function(){
  var mount=document.getElementById("hangar-mount");if(!mount||!window.indexedDB)return;
  var SHIPS={vulture:"Drake Vulture",f7c:"F7C Hornet Mk II",corsair:"Drake Corsair",pulse:"Mirai Pulse"};
  function idOf(name){var n=String(name).toLowerCase();if(/vulture/.test(n))return "vulture";if(/f7c|hornet/.test(n))return "f7c";if(/corsair/.test(n))return "corsair";if(/pulse/.test(n))return "pulse";return null;}
  var dbp=new Promise(function(res,rej){var r=indexedDB.open("mg-holo",1);r.onupgradeneeded=function(){r.result.createObjectStore("m");};r.onsuccess=function(){res(r.result);};r.onerror=function(){rej(r.error);};});
  function tx(mode,fn){return dbp.then(function(db){return new Promise(function(res,rej){var t=db.transaction("m",mode),st=t.objectStore("m"),out=fn(st);t.oncomplete=function(){res(out&&out.result!==undefined?out.result:out);};t.onerror=function(){rej(t.error);};});});}
  function get(id){return tx("readonly",function(st){return st.get(id);});}
  function put(id,buf){return tx("readwrite",function(st){st.put(buf,id);});}
  function keys(){return tx("readonly",function(st){return st.getAllKeys();});}
  /* barre d'import en haut du Hangar */
  var bar=document.createElement("div");bar.className="h3d-bar";bar.innerHTML='<span class="h3d-st">Hologrammes 3D</span><button type="button">Importer les fichiers .holo</button><input type="file" accept=".holo,application/octet-stream" multiple hidden>';
  mount.parentNode.insertBefore(bar,mount);
  var btn=bar.querySelector("button"),fi=bar.querySelector("input"),stEl=bar.querySelector(".h3d-st");
  function status(){keys().then(function(k){k=k||[];stEl.textContent=k.length?"Hologrammes installés : "+k.map(function(x){return SHIPS[x]||x;}).join(", "):"Hologrammes 3D : aucun installé";btn.textContent=k.length?"Ajouter / remplacer":"Importer les fichiers .holo";}).catch(function(){});}
  btn.addEventListener("click",function(){fi.click();});
  fi.addEventListener("change",function(){var fs=[].slice.call(fi.files||[]),done=[],bad=[];
    Promise.all(fs.map(function(f){var id=idOf(f.name);if(!id){bad.push(f.name);return null;}return f.arrayBuffer().then(function(b){var h=String.fromCharCode.apply(null,new Uint8Array(b,0,4));if(h!=="HOLO"){bad.push(f.name);return;}return put(id,b).then(function(){done.push(SHIPS[id]);});});}))
      .then(function(){stEl.textContent=(done.length?"Installé : "+done.join(", "):"Rien installé")+(bad.length?" · ignoré : "+bad.join(", "):"");if(window.mgFx)mgFx.open();fi.value="";setTimeout(status,2500);inject(true);});});
  status();
  /* hologramme en tête de la fiche du vaisseau */
  var cur=null;
  function inject(force){var sel=mount.querySelector('.inv-item[aria-current="true"]'),id=sel&&sel.dataset.id,m=id&&/^ship-(\w+)$/.exec(id),det=mount.querySelector(".inv-detail");if(!det)return;
    var have=det.querySelector(".h3d");if(!m){cur=null;return;}var sid=m[1];if(have&&cur===sid&&!force)return;
    get(sid).then(function(buf){if(!buf)return;var head=det.querySelector(".d-head");if(!head)return;var old=det.querySelector(".h3d-wrap");if(old)old.remove();
      var w=document.createElement("div");w.className="h3d-wrap";head.insertAdjacentElement("afterend",w);var el=document.createElement("div");w.appendChild(el);cur=sid;window.mgHolo3D(el,buf,SHIPS[sid]||sid);
      var img=det.querySelector(".slot,.img-slot,figure");if(img&&img!==w)img.classList.add("h3d-after");}).catch(function(){});}
  new MutationObserver(function(){setTimeout(function(){inject(false);},30);}).observe(mount,{childList:true,subtree:true});
  window.addEventListener("hashchange",function(){if(location.hash==="#hangar")setTimeout(function(){inject(false);},80);});
})();
