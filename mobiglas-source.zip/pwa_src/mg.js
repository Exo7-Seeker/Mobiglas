/* mobiGlas · démarrage, étoiles, sons, vibrations, transitions */
(function(){
  var SET=function(k,d){try{var v=localStorage.getItem("mg-"+k);return v===null?d:v==="1";}catch(e){return d;}};
  window.mgSettings={sound:SET("sound",true),vibe:SET("vibe",true),voice:SET("voice",true)};
  window.mgSave=function(k,v){window.mgSettings[k]=v;try{localStorage.setItem("mg-"+k,v?"1":"0");}catch(e){}};

  /* --- sons synthétisés (aucun fichier) --- */
  var AC=null;function vib(p){try{if(mgSettings.vibe&&navigator.vibrate&&(!navigator.userActivation||navigator.userActivation.hasBeenActive))navigator.vibrate(p);}catch(e){}}window.mgVib=vib;
  function ac(){if(!AC){var C=window.AudioContext||window.webkitAudioContext;if(!C)return null;AC=new C();}if(AC.state==="suspended")AC.resume();return AC;}
  function tone(f,d,type,vol,when,slide){var a=ac();if(!a)return;var t=a.currentTime+(when||0),o=a.createOscillator(),g=a.createGain();
    o.type=type||"sine";o.frequency.setValueAtTime(f,t);if(slide)o.frequency.exponentialRampToValueAtTime(slide,t+d);
    g.gain.setValueAtTime(0.0001,t);g.gain.exponentialRampToValueAtTime(vol||0.05,t+0.01);g.gain.exponentialRampToValueAtTime(0.0001,t+d);
    o.connect(g);g.connect(a.destination);o.start(t);o.stop(t+d+0.02);}
  window.mgFx={
    tick:function(){if(mgSettings.sound)tone(1800,0.04,"square",0.018);vib(8);},
    open:function(){if(mgSettings.sound){tone(520,0.09,"sine",0.04);tone(1040,0.12,"sine",0.03,0.06);}vib(12);},
    boot:function(){if(!mgSettings.sound)return;tone(180,0.6,"sawtooth",0.025,0,420);tone(660,0.18,"sine",0.05,0.5);tone(990,0.3,"sine",0.04,0.66);},
    seeker:function(){if(mgSettings.sound){tone(300,0.12,"triangle",0.05);tone(450,0.16,"triangle",0.04,0.1);}vib([10,40,10]);},
    beep:function(){if(mgSettings.sound)tone(880,0.08,"square",0.03);}
  };
  document.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest("button,a.tab,.inv-item,.ml-it,.evo-chip,.site-chip,summary");if(b&&!b.closest("#mg-boot"))mgFx.tick();},true);

  /* --- icônes des onglets --- */
  var TI={seeker:'<rect x="5.5" y="4" width="13" height="13" stroke="#ff5a5a" opacity=".7"/><rect x="4" y="5" width="13" height="13"/><circle cx="10.5" cy="11.5" r="2.5" fill="currentColor"/>',
    carte:'<circle cx="12" cy="12" r="8"/><ellipse cx="12" cy="12" rx="11" ry="3.5"/>',hangar:'<path d="M12 3 L15 11 L22 14 L22 16 L15 15 L14 20 L10 20 L9 15 L2 16 L2 14 L9 11 Z"/>',
    journal:'<path d="M4 4h11l5 5v11H4z M15 4v5h5 M8 13h8 M8 17h6"/>',cap:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 1v5M12 18v5M1 12h5M18 12h5"/>',
    codex:'<path d="M12 6 Q8 3 3 4 V19 Q8 18 12 21 Q16 18 21 19 V4 Q16 3 12 6 Z M12 6 V21"/>',contacts:'<circle cx="12" cy="8" r="4"/><path d="M4 21 C5 15 19 15 20 21"/>',
    spectrum:'<path d="M3 12h3l2-6 4 12 3-9 2 3h4"/>'};
  function tabIcons(){document.querySelectorAll("a.tab[data-tab]").forEach(function(a){if(a.querySelector(".ti"))return;var p=TI[a.dataset.tab];if(!p)return;a.insertAdjacentHTML("afterbegin",'<svg class="ti" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true">'+p+'</svg>');});}
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",tabIcons);else tabIcons();

  /* --- fond étoilé avec parallaxe --- */
  var cv=document.createElement("canvas");cv.id="mg-stars";cv.setAttribute("aria-hidden","true");document.body.prepend(cv);
  var ctx=cv.getContext("2d"),stars=[],W=0,H=0,dpr=Math.min(2,window.devicePixelRatio||1);
  function seed(){W=window.innerWidth;H=window.innerHeight;cv.width=W*dpr;cv.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);stars=[];
    var n=Math.round(W*H/2600),s=7;function r(){s=(s*16807)%2147483647;return s/2147483647;}
    for(var i=0;i<n;i++)stars.push({x:r()*W,y:r()*H*3,z:r()<.15?2:r()<.5?1:0,a:.25+r()*.6,tw:r()*6});}
  var glowC=null,lastP=0;
  function glowLayer(){glowC=document.createElement("canvas");glowC.width=cv.width;glowC.height=cv.height;var g2=glowC.getContext("2d");g2.setTransform(dpr,0,0,dpr,0,0);
    var g=g2.createRadialGradient(W*.7,H*.15,0,W*.7,H*.15,H*.9);g.addColorStop(0,"rgba(8,50,74,.55)");g.addColorStop(1,"rgba(2,10,16,0)");g2.fillStyle=g;g2.fillRect(0,0,W,H);}
  function paint(t){requestAnimationFrame(paint);if(document.hidden||t-lastP<33)return;lastP=t;var sy=window.scrollY||0;ctx.clearRect(0,0,W,H);
    if(!glowC)glowLayer();ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(glowC,0,0);ctx.restore();
    for(var i=0;i<stars.length;i++){var st=stars[i],k=[.04,.12,.28][st.z],y=((st.y-sy*k)%(H*3)+H*3)%(H*3);if(y>H)continue;
      var a=st.a*(0.75+0.25*Math.sin(t/900+st.tw));ctx.fillStyle="rgba(214,247,251,"+a.toFixed(3)+")";var sz=[.7,1.1,1.6][st.z];ctx.fillRect(st.x,y,sz,sz);}}
  seed();var rsT=null;window.addEventListener("resize",function(){clearTimeout(rsT);rsT=setTimeout(function(){if(window.innerWidth!==W||window.innerHeight>H*1.2||window.innerHeight<H*0.6){seed();glowC=null;}},150);});requestAnimationFrame(paint);

  /* --- scintillement au changement d'appli --- */
  window.addEventListener("hashchange",function(){setTimeout(function(){var p=document.querySelector(".tab-panel:not([hidden])");if(!p)return;p.classList.remove("mg-flick");void p.offsetWidth;p.classList.add("mg-flick");mgFx.open();},0);});

  /* --- texte de Seeker lettre par lettre dans le journal --- */
  var typed=new WeakSet();
  function typeLine(p){if(typed.has(p))return;typed.add(p);var tn=p.firstChild;if(!tn||tn.nodeType!==3)return;var full=tn.nodeValue,i=0;tn.nodeValue="";
    var caret=document.createElement("span");caret.className="tw-caret";p.insertBefore(caret,tn.nextSibling);
    (function step(){i+=2;tn.nodeValue=full.slice(0,i);if(i<full.length)setTimeout(step,22);else setTimeout(function(){caret.remove();},1600);})();}
  var io=("IntersectionObserver" in window)?new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){io.unobserve(e.target);typeLine(e.target);}});},{threshold:.4}):null;
  function watch(){document.querySelectorAll(".voice-line").forEach(function(p){if(!typed.has(p)){if(io)io.observe(p);else typeLine(p);}});}
  new MutationObserver(watch).observe(document.body,{childList:true,subtree:true});setTimeout(watch,500);

  /* --- séquence de démarrage --- */
  function boot(){
    var seen=false;try{seen=sessionStorage.getItem("mg-booted")==="1";}catch(e){}
    if(seen)return;try{sessionStorage.setItem("mg-booted","1");}catch(e){}
    var el=document.createElement("div");el.id="mg-boot";el.setAttribute("role","dialog");el.setAttribute("aria-label","Démarrage mobiGlas");
    el.innerHTML='<div class="b-top"><span>mobiGlas OS 4.2</span><span>Lien biométrique</span></div>'+
      '<div class="b-mid"><svg width="170" height="170" viewBox="0 0 170 170" aria-hidden="true" fill="none"><polygon points="85,6 154,45 154,125 85,164 16,125 16,45" stroke="#2aa9c4" stroke-width="1" opacity=".6"/><polygon points="85,26 137,55 137,115 85,144 33,115 33,55" stroke="#5fe3f0" stroke-width="1.5"/><g class="spin"><circle cx="85" cy="85" r="34" stroke="#5fe3f0" stroke-width="1" stroke-dasharray="3 5"/><path d="M85 51 A34 34 0 0 1 119 85" stroke="#fff" stroke-width="2"/></g><path d="M70 85 h30 M85 70 v30" stroke="#5fe3f0" stroke-width="1"/></svg>'+
      '<div><div class="b-user">Utilisateur</div><div class="b-name">Exo</div></div></div>'+
      '<div><div class="b-log" aria-live="polite"></div><div class="b-bar">'+new Array(17).join("<i></i>")+'</div><div class="b-go">Touche pour ouvrir</div></div>';
    document.body.appendChild(el);
    var log=el.querySelector(".b-log"),bars=el.querySelectorAll(".b-bar i"),lines=[
      ["Synchronisation imprint","OK","ok"],["Localisation","LORVILLE / HURSTON","ok"],["Journal de bord","chargé","ok"],["Carte stellaire","23 systèmes","ok"],["Processus non déclaré","SEEKER","warn"]];
    var i=0,b=0;
    var bi=setInterval(function(){if(b<bars.length){bars[b].classList.add("on");b++;}else clearInterval(bi);},110);
    (function next(){if(i>=lines.length){el.querySelector(".b-name").classList.add("on");setTimeout(function(){el.querySelector(".b-go").classList.add("on");},500);return;}
      var L=lines[i],d=document.createElement("div");d.innerHTML="&gt; "+L[0]+" … <span class='"+L[2]+"'>"+L[1]+"</span>";log.appendChild(d);i++;setTimeout(next,320);})();
    function close(){mgFx.boot();vib([15,60,25]);el.classList.add("out");setTimeout(function(){el.remove();},600);}
    el.addEventListener("click",close,{once:true});
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();

  /* --- appli installable --- */
  if("serviceWorker" in navigator&&location.protocol==="https:")window.addEventListener("load",function(){navigator.serviceWorker.register("sw.js").catch(function(){});});
})();
