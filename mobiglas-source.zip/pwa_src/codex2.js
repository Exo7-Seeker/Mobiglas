/* Codex pensé pour le téléphone : accueil en tuiles, catégories adaptées, fiche plein écran, recherche partout */
(function(){
  var panel=document.getElementById("tab-codex");if(!panel)return;
  var A=window.__APP||{},ALL=(A.codex||[]).slice(),CATS=A.codexCats||[];
  var esc=function(t){return String(t==null?"":t).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});};
  var norm=function(s){return String(s||"").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"");};
  function textOf(e){if(e.text)return e.text;var d=document.createElement("div");d.innerHTML=e.html||"";return d.textContent.replace(/\s+/g," ");}
  ALL.forEach(function(e){e._t=norm(e.title+" "+(e.sub||"")+" "+textOf(e));});

  /* ---------- photos : wiki Star Citizen (recherche par sujet, gardée en mémoire) ---------- */
  var Q={"ch-empire":"United Empire of Earth","Terriens de Sol":"Earth","Terrans":"Terra","Gens de Stanton":"Stanton system","Gens de Pyro":"Pyro system","Peuple de Levski":"Levski","Citoyens et Civils":"Citizenship","Hadesiens":"Hadesian","Aéroplancton et kiami":"Crusader","Savane dégradée":"Hurston","Forêts et toundra enneigées":"microTech","Flore de fournaise":"Pyro I","Navy, Marines, Army":"UEE Navy","Sénat":"Senate","Foxwell, Northrock":"Foxwell Enforcement","73R Vipers, Fire Rats":"Fire Rats","Repaires du Keeger Belt":"Keeger Belt","Imperator":"Imperator"};
  var HQ={"Stanton, le système à vendre":"Stanton system","Hurston, la planète-usine":"Hurston","Lorville":"Lorville","Les ombres sur Stanton":"Nine Tails","Au-delà des points de saut":"Pyro system"};
  function query(e){return Q[e.id]||Q[e.title]||HQ[e.title]||e.title;}
  var IC={};try{IC=JSON.parse(localStorage.getItem("mg-cx-img")||"{}");}catch(_){}
  function saveIC(){try{localStorage.setItem("mg-cx-img",JSON.stringify(IC));}catch(_){}}
  var pending={};
  function photo(q){if(IC[q]!==undefined)return Promise.resolve(IC[q]);if(pending[q])return pending[q];
    pending[q]=fetch("https://starcitizen.tools/api.php?format=json&origin=*&action=query&generator=search&gsrlimit=3&gsrsearch="+encodeURIComponent(q)+"&prop=pageimages&piprop=thumbnail&pithumbsize=720")
      .then(function(r){return r.json();}).then(function(d){var p=d.query&&d.query.pages,best=null,bi=99;for(var k in p)if(p[k].thumbnail&&(p[k].index||9)<bi){bi=p[k].index||9;best=p[k].thumbnail.source;}IC[q]=best||"";saveIC();return IC[q];})
      .catch(function(){return "";});return pending[q];}
  function fillImg(el,q,fallback){var set=function(u){if(u){el.style.backgroundImage="url('"+u.replace(/'/g,"%27")+"')";el.classList.add("on");}else if(fallback)el.style.backgroundImage="url('"+fallback+"')";};photo(q).then(set);}
  var W=window.__WIKI||{};function wk(f){return W[f]?W[f].thumb:"";}
  var TILE={"Histoire et lieux":{f:"Lorville-buildings-3.19-CIG.jpg"},"Peuples":{f:"Lorville-workers-district-leavsden-square01-3.4.1.jpg"},"Faune":{q:"Kopion"},"Flore":{q:"Hurston"},"Factions":{q:"Hurston Dynamics"},"Lexique":{f:"Quantum_Drive_Travel.png"}};

  /* ---------- « vu en jeu » : sujets croisés dans le journal ---------- */
  function seenSet(){var J=window.__mgGet?__mgGet("journal"):{},txt=[];for(var k in J)txt.push((J[k].paragraphes||[]).join(" "),J[k].titre||"",J[k].lieu||"");
    var lede=document.querySelector("#tab-journal .lede"),passe=document.querySelector("#passe");if(lede)txt.push(lede.textContent);if(passe)txt.push(passe.textContent);
    var T=norm(txt.join(" ")),S={};ALL.forEach(function(e){var keys=e.title.split(/,| et /).map(function(s){return norm(s.trim());}).filter(function(s){return s.length>3;});if(keys.some(function(k){return T.indexOf(k)>=0;}))S[e.id]=1;});return S;}
  var SEEN={};

  /* ---------- carte et Seeker ---------- */
  function placeOf(e){var n=e.title,a=window.__APP||{};var f=function(l){return (l||[]).find(function(x){return norm(x.name)===norm(n);});};
    if(f(a.places))return {k:"place",n:f(a.places).name};if(f(a.bodies))return {k:"body",n:f(a.bodies).name};if(f(a.systems))return {k:"sys",n:f(a.systems).name};return null;}
  function showOnMap(p){location.hash="carte";setTimeout(function(){if(!window.__map)return;if(p.k==="place")__map.place(p.n);else if(p.k==="body")__map.go("body:"+p.n);else __map.go("sys:"+p.n);},120);}
  function askSeeker(e){location.hash="seeker";setTimeout(function(){var i=document.getElementById("sk-input");if(i){i.value="Seeker, parle-moi de "+e.title;i.focus();}},150);}

  /* ---------- structure ---------- */
  [].slice.call(panel.children).forEach(function(c){c.classList.add("cx-hide");});
  var root=document.createElement("div");root.className="cx";panel.appendChild(root);
  root.innerHTML='<div class="cx-top"><div class="cx-search"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input type="text" enterkeyhint="search" placeholder="Chercher dans le Codex" aria-label="Chercher dans le Codex"><button type="button" class="cx-clear" aria-label="Effacer" hidden>✕</button></div></div><div class="cx-body"></div>';
  var body=root.querySelector(".cx-body"),inp=root.querySelector("input"),clr=root.querySelector(".cx-clear");
  var ov=document.createElement("div");ov.className="cx-fiche";ov.hidden=true;panel.appendChild(ov);
  var state={v:"home"};

  function card(e,big){var s=SEEN[e.id]?'<span class="cx-seen">Vu en jeu</span>':"";
    return '<button type="button" class="cx-card'+(big?" big":"")+(SEEN[e.id]?"":" unseen")+'" data-id="'+esc(e.id)+'"><span class="cx-img" data-q="'+esc(query(e))+'"></span><span class="cx-ct"><span class="cx-t">'+esc(e.title)+'</span><span class="cx-s">'+esc(e.sub||"")+'</span>'+s+'</span></button>';}
  function hydrate(){[].slice.call(body.querySelectorAll(".cx-img[data-q]")).forEach(function(el){if(el._h)return;el._h=1;fillImg(el,el.dataset.q,"");});}

  function home(){var h='<div class="cx-intro">L\'univers de 2956, rangé par sujet.</div><div class="cx-tiles">';
    CATS.forEach(function(c){var n=ALL.filter(function(e){return e.cat===c;}).length,t=TILE[c]||{};h+='<button type="button" class="cx-tile" data-cat="'+esc(c)+'"><span class="cx-img"'+(t.f?' style="background-image:url(\''+wk(t.f)+'\')"':' data-q="'+esc(t.q||c)+'"')+'></span><span class="cx-tl"><b>'+esc(c)+'</b><i>'+n+' fiches</i></span></button>';});
    body.innerHTML=h+'</div>';hydrate();}
  function category(c){var list=ALL.filter(function(e){return e.cat===c;}),h='<button type="button" class="cx-back" data-back>‹ Codex</button><h2 class="cx-h">'+esc(c)+'</h2>';
    if(c==="Lexique"){var L={};list.sort(function(a,b){return norm(a.title)<norm(b.title)?-1:1;}).forEach(function(e){var l=norm(e.title).charAt(0).toUpperCase();if(!/[A-Z]/.test(l))l="#";(L[l]=L[l]||[]).push(e);});
      var ks=Object.keys(L);h+='<nav class="cx-az">'+ks.map(function(k){return '<button type="button" data-az="'+k+'">'+k+'</button>';}).join("")+'</nav><div class="cx-lex">';
      ks.forEach(function(k){h+='<div class="cx-letter" id="cx-l-'+k+'">'+k+'</div>';L[k].forEach(function(e){h+='<details class="cx-term'+(SEEN[e.id]?" seen":"")+'"><summary><span>'+esc(e.title)+'</span><i>'+esc(e.sub||"")+'</i></summary><div class="cx-def">'+(e.paras?e.paras.map(function(p){return "<p>"+esc(p)+"</p>";}).join(""):e.html||"")+'</div></details>';});});
      body.innerHTML=h+'</div>';return;}
    if(c==="Factions"){var G={};list.forEach(function(e){(G[e.sub||"Autres"]=G[e.sub||"Autres"]||[]).push(e);});
      Object.keys(G).forEach(function(g){h+='<div class="cx-group">'+esc(g)+'</div><div class="cx-list">'+G[g].map(function(e){return card(e);}).join("")+'</div>';});body.innerHTML=h;hydrate();return;}
    var grid=(c==="Peuples"||c==="Faune"||c==="Flore");
    h+='<div class="'+(grid?"cx-grid":"cx-list")+'">'+list.map(function(e){return card(e,grid);}).join("")+'</div>';body.innerHTML=h;hydrate();}
  function results(q){var t=norm(q),hits=ALL.filter(function(e){return e._t.indexOf(t)>=0;}).sort(function(a,b){return (norm(a.title).indexOf(t)>=0?0:1)-(norm(b.title).indexOf(t)>=0?0:1);});
    if(!hits.length){body.innerHTML='<div class="cx-empty">Aucune fiche pour « '+esc(q)+' ». Demande à Seeker : il cherchera dans la base Star Citizen.</div>';return;}
    var h="";CATS.forEach(function(c){var g=hits.filter(function(e){return e.cat===c;});if(g.length)h+='<div class="cx-group">'+esc(c)+' · '+g.length+'</div><div class="cx-list">'+g.slice(0,30).map(function(e){return card(e);}).join("")+'</div>';});body.innerHTML=h;hydrate();}

  function related(e){var me=norm(e.title),t=e._t;return ALL.filter(function(o){if(o===e||o.cat==="Lexique")return false;var k=norm(o.title.split(",")[0]);return k.length>3&&(t.indexOf(k)>=0||o._t.indexOf(me)>=0);}).slice(0,8);}
  function fiche(e){
    var d=document.createElement("div");d.innerHTML=e.html||(e.paras||[]).map(function(p){return "<p>"+esc(p)+"</p>";}).join("");
    [].slice.call(d.querySelectorAll(".frame,canvas,.log")).forEach(function(x){x.remove();});
    [].slice.call(d.querySelectorAll("h2")).forEach(function(x,i){if(i===0)x.remove();});
    var p=placeOf(e),rel=related(e);
    ov.innerHTML='<div class="cx-ftop"><button type="button" class="cx-back" data-back>‹ Retour</button><span>'+esc(e.cat)+'</span></div><div class="cx-fscroll">'+
      '<div class="cx-hero"><span class="cx-img" data-q="'+esc(query(e))+'"></span></div>'+
      '<div class="cx-fhead">'+(SEEN[e.id]?'<span class="cx-seen">Vu en jeu</span>':"")+'<h2>'+esc(e.title)+'</h2><div class="cx-s">'+esc(e.sub||"")+'</div></div>'+
      '<div class="cx-actions">'+(p?'<button type="button" data-map>◎ Voir sur la carte</button>':"")+'<button type="button" data-ask>Demander à Seeker</button></div>'+
      '<div class="cx-ftext">'+d.innerHTML+'</div>'+
      (rel.length?'<div class="cx-group">Voir aussi</div><div class="cx-chips">'+rel.map(function(o){return '<button type="button" data-id="'+esc(o.id)+'">'+esc(o.title)+'</button>';}).join("")+'</div>':"")+'</div>';
    ov.style.top=Math.max(0,panel.getBoundingClientRect().top)+"px";ov.hidden=false;ov.classList.remove("in");void ov.offsetWidth;ov.classList.add("in");
    ov.querySelector(".cx-fscroll").scrollTop=0;
    var im=ov.querySelector(".cx-hero .cx-img"),t=TILE[e.cat]||{};fillImg(im,query(e),t.f?wk(t.f):"");
    if(window.__linkTerms)try{__linkTerms(ov.querySelector(".cx-ftext"));}catch(_){}
    ov.onclick=function(ev){var b=ev.target.closest("button");if(!b)return;if(b.hasAttribute("data-map")){showOnMap(p);}else if(b.hasAttribute("data-ask")){askSeeker(e);}else if(b.dataset.id){go({v:"fiche",id:b.dataset.id});}else if(b.hasAttribute("data-back"))history.back();};
    if(window.mgFx)mgFx.open();}

  /* ---------- navigation avec le bouton retour du téléphone ---------- */
  function render(s){state=s;SEEN=seenSet();if(s.v==="fiche"){var e=ALL.find(function(x){return x.id===s.id;});if(e){if(s.under)renderUnder(s.under);fiche(e);return;}}
    ov.hidden=true;renderUnder(s);}
  function renderUnder(s){if(s.v==="cat")category(s.c);else if(s.v==="search")results(s.q);else home();}
  function go(s){if(s.v==="fiche"&&state.v!=="fiche")s.under=state;else if(s.v==="fiche")s.under=state.under;history.pushState({cx:s},"","#codex");render(s);if(s.v!=="fiche")window.scrollTo(0,panel.offsetTop-10);}
  window.addEventListener("popstate",function(ev){if(location.hash!=="#codex")return;var s=ev.state&&ev.state.cx;render(s||{v:"home"});});
  window.addEventListener("hashchange",function(){if(location.hash!=="#codex")ov.hidden=true;});

  body.addEventListener("click",function(ev){var b=ev.target.closest("button");if(!b)return;
    if(b.dataset.cat)go({v:"cat",c:b.dataset.cat});else if(b.dataset.id)go({v:"fiche",id:b.dataset.id});else if(b.hasAttribute("data-back"))history.back();
    else if(b.dataset.az){var t=document.getElementById("cx-l-"+b.dataset.az);if(t)window.scrollTo({top:t.getBoundingClientRect().top+window.scrollY-110,behavior:"smooth"});}});
  var st=null;inp.addEventListener("input",function(){clr.hidden=!inp.value;clearTimeout(st);st=setTimeout(function(){var q=inp.value.trim();if(q.length>=2){if(state.v==="search")history.replaceState({cx:{v:"search",q:q}},"","#codex");else history.pushState({cx:{v:"search",q:q}},"","#codex");render({v:"search",q:q});}else if(!q&&state.v==="search")history.back();},180);});
  clr.addEventListener("click",function(){inp.value="";clr.hidden=true;if(state.v==="search")history.back();});
  window.__codexSelect=function(id){go({v:"fiche",id:id});};
  (window.__mgReady||Promise.resolve()).then(function(){SEEN=seenSet();home();});
})();
