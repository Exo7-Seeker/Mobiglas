/* Illustrations générées en plus (aucune image officielle) */
(function(){
  var S=window.__scenes,K=window.__kit;if(!S||!K)return;
  var rng=K.rng,bg=K.bg,stars=K.stars,glow=K.glow,nebula=K.nebula,planet=K.planet;
  function lin(ctx,x0,y0,x1,y1,stops){var g=ctx.createLinearGradient(x0,y0,x1,y1);stops.forEach(function(s){g.addColorStop(s[0],s[1]);});return g;}
  function haze(ctx,w,h,y,c){ctx.fillStyle=lin(ctx,0,y-h*.2,0,y+h*.2,[[0,"rgba(0,0,0,0)"],[.5,c],[1,"rgba(0,0,0,0)"]]);ctx.fillRect(0,y-h*.2,w,h*.4);}

  /* cockpit : approche de Hurston, verrière et HUD */
  S.cockpit=function(ctx,w,h){var r=rng(301);bg(ctx,w,h,"#05070b","#0b0f16");stars(ctx,w,h,r,Math.round(w*.4));
    planet(ctx,{x:w*.62,y:h*1.25,r:w*.75,base:["#b89a78","#4e3a2c"],bands:{n:14,colors:["#8c6f55","#d1b590","#6d5a48"]},atmo:"rgba(230,180,120,A)",light:-2.2,seed:5});
    ctx.fillStyle="#04070a";ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(w*.16,0);ctx.lineTo(w*.06,h*.75);ctx.lineTo(w*.3,h);ctx.lineTo(0,h);ctx.fill();
    ctx.beginPath();ctx.moveTo(w,0);ctx.lineTo(w*.84,0);ctx.lineTo(w*.94,h*.75);ctx.lineTo(w*.7,h);ctx.lineTo(w,h);ctx.fill();
    ctx.fillStyle=lin(ctx,0,h*.78,0,h,[[0,"#0a1218"],[1,"#020406"]]);ctx.beginPath();ctx.moveTo(w*.06,h*.8);ctx.quadraticCurveTo(w*.5,h*.7,w*.94,h*.8);ctx.lineTo(w,h);ctx.lineTo(0,h);ctx.fill();
    ctx.strokeStyle="rgba(95,227,240,.75)";ctx.lineWidth=1.2;var cx=w*.5,cy=h*.42;ctx.beginPath();ctx.arc(cx,cy,h*.08,0,Math.PI*2);ctx.stroke();
    ctx.beginPath();ctx.moveTo(cx-h*.2,cy);ctx.lineTo(cx-h*.1,cy);ctx.moveTo(cx+h*.1,cy);ctx.lineTo(cx+h*.2,cy);ctx.stroke();
    for(var i=0;i<6;i++){var y=cy-h*.2+i*h*.08;ctx.beginPath();ctx.moveTo(w*.24,y);ctx.lineTo(w*.27,y);ctx.moveTo(w*.73,y);ctx.lineTo(w*.76,y);ctx.stroke();}
    ctx.fillStyle="rgba(255,179,71,.9)";ctx.font="600 "+Math.round(h*.04)+"px monospace";ctx.fillText("ATC TEASA · VOIE 03",w*.36,h*.86);
    ctx.fillStyle="rgba(95,227,240,.85)";ctx.fillText("ALT 12 400 m",w*.18,h*.93);ctx.fillText("SCM 180",w*.68,h*.93);};

  /* saut quantique */
  S.qt=function(ctx,w,h){var r=rng(302);bg(ctx,w,h,"#020610","#05101c");var cx=w*.5,cy=h*.48;
    for(var i=0;i<260;i++){var a=r()*Math.PI*2,d0=r()*w*.05+w*.02,d1=d0+w*(.15+r()*.6),c=r()<.3?"rgba(255,200,140,":"rgba(140,220,255,";
      ctx.strokeStyle=c+(.15+r()*.6).toFixed(2)+")";ctx.lineWidth=.5+r()*1.4;ctx.beginPath();ctx.moveTo(cx+Math.cos(a)*d0,cy+Math.sin(a)*d0*.6);ctx.lineTo(cx+Math.cos(a)*d1,cy+Math.sin(a)*d1*.6);ctx.stroke();}
    glow(ctx,cx,cy,w*.12,"rgba(170,230,255,A)",.9);glow(ctx,cx,cy,w*.04,"rgba(255,255,255,A)",1);
    ctx.fillStyle="#03060a";ctx.beginPath();ctx.moveTo(cx-w*.12,h);ctx.lineTo(cx-w*.04,h*.8);ctx.lineTo(cx+w*.04,h*.8);ctx.lineTo(cx+w*.12,h);ctx.fill();
    ctx.fillStyle="rgba(120,220,255,.9)";ctx.beginPath();ctx.arc(cx-w*.03,h*.82,2.5,0,7);ctx.arc(cx+w*.03,h*.82,2.5,0,7);ctx.fill();};

  /* hôpital : couloir de soins */
  S.hopital=function(ctx,w,h){var r=rng(303);ctx.fillStyle=lin(ctx,0,0,0,h,[[0,"#0d1a20"],[1,"#050a0d"]]);ctx.fillRect(0,0,w,h);
    var vx=w*.5,vy=h*.45;ctx.strokeStyle="rgba(150,230,240,.18)";ctx.lineWidth=1;
    for(var i=0;i<10;i++){var t=i/10;ctx.beginPath();ctx.moveTo(vx+(0-vx)*t,vy+(h-vy)*t);ctx.lineTo(vx+(w-vx)*t,vy+(h-vy)*t);ctx.stroke();}
    [[0,0],[w,0],[0,h],[w,h]].forEach(function(p){ctx.beginPath();ctx.moveTo(vx,vy);ctx.lineTo(p[0],p[1]);ctx.stroke();});
    for(var k=0;k<5;k++){var s=Math.pow(.62,k),y=vy-(vy)*s*.85,lw=w*.32*s;ctx.fillStyle="rgba(200,250,255,"+(.75*s+.1).toFixed(2)+")";ctx.fillRect(vx-lw/2,y,lw,Math.max(2,h*.02*s));}
    for(var b=0;b<3;b++){var s2=Math.pow(.6,b),bx=w*.5-w*.42*s2,by=vy+(h*.5)*s2,bw=w*.2*s2,bh=h*.08*s2;
      ctx.fillStyle="rgba(220,240,245,.85)";ctx.fillRect(bx,by,bw,bh);ctx.fillStyle="rgba(95,227,240,.9)";ctx.fillRect(bx+bw*.1,by-bh*1.6,bw*.25,bh*1.1);
      ctx.fillStyle="rgba(220,240,245,.85)";ctx.fillRect(w-bx-bw,by,bw,bh);}
    ctx.fillStyle="rgba(255,90,90,.9)";ctx.fillRect(vx-6,vy-h*.08,12,4);ctx.fillRect(vx-2,vy-h*.08-4,4,12);
    haze(ctx,w,h,vy,"rgba(150,230,240,.08)");};

  /* métro de Lorville */
  S.metro=function(ctx,w,h){var r=rng(304);bg(ctx,w,h,"#1a0f0a","#3a2416");haze(ctx,w,h,h*.35,"rgba(255,170,100,.18)");
    for(var i=0;i<14;i++){var x=r()*w,bw=w*(.03+r()*.06),bh=h*(.2+r()*.35);ctx.fillStyle="rgba(30,18,12,.85)";ctx.fillRect(x,h*.55-bh,bw,bh);if(r()<.6){ctx.fillStyle="rgba(255,190,110,.7)";ctx.fillRect(x+bw*.3,h*.55-bh+4,2,2);}}
    ctx.fillStyle="#0e0a08";ctx.fillRect(0,h*.62,w,h*.38);
    ctx.fillStyle=lin(ctx,0,h*.5,0,h*.66,[[0,"#3b4248"],[1,"#1b1f22"]]);ctx.beginPath();ctx.moveTo(w*.05,h*.66);ctx.lineTo(w*.08,h*.52);ctx.quadraticCurveTo(w*.1,h*.48,w*.2,h*.48);ctx.lineTo(w*.9,h*.48);ctx.lineTo(w*.92,h*.66);ctx.fill();
    for(var j=0;j<9;j++){ctx.fillStyle="rgba(255,214,150,.85)";ctx.fillRect(w*(.22+j*.075),h*.52,w*.05,h*.05);}
    ctx.fillStyle="#ffb347";ctx.fillRect(0,h*.68,w,3);ctx.fillStyle="rgba(255,179,71,.85)";ctx.font="600 "+Math.round(h*.045)+"px monospace";ctx.fillText("PERIMETER · EST",w*.06,h*.8);
    for(var p=0;p<6;p++){var px=w*(.15+p*.14+r()*.04),ph=h*(.12+r()*.03);ctx.fillStyle="#050302";ctx.fillRect(px,h*.78-ph,w*.022,ph);ctx.beginPath();ctx.arc(px+w*.011,h*.78-ph-h*.02,h*.022,0,7);ctx.fill();}};

  /* hangar de Teasa */
  S.hangar=function(ctx,w,h){var r=rng(305);ctx.fillStyle=lin(ctx,0,0,0,h,[[0,"#14100c"],[1,"#060504"]]);ctx.fillRect(0,0,w,h);
    ctx.fillStyle="rgba(255,190,120,.12)";ctx.beginPath();ctx.moveTo(w*.3,0);ctx.lineTo(w*.7,0);ctx.lineTo(w*.9,h);ctx.lineTo(w*.1,h);ctx.fill();
    for(var i=0;i<7;i++){ctx.fillStyle="rgba(255,226,180,.9)";ctx.fillRect(w*(.1+i*.13),h*.06,w*.06,3);}
    ctx.strokeStyle="rgba(90,70,50,.6)";for(var k=0;k<8;k++){ctx.beginPath();ctx.moveTo(w*k/7,h*.62);ctx.lineTo(w*.5+(w*k/7-w*.5)*2.4,h);ctx.stroke();}
    ctx.fillStyle="#0a0806";ctx.fillRect(0,h*.62,w,2);
    var cx=w*.5,cy=h*.52;ctx.fillStyle="#1d1a16";ctx.beginPath();ctx.moveTo(cx-w*.36,cy+h*.06);ctx.lineTo(cx-w*.1,cy-h*.06);ctx.lineTo(cx+w*.12,cy-h*.07);ctx.lineTo(cx+w*.38,cy+h*.05);ctx.lineTo(cx+w*.2,cy+h*.1);ctx.lineTo(cx-w*.2,cy+h*.1);ctx.fill();
    ctx.fillStyle="#2a2620";ctx.fillRect(cx-w*.08,cy-h*.12,w*.16,h*.07);ctx.fillStyle="rgba(95,227,240,.6)";ctx.fillRect(cx-w*.05,cy-h*.11,w*.1,h*.03);
    ctx.fillStyle="#0c0a08";[cx-w*.18,cx+w*.16].forEach(function(x){ctx.fillRect(x,cy+h*.1,4,h*.08);});
    ctx.fillStyle="rgba(255,179,71,.85)";ctx.font="600 "+Math.round(h*.05)+"px monospace";ctx.fillText("10-03",w*.06,h*.2);
    haze(ctx,w,h,h*.62,"rgba(255,180,110,.08)");};

  /* Sénat : hémicycle */
  S.senat=function(ctx,w,h){var r=rng(306);bg(ctx,w,h,"#07090f","#121826");var cx=w*.5,cy=h*1.05;
    for(var k=0;k<7;k++){var R=h*(.35+k*.1);ctx.strokeStyle="rgba(150,180,220,"+(.5-k*.05).toFixed(2)+")";ctx.lineWidth=h*.03;ctx.beginPath();ctx.arc(cx,cy,R,Math.PI*1.05,Math.PI*1.95);ctx.stroke();
      for(var s=0;s<14+k*3;s++){var a=Math.PI*1.07+s/(13+k*3)*Math.PI*.86;if(r()<.75){ctx.fillStyle=r()<.15?"rgba(255,179,71,.9)":"rgba(210,230,255,.75)";ctx.beginPath();ctx.arc(cx+Math.cos(a)*R,cy+Math.sin(a)*R-h*.02,h*.008+1,0,7);ctx.fill();}}}
    ctx.fillStyle="rgba(95,227,240,.12)";ctx.beginPath();ctx.moveTo(cx-w*.05,h*.1);ctx.lineTo(cx+w*.05,h*.1);ctx.lineTo(cx+w*.2,h*.7);ctx.lineTo(cx-w*.2,h*.7);ctx.fill();
    ctx.strokeStyle="rgba(95,227,240,.8)";ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(cx,h*.32,h*.12,0,7);ctx.stroke();ctx.beginPath();ctx.arc(cx,h*.32,h*.07,0,7);ctx.stroke();
    ctx.fillStyle="rgba(214,247,251,.9)";ctx.font="600 "+Math.round(h*.045)+"px monospace";ctx.textAlign="center";ctx.fillText("UEE · SÉNAT",cx,h*.08);ctx.textAlign="left";};

  /* convoi commercial */
  S.convoi=function(ctx,w,h){var r=rng(307);bg(ctx,w,h,"#04060a","#0a0f18");nebula(ctx,w,h,r,["rgba(90,140,120,A)","rgba(60,70,130,A)"],5);stars(ctx,w,h,r,Math.round(w*.5));
    for(var i=0;i<6;i++){var x=w*(.12+i*.15),y=h*(.32+((i%3)*.14)),s=w*(.05+(i%2)*.025);ctx.fillStyle="#141a22";ctx.fillRect(x-s,y-s*.25,s*2,s*.5);ctx.fillStyle="#1f2833";ctx.fillRect(x-s*.7,y-s*.45,s*.5,s*.2);ctx.fillRect(x-s*.1,y-s*.45,s*.5,s*.2);
      glow(ctx,x-s*1.05,y,s*.35,"rgba(120,200,255,A)",.8);ctx.fillStyle="rgba(255,179,71,.9)";ctx.fillRect(x+s*.9,y-1,2,2);}
    ctx.strokeStyle="rgba(255,179,71,.5)";ctx.setLineDash([4,6]);ctx.beginPath();ctx.moveTo(0,h*.86);ctx.lineTo(w,h*.86);ctx.stroke();ctx.setLineDash([]);};

  /* raid : combat aux frontières */
  S.raid=function(ctx,w,h){var r=rng(308);bg(ctx,w,h,"#05040a","#120a14");nebula(ctx,w,h,r,["rgba(150,70,90,A)","rgba(70,60,140,A)"],6);stars(ctx,w,h,r,Math.round(w*.45));
    planet(ctx,{x:w*.15,y:h*.95,r:w*.35,base:["#5a5f73","#1b1d26"],bands:null,atmo:null,light:-1,seed:41});
    glow(ctx,w*.66,h*.4,w*.09,"rgba(255,150,80,A)",.95);glow(ctx,w*.66,h*.4,w*.03,"rgba(255,255,220,A)",1);
    for(var i=0;i<14;i++){var a=r()*7,d=w*(.04+r()*.12);ctx.strokeStyle="rgba(255,200,120,"+(.3+r()*.5).toFixed(2)+")";ctx.beginPath();ctx.moveTo(w*.66,h*.4);ctx.lineTo(w*.66+Math.cos(a)*d,h*.4+Math.sin(a)*d);ctx.stroke();}
    for(var j=0;j<5;j++){var x=w*(.2+r()*.6),y=h*(.15+r()*.5),dx=(r()-.5)*w*.3,dy=(r()-.5)*h*.2;ctx.strokeStyle=j%2?"rgba(255,90,90,.85)":"rgba(95,227,240,.85)";ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+dx,y+dy);ctx.stroke();
      ctx.fillStyle="#0a0a10";ctx.beginPath();ctx.moveTo(x,y-5);ctx.lineTo(x+9,y);ctx.lineTo(x,y+5);ctx.fill();}};
})();
/* Scènes du récit d'Exo : chaque image illustre une action racontée */
(function(){
  var S=window.__scenes,K=window.__kit;if(!S||!K)return;
  var rng=K.rng,bg=K.bg,stars=K.stars,glow=K.glow,nebula=K.nebula,planet=K.planet;
  function lin(ctx,x0,y0,x1,y1,st){var g=ctx.createLinearGradient(x0,y0,x1,y1);st.forEach(function(s){g.addColorStop(s[0],s[1]);});return g;}
  function smog(ctx,w,h,y,a){ctx.fillStyle=lin(ctx,0,y-h*.25,0,y+h*.25,[[0,"rgba(120,80,50,0)"],[.5,"rgba(170,110,70,"+a+")"],[1,"rgba(120,80,50,0)"]]);ctx.fillRect(0,y-h*.25,w,h*.5);}
  function skyline(ctx,w,h,r,base,col,n){for(var i=0;i<n;i++){var x=r()*w,bw=w*(.02+r()*.06),bh=h*(.08+r()*.3);ctx.fillStyle=col;ctx.fillRect(x,base-bh,bw,bh);if(r()<.4){ctx.fillRect(x+bw*.4,base-bh-h*.08,bw*.2,h*.08);}}}
  function ship(ctx,x,y,s,col,lights){ctx.save();ctx.translate(x,y);ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(-s,-s*.18);ctx.lineTo(s*.5,-s*.3);ctx.lineTo(s,0);ctx.lineTo(s*.5,s*.3);ctx.lineTo(-s,s*.2);ctx.closePath();ctx.fill();
    ctx.fillRect(-s*.4,-s*.55,s*.5,s*.3);ctx.fillRect(-s*.4,s*.25,s*.5,s*.3);if(lights){ctx.fillStyle=lights;ctx.fillRect(s*.55,-s*.06,s*.18,s*.08);}ctx.restore();}

  /* les mines sous la ville */
  S.mine=function(ctx,w,h){var r=rng(401);ctx.fillStyle=lin(ctx,0,0,0,h,[[0,"#120b07"],[1,"#050302"]]);ctx.fillRect(0,0,w,h);
    var vx=w*.55,vy=h*.42;ctx.fillStyle="#1d130c";ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(w,0);ctx.lineTo(vx+w*.08,vy-h*.06);ctx.lineTo(vx-w*.08,vy-h*.06);ctx.fill();
    ctx.beginPath();ctx.moveTo(0,h);ctx.lineTo(w,h);ctx.lineTo(vx+w*.08,vy+h*.06);ctx.lineTo(vx-w*.08,vy+h*.06);ctx.fill();
    for(var i=0;i<7;i++){var t=Math.pow(.72,i),x0=vx-(vx)*t,x1=vx+(w-vx)*t,y0=vy-vy*t,y1=vy+(h-vy)*t;ctx.strokeStyle="rgba(120,80,40,"+(.25+t*.5).toFixed(2)+")";ctx.lineWidth=2+t*8;ctx.strokeRect(x0,y0,x1-x0,y1-y0);
      ctx.fillStyle="rgba(255,190,90,"+(.3+t*.6).toFixed(2)+")";ctx.beginPath();ctx.arc(vx,y0+3,3+t*5,0,7);ctx.fill();}
    ctx.strokeStyle="rgba(160,130,90,.5)";ctx.lineWidth=2;[[-1],[1]].forEach(function(d){ctx.beginPath();ctx.moveTo(vx+d*w*.02,vy+h*.06);ctx.lineTo(vx+d*w*.25,h);ctx.stroke();});
    for(var k=0;k<2;k++){var px=w*(.3+k*.42),ph=h*.28;ctx.fillStyle="#070403";ctx.fillRect(px,h*.95-ph,w*.05,ph);ctx.beginPath();ctx.arc(px+w*.025,h*.95-ph-h*.035,h*.04,0,7);ctx.fill();ctx.fillStyle="rgba(255,220,140,.95)";ctx.fillRect(px+w*.012,h*.95-ph-h*.06,w*.026,h*.015);
      glow(ctx,px+w*.025,h*.95-ph-h*.05,w*.06,"rgba(255,200,120,A)",.35);}
    for(var d=0;d<60;d++){ctx.fillStyle="rgba(220,170,110,"+(r()*.35).toFixed(2)+")";ctx.fillRect(r()*w,r()*h,1.2,1.2);}};

  /* les baraques au-delà des portes */
  S.baraques=function(ctx,w,h){var r=rng(402);bg(ctx,w,h,"#2a1a10","#5a3a22");smog(ctx,w,h,h*.4,.45);
    skyline(ctx,w*.6,h,r,h*.5,"rgba(40,26,18,.7)",14);ctx.fillStyle="rgba(30,20,14,.9)";ctx.fillRect(w*.62,h*.12,w*.025,h*.4);ctx.fillRect(w*.6,h*.14,w*.065,h*.02);
    ctx.fillStyle="#24170f";ctx.fillRect(w*.5,h*.34,w*.5,h*.2);ctx.fillStyle="rgba(255,179,71,.6)";ctx.fillRect(w*.5,h*.33,w*.5,3);
    for(var i=0;i<16;i++){var x=r()*w*.95,y=h*(.62+r()*.25),bw=w*(.06+r()*.08),bh=h*(.07+r()*.08);ctx.fillStyle=["#3a2a1e","#2e241c","#46342a","#2a2a2c"][i%4];ctx.fillRect(x,y-bh,bw,bh);
      ctx.fillStyle="#1a120c";ctx.beginPath();ctx.moveTo(x-3,y-bh);ctx.lineTo(x+bw*.6,y-bh-h*.03);ctx.lineTo(x+bw+3,y-bh);ctx.fill();if(r()<.6){ctx.fillStyle="rgba(255,190,110,.85)";ctx.fillRect(x+bw*.3,y-bh*.6,bw*.18,bh*.25);}}
    ctx.fillStyle="#140d08";ctx.fillRect(0,h*.88,w,h*.12);
    for(var c=0;c<3;c++){ctx.strokeStyle="rgba(200,160,120,.25)";ctx.beginPath();ctx.moveTo(0,h*(.55+c*.04));ctx.quadraticCurveTo(w*.5,h*(.62+c*.04),w,h*(.56+c*.04));ctx.stroke();}};

  /* la casse de Reclamation & Disposal */
  S.casse=function(ctx,w,h){var r=rng(403);bg(ctx,w,h,"#3a2416","#6a4a30");smog(ctx,w,h,h*.3,.4);
    for(var l=0;l<3;l++){ctx.fillStyle=["#3c2c22","#2e2219","#1f1712"][l];ctx.beginPath();ctx.moveTo(0,h);for(var x=0;x<=w;x+=w/14){ctx.lineTo(x,h*(.45+l*.15)+Math.sin(x*.03+l)*h*.05+r()*h*.06);}ctx.lineTo(w,h);ctx.fill();
      for(var k=0;k<14;k++){ctx.fillStyle="rgba(120,110,100,"+(.25+l*.15).toFixed(2)+")";ctx.save();ctx.translate(r()*w,h*(.5+l*.15)+r()*h*.1);ctx.rotate(r()*3);ctx.fillRect(0,0,w*(.02+r()*.05),h*.015);ctx.restore();}}
    ctx.strokeStyle="#140e0a";ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(w*.82,h);ctx.lineTo(w*.82,h*.2);ctx.lineTo(w*.5,h*.28);ctx.stroke();ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(w*.55,h*.27);ctx.lineTo(w*.55,h*.45);ctx.stroke();
    ctx.fillStyle="#140e0a";ctx.fillRect(w*.52,h*.45,w*.06,h*.04);
    [[.25,.8,.11],[.35,.82,.09],[.18,.84,.08]].forEach(function(k){var x=w*k[0],y=h*k[1],s=h*k[2];ctx.fillStyle="#0d0907";ctx.fillRect(x-s*.18,y-s,s*.36,s);ctx.beginPath();ctx.arc(x,y-s-s*.18,s*.18,0,7);ctx.fill();});
    ctx.fillStyle="rgba(255,179,71,.85)";ctx.font="600 "+Math.round(h*.045)+"px monospace";ctx.fillText("RECLAMATION & DISPOSAL",w*.05,h*.12);};

  /* départ à dix-sept ans sur un vieux cargo */
  S.depart=function(ctx,w,h){var r=rng(404);bg(ctx,w,h,"#1a1218","#5a3a26");smog(ctx,w,h,h*.62,.6);
    skyline(ctx,w,h,r,h*.88,"rgba(30,20,14,.95)",22);ctx.fillStyle="#120c08";ctx.fillRect(0,h*.88,w,h*.12);
    var x=w*.6,y=h*.3;ctx.strokeStyle="rgba(255,190,120,.35)";ctx.lineWidth=h*.03;ctx.beginPath();ctx.moveTo(w*.35,h*.85);ctx.quadraticCurveTo(w*.48,h*.5,x,y);ctx.stroke();
    ctx.save();ctx.translate(x,y);ctx.rotate(-.6);ctx.fillStyle="#2a2622";ctx.fillRect(-w*.09,-h*.04,w*.18,h*.08);ctx.fillRect(-w*.05,-h*.08,w*.08,h*.04);ctx.fillStyle="#3a342e";ctx.fillRect(-w*.09,-h*.02,w*.18,h*.015);ctx.restore();
    glow(ctx,x-w*.05,y+h*.06,w*.06,"rgba(120,200,255,A)",.8);ctx.fillStyle="rgba(255,90,60,.9)";ctx.fillRect(x+w*.06,y-h*.06,3,3);};

  /* une plaque au fond d'un couloir */
  S.plaque=function(ctx,w,h){var r=rng(405);ctx.fillStyle=lin(ctx,0,0,0,h,[[0,"#0b0e12"],[1,"#040506"]]);ctx.fillRect(0,0,w,h);
    var vx=w*.5,vy=h*.45;ctx.strokeStyle="rgba(120,140,160,.18)";[[0,0],[w,0],[0,h],[w,h]].forEach(function(p){ctx.beginPath();ctx.moveTo(vx,vy);ctx.lineTo(p[0],p[1]);ctx.stroke();});
    for(var i=1;i<8;i++){var t=i/8;ctx.strokeStyle="rgba(120,140,160,"+(.08+t*.12).toFixed(2)+")";ctx.strokeRect(vx-vx*t,vy-vy*t,w*t,h*t);}
    for(var p=0;p<18;p++){var row=p%3,col=Math.floor(p/3),x=w*.08+col*w*.035,y=h*(.32+row*.12)+col*h*.01;ctx.fillStyle="rgba(170,160,140,"+(.15+col*.03).toFixed(2)+")";ctx.fillRect(x,y,w*.025,h*.06);}
    ctx.fillStyle="#6b6252";ctx.fillRect(vx-w*.07,vy-h*.08,w*.14,h*.14);ctx.fillStyle="#a39880";ctx.fillRect(vx-w*.06,vy-h*.07,w*.12,h*.12);
    ctx.fillStyle="#3a3428";for(var l=0;l<4;l++)ctx.fillRect(vx-w*.045,vy-h*.045+l*h*.025,w*(l?.07:.09),h*.008);
    glow(ctx,vx,vy-h*.2,w*.12,"rgba(255,220,170,A)",.25);};

  /* le moteur quantique lâche près de Magda */
  S.qtpanne=function(ctx,w,h){var r=rng(406);bg(ctx,w,h,"#04050a","#0a0c14");stars(ctx,w,h,r,Math.round(w*.4));
    planet(ctx,{x:w*.2,y:h*.3,r:h*.42,base:["#c9b8d8","#4a3f5c"],bands:null,atmo:"rgba(200,180,230,A)",light:-.3,seed:33});
    for(var i=0;i<26;i++){var y=h*(.45+r()*.2),x0=w*(.45+r()*.1),len=w*(.05+r()*.25);ctx.strokeStyle="rgba(150,220,255,"+(r()*.4).toFixed(2)+")";ctx.beginPath();ctx.moveTo(x0+len,y);ctx.lineTo(x0+len*2,y);ctx.stroke();}
    var x=w*.62,y=h*.55,s=w*.12;ship(ctx,x,y,s,"#2b2f36",null);
    glow(ctx,x-s*.95,y,s*.5,"rgba(255,90,40,A)",.85);glow(ctx,x-s*.95,y,s*.2,"rgba(255,220,160,A)",1);
    for(var k=0;k<20;k++){ctx.fillStyle="rgba(255,"+Math.round(120+r()*100)+",60,"+(.3+r()*.6).toFixed(2)+")";ctx.fillRect(x-s*.95-r()*s*.8,y+(r()-.5)*s*.6,2,2);}
    ctx.fillStyle="rgba(255,90,60,.95)";ctx.font="600 "+Math.round(h*.045)+"px monospace";ctx.fillText("QT · SURCHAUFFE",w*.58,h*.85);};

  /* l'épave sans transpondeur : Exo tourne autour, têtes de récupération éteintes */
  S.epave=function(ctx,w,h){var r=rng(407);bg(ctx,w,h,"#04050a","#090b12");stars(ctx,w,h,r,Math.round(w*.45));
    planet(ctx,{x:w*.95,y:h*.1,r:h*.32,base:["#c9b8d8","#4a3f5c"],bands:null,atmo:"rgba(200,180,230,A)",light:Math.PI-.4,seed:33});
    ctx.save();ctx.translate(w*.42,h*.48);ctx.rotate(.25);var L=w*.3,H=h*.16;ctx.fillStyle="#1b2028";ctx.fillRect(-L/2,-H/2,L,H);ctx.fillRect(-L*.2,-H*.85,L*.3,H*.4);
    ctx.fillStyle="#0c0e12";ctx.beginPath();ctx.arc(L*.3,0,H*.28,0,7);ctx.fill();ctx.fillStyle="rgba(40,30,25,.9)";for(var b=0;b<10;b++){ctx.beginPath();ctx.arc(L*.3+(r()-.5)*H*.9,(r()-.5)*H*.9,H*.08*r()+2,0,7);ctx.fill();}
    ctx.strokeStyle="#2a313b";for(var i=0;i<9;i++){ctx.beginPath();ctx.moveTo(-L/2+i*L/9,-H/2);ctx.lineTo(-L/2+i*L/9,H/2);ctx.stroke();}ctx.restore();
    ctx.strokeStyle="rgba(95,227,240,.35)";ctx.setLineDash([4,6]);ctx.beginPath();ctx.ellipse(w*.42,h*.5,w*.3,h*.16,.2,0,7);ctx.stroke();ctx.setLineDash([]);
    ship(ctx,w*.82,h*.8,w*.1,"#14171c",null);ctx.fillStyle="rgba(95,227,240,.7)";ctx.fillRect(w*.86,h*.79,4,2);
    ctx.fillStyle="rgba(95,227,240,.85)";ctx.font="600 "+Math.round(h*.04)+"px monospace";ctx.fillText("TRANSPONDEUR : AUCUN",w*.05,h*.92);};

  /* la descente sur Hurston, la coque secouée */
  S.descente=function(ctx,w,h){var r=rng(408);bg(ctx,w,h,"#3a2a20","#8a5a36");
    for(var i=0;i<5;i++)smog(ctx,w,h,h*(.2+i*.18),.35);
    for(var k=0;k<7;k++){var x=w*(.1+k*.13),bh=h*(.15+r()*.2);ctx.fillStyle="rgba(40,26,18,.8)";ctx.fillRect(x,h-bh,w*.03,bh);ctx.fillStyle="rgba(90,70,60,.35)";ctx.beginPath();ctx.arc(x+w*.015,h-bh-h*.06,w*.05,0,7);ctx.fill();}
    ctx.fillStyle="#0d0a08";ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(w*.2,0);ctx.lineTo(w*.08,h);ctx.lineTo(0,h);ctx.fill();ctx.beginPath();ctx.moveTo(w,0);ctx.lineTo(w*.8,0);ctx.lineTo(w*.92,h);ctx.lineTo(w,h);ctx.fill();
    for(var s=0;s<40;s++){ctx.strokeStyle="rgba(255,190,140,"+(r()*.35).toFixed(2)+")";var x0=w*(.15+r()*.7),y0=r()*h;ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x0-w*.02,y0+h*.12);ctx.stroke();}
    glow(ctx,w*.5,h*.15,w*.25,"rgba(255,140,60,A)",.25);
    ctx.fillStyle="rgba(255,179,71,.95)";ctx.font="600 "+Math.round(h*.042)+"px monospace";ctx.fillText("TURBULENCES · COQUE 92 %",w*.22,h*.93);};

  /* Maria Pure of Heart : la tour de l'hôpital et sa plateforme sur le toit, la statue de Maria Wharton devant l'entrée (Workers District, FO19 Production Quad) */
  S.entree=function(ctx,w,h){var r=rng(409);bg(ctx,w,h,"#2a1c12","#6a4a30");smog(ctx,w,h,h*.35,.45);
    skyline(ctx,w,h,r,h*.78,"rgba(36,24,16,.85)",18);
    var tx=w*.56,tw=w*.2,top=h*.12;ctx.fillStyle=lin(ctx,tx-tw/2,0,tx+tw/2,0,[[0,"#8d989c"],[.5,"#c9d2d4"],[1,"#7c8689"]]);ctx.fillRect(tx-tw/2,top,tw,h*.66);
    for(var f=0;f<14;f++){ctx.fillStyle=r()<.7?"rgba(140,230,240,.55)":"rgba(40,50,55,.6)";ctx.fillRect(tx-tw*.42,top+h*.06+f*h*.042,tw*.84,h*.012);}
    ctx.fillStyle="#5f696c";ctx.fillRect(tx-tw*.75,top-h*.015,tw*1.5,h*.02);ctx.strokeStyle="rgba(255,179,71,.8)";ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(tx,top-h*.02,tw*.55,h*.012,0,0,7);ctx.stroke();
    ctx.fillStyle="#e8eef0";ctx.fillRect(tx-w*.035,top-h*.05,w*.07,h*.025);ctx.fillStyle="#d84a4a";ctx.fillRect(tx-w*.006,top-h*.047,w*.012,h*.02);
    ctx.fillStyle="#d84a4a";ctx.fillRect(tx-w*.012,top+h*.015,w*.024,h*.04);ctx.fillRect(tx-w*.03,top+h*.025,w*.06,h*.02);
    ctx.fillStyle="#2a3238";ctx.font="600 "+Math.round(h*.03)+"px sans-serif";ctx.textAlign="center";ctx.fillText("MARIA PURE OF HEART",tx,h*.7);ctx.textAlign="left";
    ctx.fillStyle="#5fd0dc";ctx.fillRect(tx-tw*.3,h*.71,tw*.6,h*.07);
    ctx.fillStyle="#120c08";ctx.fillRect(0,h*.78,w,h*.22);
    var sx=w*.24,sy=h*.78;ctx.fillStyle="#3a3631";ctx.fillRect(sx-w*.04,sy-h*.05,w*.08,h*.05);ctx.fillStyle="#b9b2a6";
    ctx.beginPath();ctx.moveTo(sx-w*.02,sy-h*.05);ctx.lineTo(sx-w*.03,sy-h*.2);ctx.lineTo(sx+w*.03,sy-h*.2);ctx.lineTo(sx+w*.02,sy-h*.05);ctx.fill();
    ctx.beginPath();ctx.arc(sx,sy-h*.23,h*.03,0,7);ctx.fill();ctx.beginPath();ctx.moveTo(sx+w*.025,sy-h*.18);ctx.lineTo(sx+w*.06,sy-h*.24);ctx.lineTo(sx+w*.065,sy-h*.235);ctx.lineTo(sx+w*.03,sy-h*.16);ctx.fill();
    glow(ctx,sx,sy-h*.15,w*.08,"rgba(255,220,170,A)",.18);
    ctx.fillStyle="#0a0705";ctx.fillRect(w*.4,h*.8,w*.02,h*.1);ctx.beginPath();ctx.arc(w*.41,h*.79,h*.022,0,7);ctx.fill();
    ctx.fillStyle="rgba(214,247,251,.85)";ctx.font="italic "+Math.round(h*.028)+"px serif";ctx.fillText("« Good health is the foundation… »",w*.05,h*.95);};

  /* la borne d'assurance : transfert de l'imprint */
  S.imprint=function(ctx,w,h){var r=rng(410);ctx.fillStyle=lin(ctx,0,0,0,h,[[0,"#06141a"],[1,"#020709"]]);ctx.fillRect(0,0,w,h);
    ctx.fillStyle="#0d2028";ctx.fillRect(w*.3,h*.15,w*.4,h*.75);ctx.fillStyle="#0a161c";ctx.fillRect(w*.33,h*.2,w*.34,h*.5);
    var cx=w*.5,cy=h*.43;ctx.strokeStyle="rgba(95,227,240,.9)";ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(cx,cy-h*.14,h*.045,0,7);ctx.stroke();
    ctx.beginPath();ctx.moveTo(cx,cy-h*.095);ctx.lineTo(cx,cy+h*.06);ctx.moveTo(cx-w*.06,cy-h*.06);ctx.lineTo(cx+w*.06,cy-h*.06);ctx.moveTo(cx,cy+h*.06);ctx.lineTo(cx-w*.035,cy+h*.17);ctx.moveTo(cx,cy+h*.06);ctx.lineTo(cx+w*.035,cy+h*.17);ctx.stroke();
    for(var i=0;i<12;i++){ctx.strokeStyle="rgba(95,227,240,"+(.1+r()*.3).toFixed(2)+")";var y=cy-h*.2+i*h*.035;ctx.beginPath();ctx.moveTo(w*.35,y);ctx.lineTo(w*.65,y);ctx.stroke();}
    glow(ctx,cx,cy,w*.2,"rgba(95,227,240,A)",.18);
    ctx.fillStyle="rgba(255,179,71,.95)";ctx.font="600 "+Math.round(h*.034)+"px monospace";ctx.textAlign="center";ctx.fillText("IMPRINT → LORVILLE",cx,h*.78);ctx.fillStyle="rgba(95,227,240,.85)";ctx.fillText("TRANSFERT CONFIRMÉ",cx,h*.84);ctx.textAlign="left";};

  /* seul dans le vide */
  S.seul=function(ctx,w,h){var r=rng(411);bg(ctx,w,h,"#020306","#05070c");stars(ctx,w,h,r,Math.round(w*.7));nebula(ctx,w,h,r,["rgba(60,80,120,A)"],3);
    ship(ctx,w*.6,h*.55,w*.035,"#1a1d22","rgba(255,179,71,.9)");glow(ctx,w*.6-w*.035,h*.55,w*.02,"rgba(120,200,255,A)",.8);};
})();
