/* Carte 3D : galaxie, système, planète — moteur maison (canvas). Glisser de côté = tourner, vertical = défiler la page, pincer = zoomer */
(function(){
  var mount=document.getElementById("map-mount");if(!mount)return;
  var stage=mount.querySelector(".map-stage"),svg=stage&&stage.querySelector("svg");if(!svg)return;
  stage.style.position="relative";
  var AP=function(){return window.__APP||{};};

  /* ---------- HUD ---------- */
  var hud=document.createElement("div");hud.className="mfx-hud";hud.innerHTML='<div class="mfx-tl"><span class="mfx-k">Cible</span><span class="mfx-v" id="mfx-t">—</span></div><div class="mfx-tr"><span class="mfx-k">Coord.</span><span class="mfx-v" id="mfx-c">—</span></div><div class="mfx-scan"></div><div class="mfx-corners"><i></i><i></i><i></i><i></i></div>';
  stage.appendChild(hud);
  var T=hud.querySelector("#mfx-t"),C=hud.querySelector("#mfx-c"),scan=hud.querySelector(".mfx-scan");
  function typeTo(el,txt){var i=0;el.textContent="";clearInterval(el._t);el._t=setInterval(function(){i+=2;el.textContent=txt.slice(0,i);if(i>=txt.length)clearInterval(el._t);},18);}
  function hash(s){var h=2166136261;for(var i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return Math.abs(h);}
  /* positions : données publiques de la carte stellaire RSI (copie d'archive) ; Branaugh placé à la main */
  var SYS={Stanton:[49.53,-2.63,16.48],Pyro:[40.13,8.41,-17.22],Nyx:[26.54,27.07,-14.52],Sol:[0,0,0],Terra:[67.71,-8.13,-3.14],Magnus:[49.62,-13.12,2.55],Hadrian:[67.70,8.08,6.06],Ellis:[45.25,-21.55,-3.71],Croshaw:[-0.53,-10.88,-0.80],Castra:[40.19,18.96,21.06],Davien:[13.36,-18.61,3.85],Oso:[31.10,13.59,-40.18],Kellog:[-27.03,37.93,-2.59],Vega:[-8.54,10.79,17.98],Orion:[-45.33,0.06,15.39],Caliban:[-31.41,-7.82,3.56],Branaugh:[-34,26,-8],Hades:[26.81,-32.33,-3.96],Nul:[-18.15,-10.62,-2.24],Odin:[-0.11,37.88,-27.75],Goss:[85.11,-29.70,8.18],Cathcart:[26.63,-21.69,16.41],Kallis:[22.29,2.70,-3.52]};
  function coordOf(name){var p=SYS[name];if(p)return (p[0]>=0?"+":"")+p[0].toFixed(2)+" · "+(p[1]>=0?"+":"")+p[1].toFixed(2)+" · "+(p[2]>=0?"+":"")+p[2].toFixed(2)+" al";var h=hash(name);return (h%900/10).toFixed(1)+"° · "+((h>>8)%1800/10-90).toFixed(1)+"° · "+((h>>4)%9000/10).toFixed(1)+" Gm";}
  function sweep(){scan.classList.remove("on");void scan.offsetWidth;scan.classList.add("on");}

  /* ---------- moteur ---------- */
  var wrap=document.createElement("div");wrap.className="g3d";wrap.innerHTML='<canvas></canvas><div class="g3d-labels"></div><div class="g3d-ret"><b><i></i><i></i><i></i><i></i></b></div><div class="g3d-help">Glisse de côté pour tourner · pince pour zoomer · touche un objet</div>';
  stage.insertBefore(wrap,hud);
  var cv=wrap.querySelector("canvas"),ctx=cv.getContext("2d"),lab=wrap.querySelector(".g3d-labels"),ret=wrap.querySelector(".g3d-ret"),W=0,H=0,dpr=Math.min(2,window.devicePixelRatio||1);
  svg.style.visibility="hidden";wrap.style.display="block";
  var sub=function(a,b){return [a[0]-b[0],a[1]-b[1],a[2]-b[2]];},dot=function(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];},crs=function(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];},nrm=function(a){var l=Math.hypot(a[0],a[1],a[2])||1;return [a[0]/l,a[1]/l,a[2]/l];};
  var cam=[0,0,0],F=[0,0,1],R=[1,0,0],U=[0,1,0],foc=1,tgt=[0,0,0],th=0.75,ph=1.08,rad=260,auto=true,lastT=0,radGoal=null;
  function camUpdate(){cam=[tgt[0]+rad*Math.sin(ph)*Math.sin(th),tgt[1]+rad*Math.cos(ph),tgt[2]+rad*Math.sin(ph)*Math.cos(th)];F=nrm(sub(tgt,cam));R=nrm(crs(F,[0,1,0]));U=crs(R,F);foc=H/(2*Math.tan(25*Math.PI/180));}
  function proj(p){var v=sub(p,cam),z=dot(v,F);if(z<1)return null;return [W/2+foc*dot(v,R)/z,H/2-foc*dot(v,U)/z,z];}
  function rgb(h){h=String(h||"#7d8590").replace("#","");if(h.length===3)h=h.split("").map(function(c){return c+c;}).join("");var n=parseInt(h,16);return [(n>>16)&255,(n>>8)&255,n&255];}
  var bg=[];for(var i=0;i<900;i++){var u=Math.random()*2-1,tt=Math.random()*Math.PI*2,q=Math.sqrt(1-u*u);bg.push([q*Math.cos(tt),u,q*Math.sin(tt),.3+Math.random()*.7]);}
  var SC={objs:[],rings:[],lines:[],grid:null,key:"",center:[0,0,0],rad:260,ph:1.05},selId=null;

  function circlePts(c,r,n){var pts=[];for(var k=0;k<=n;k++){var a=k/n*Math.PI*2;pts.push([c[0]+r*Math.cos(a),c[1],c[2]+r*Math.sin(a)]);}return pts;}
  function strokePts(pts,style,w,dash){ctx.beginPath();var on=false;for(var k=0;k<pts.length;k++){var q=proj(pts[k]);if(!q){on=false;continue;}if(!on){ctx.moveTo(q[0],q[1]);on=true;}else ctx.lineTo(q[0],q[1]);}ctx.setLineDash(dash||[]);ctx.strokeStyle=style;ctx.lineWidth=w||1;ctx.stroke();ctx.setLineDash([]);}
  function sphere(x,y,r,c1,c2){var g=ctx.createRadialGradient(x-r*.35,y-r*.38,r*.05,x,y,r);g.addColorStop(0,c1);g.addColorStop(.7,c2);g.addColorStop(1,"rgba(0,0,0,.95)");ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle="rgba(150,220,255,.35)";ctx.lineWidth=Math.max(1,r*.05);ctx.beginPath();ctx.arc(x,y,r*1.02,0,Math.PI*2);ctx.stroke();}
  function glow(x,y,r,c){var g=ctx.createRadialGradient(x,y,0,x,y,r*2.4);g.addColorStop(0,"rgba(255,255,255,.95)");g.addColorStop(.2,"rgba("+c+",.9)");g.addColorStop(.5,"rgba("+c+",.25)");g.addColorStop(1,"rgba("+c+",0)");ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r*2.4,0,Math.PI*2);ctx.fill();}
  function diamond(x,y,s,c){ctx.fillStyle=c;ctx.strokeStyle="#020a10";ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x,y-s);ctx.lineTo(x+s,y);ctx.lineTo(x,y+s);ctx.lineTo(x-s,y);ctx.closePath();ctx.fill();ctx.stroke();}

  function render(t){
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,W,H);
    bg.forEach(function(b){var z=dot(b,F);if(z<=0)return;var x=W/2+foc*dot(b,R)/z,y=H/2-foc*dot(b,U)/z;if(x<0||y<0||x>W||y>H)return;ctx.fillStyle="rgba(190,235,242,"+(b[3]*0.55).toFixed(2)+")";ctx.fillRect(x,y,1.2,1.2);});
    if(SC.grid){var gc=SC.grid;for(var rr=gc.step;rr<=gc.max;rr+=gc.step)strokePts(circlePts([gc.c[0],gc.y,gc.c[2]],rr,72),"rgba(14,58,76,.55)",1);
      for(var a2=0;a2<12;a2++){var an=a2/12*Math.PI*2;strokePts([[gc.c[0],gc.y,gc.c[2]],[gc.c[0]+gc.max*Math.cos(an),gc.y,gc.c[2]+gc.max*Math.sin(an)]],"rgba(11,42,56,.6)",1);}}
    SC.rings.forEach(function(r){strokePts(r.pts,r.style,r.w,r.dash);});
    SC.lines.forEach(function(l){strokePts(l.pts,l.style,l.w,l.dash);});
    drawRoute(t);
    SC.objs.forEach(function(o){o.s=proj(o.p);});
    SC.objs.filter(function(o){return o.s;}).sort(function(a,b){return b.s[2]-a.s[2];}).forEach(function(o){
      var k=foc/o.s[2],r=Math.max(o.min||2,o.r*k);o.sr=r;var x=o.s[0],y=o.s[1];
      if(o.kind==="system"){r=Math.max(o.lore?4:7,Math.min(o.lore?14:26,r));o.sr=r;glow(x,y,r,rgb(o.color).join(","));
        if(o.home){ctx.save();ctx.translate(x,y);ctx.rotate(t/1400);ctx.setLineDash([10,6]);ctx.strokeStyle="rgba(255,179,71,.9)";ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(0,0,r*1.9,0,Math.PI*2);ctx.stroke();ctx.restore();ctx.setLineDash([]);}}
      else if(o.kind==="star"){glow(x,y,r,rgb(o.color).join(","));ctx.fillStyle="rgba(255,250,235,1)";ctx.beginPath();ctx.arc(x,y,r*.55,0,Math.PI*2);ctx.fill();}
      else if(o.kind==="planet"){if(o.atmo){ctx.fillStyle=o.atmo;ctx.beginPath();ctx.arc(x,y,r*1.12,0,Math.PI*2);ctx.fill();}sphere(x,y,r,o.c1,o.c2);
        for(var m=0;m<(o.moons||0);m++){var an3=t/2600+m/o.moons*Math.PI*2;ctx.fillStyle="rgba(207,214,221,.85)";ctx.beginPath();ctx.arc(x+(r+6)*Math.cos(an3),y+(r+6)*.45*Math.sin(an3),1.8,0,Math.PI*2);ctx.fill();}}
      else if(o.kind==="station"){diamond(x,y,Math.max(4,Math.min(8,r)),o.color||"#86cfc8");o.sr=6;}
      else if(o.kind==="city"){if(o.hidden)return;ctx.fillStyle="#e0a347";ctx.strokeStyle="#020a10";ctx.lineWidth=1.5;ctx.fillRect(x-5,y-5,10,10);ctx.strokeRect(x-5,y-5,10,10);o.sr=6;
        if(o.home){ctx.strokeStyle="rgba(255,179,71,"+(.5+.5*Math.sin(t/300)).toFixed(2)+")";ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(x,y,14+4*Math.sin(t/300),0,Math.PI*2);ctx.stroke();}}
      else if(o.kind==="repere"){if(o.hidden)return;ctx.save();ctx.translate(x,y);ctx.fillStyle="#ffb347";ctx.strokeStyle="#020a10";ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(-5,-9);ctx.arc(0,-10,5,Math.PI,0);ctx.lineTo(0,0);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle="#020a10";ctx.beginPath();ctx.arc(0,-10,1.8,0,7);ctx.fill();ctx.restore();o.sr=8;}
      else if(o.kind==="marker"){ctx.fillStyle="rgba(95,227,240,.9)";ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fill();o.sr=4;}
    });
    var showRet=false;
    SC.objs.forEach(function(o){if(!o.el)return;var vis=o.s&&!o.hidden&&o.s[0]>-60&&o.s[0]<W+60&&o.s[1]>-20&&o.s[1]<H+20;o.el.style.display=vis?"":"none";if(!vis)return;
      o.el.style.transform="translate("+o.s[0].toFixed(1)+"px,"+(o.s[1]+(o.sr||6)+(o.kind==="system"?8:3)).toFixed(1)+"px) translate(-50%,0)";
      if(o.id===selId){showRet=true;var sz=Math.max(34,Math.min(180,(o.sr||8)*2.6));ret.style.width=ret.style.height=sz+"px";ret.style.left=(o.s[0]-sz/2).toFixed(1)+"px";ret.style.top=(o.s[1]-sz/2).toFixed(1)+"px";}});
    ret.style.display=showRet?"block":"none";
  }
  function clearLabels(){lab.textContent="";}
  function addLabel(o,cls,text){var el=document.createElement("button");el.type="button";el.className="g3d-l "+(cls||"");el.textContent=text;el.dataset.oid=o.id;lab.appendChild(el);o.el=el;}

  /* ---------- scènes ---------- */
  function sceneGalaxy(st){
    var A=AP(),nodes=(A.map&&A.map.galaxy.nodes)||{},links=(A.map&&A.map.galaxy.links)||[],K=3;
    var P=function(n){var c=SYS[n];return [c[0]*K,c[2]*K*0.8,-c[1]*K];};
    var objs=[],lines=[];
    Object.keys(SYS).forEach(function(n){var nd=nodes[n]||{color:"#7d8590",lore:true};var o={id:"sys:"+n,name:n,kind:"system",p:P(n),r:nd.lore?3:6,min:3,color:nd.color,lore:!!nd.lore,home:n==="Stanton",tap:function(){enterSys(n);}};objs.push(o);
      lines.push({pts:[o.p,[o.p[0],-60,o.p[2]]],style:"rgba(27,111,134,.35)",w:1});});
    links.forEach(function(L){if(!SYS[L[0]]||!SYS[L[1]])return;var lore=!!((nodes[L[0]]||{}).lore||(nodes[L[1]]||{}).lore);lines.push({pts:[P(L[0]),P(L[1])],style:lore?"rgba(42,95,112,.55)":"rgba(95,227,240,.75)",w:lore?1:1.4,dash:L[2]?[5,5]:null});});
    clearLabels();objs.forEach(function(o){addLabel(o,(o.lore?"lore":"")+(o.home?" home":""),o.name);});
    var hl=document.createElement("div");hl.className="g3d-home";hl.textContent="◎ Lorville · port d'attache";lab.appendChild(hl);
    SC={view:"galaxy",objs:objs,rings:[],lines:lines,grid:{c:[90,0,-20],y:-60,step:60,max:360},center:P("Stanton"),rad:260,ph:1.05,homeEl:hl};
  }
  function bodyColors(b){return (b&&b.planet&&b.planet.base)||["#9aa3ad","#3d3935"];}
  function atmoOf(b){return b&&b.planet&&b.planet.atmo?b.planet.atmo.replace("A","0.25"):null;}
  function sceneSystem(st){
    var A=AP(),L=(A.map&&A.map.layout&&A.map.layout[st.sys])||{},byName={},objs=[],rings=[];(A.bodies||[]).forEach(function(b){byName[b.name]=b;});
    var star=(A.map&&A.map.galaxy.nodes[st.sys])||{color:"#ffd27a"};
    objs.push({id:"star",name:st.sys,kind:"star",p:[0,0,0],r:22,color:star.color||"#ffd27a",tap:function(){__map.go("sys:"+st.sys);}});
    var pos={};
    Object.keys(L).forEach(function(bn){var o=L[bn],b=byName[bn];if(!b)return;
      if(o.ring){rings.push({pts:circlePts([0,0,0],o.r,120),style:"rgba(134,185,196,.55)",w:3,dash:[1,4]});var la=(o.la||90)*Math.PI/180;objs.push({id:bn,name:bn,kind:"marker",p:[o.r*Math.cos(la),0,o.r*Math.sin(la)],r:2,tap:function(){__map.sel(bn);}});return;}
      if(o.special){objs.push({id:bn,name:bn,kind:"marker",p:[330*Math.cos(5.4),0,330*Math.sin(5.4)],r:2,tap:function(){__map.sel(bn);}});return;}
      var a=o.a*Math.PI/180,p=[o.r*Math.cos(a),0,o.r*Math.sin(a)];pos[bn]={p:p,a:a,r:o.r,s:(o.s||12)};
      rings.push({pts:circlePts([0,0,0],o.r,96),style:"rgba(27,111,134,.45)",w:1});
      var col=bodyColors(b),moons=(A.bodies||[]).filter(function(m){return m.parent===bn;}).length;
      objs.push({id:bn,name:bn,kind:"planet",p:p,r:(o.s||12)*0.9,min:4,c1:col[0],c2:col[1],atmo:atmoOf(b),moons:moons,tap:function(){__map.go("body:"+bn);}});
    });
    var gi=0,di=0;(A.places||[]).filter(function(p){return p.sys===st.sys;}).forEach(function(p){var pp=p.parent&&pos[p.parent],o=null;
      if(p.type==="lagrange"&&pp){var lb=/^[A-Z]{3}-L\d/.test(p.name)?p.name.split(" ")[0]:p.name.replace(/ (Service )?Station$/,""),q;
        if(p.lp==="L1"||p.lp==="L2"){var k=(pp.s+30)*(p.lp==="L1"?-1:1);q=[pp.p[0]+Math.cos(pp.a)*k,0,pp.p[2]+Math.sin(pp.a)*k];}else{var aa=pp.a+({L3:Math.PI,L4:-Math.PI/3,L5:Math.PI/3}[p.lp]||0);q=[pp.r*Math.cos(aa),0,pp.r*Math.sin(aa)];}
        o={id:"pl:"+p.name,name:lb,kind:"station",p:q,r:5,color:"#86cfc8"};}
      else if(p.type==="station"&&pp){o={id:"pl:"+p.name,name:p.name,kind:"station",p:[pp.p[0]+Math.cos(pp.a+.9)*(pp.s+24),10,pp.p[2]+Math.sin(pp.a+.9)*(pp.s+24)],r:5,color:"#86cfc8"};}
      else if(p.type==="gateway"){var ga=0.3+gi*0.42;gi++;o={id:"pl:"+p.name,name:p.name,kind:"station",p:[380*Math.cos(ga),0,380*Math.sin(ga)],r:6,color:"#a99be8"};}
      else if(!pp&&p.type!=="ville"&&!(p.parent&&byName[p.parent])){var da=3.4+di*0.3;di++;o={id:"pl:"+p.name,name:p.name.replace("People's Service Station","PSS"),kind:"station",p:[340*Math.cos(da),0,340*Math.sin(da)],r:5,color:"#86cfc8"};}
      if(o){o.tap=function(){__map.place(p.name);};objs.push(o);}});
    clearLabels();objs.forEach(function(o){addLabel(o,o.kind==="station"?"st":o.kind==="marker"?"mk":o.kind==="star"?"lore":"",o.name);});
    SC={view:"system",sys:st.sys,objs:objs,rings:rings,lines:[],grid:null,center:[0,0,0],rad:640,ph:1.12};
  }
  function sceneBody(st){
    var A=AP(),byName={};(A.bodies||[]).forEach(function(b){byName[b.name]=b;});var b=byName[st.body];if(!b){sceneSystem(st);return;}
    var moons=(A.bodies||[]).filter(function(m){return m.parent===b.name;}),objs=[],rings=[],RR=55,col=bodyColors(b);
    objs.push({id:b.name,name:b.name,kind:"planet",p:[0,0,0],r:RR,c1:col[0],c2:col[1],atmo:atmoOf(b),tap:function(){__map.sel(b.name);}});
    moons.forEach(function(m,i){var a=(-60+i*(240/Math.max(1,moons.length-1||1)))*Math.PI/180,rr=150+(i%2)*28,p=[rr*Math.cos(a),(i%2?12:-8),rr*Math.sin(a)],mc=bodyColors(m);
      rings.push({pts:circlePts([0,0,0],rr,96),style:"rgba(27,111,134,.35)",w:1});
      objs.push({id:m.name,name:m.name,kind:"planet",p:p,r:13,min:3,c1:mc[0],c2:mc[1],tap:function(){if(selId===m.name)__map.go("body:"+m.name);else __map.sel(m.name);}});
      (A.places||[]).filter(function(pl){return pl.parent===m.name;}).forEach(function(pl,j){objs.push({id:"pl:"+pl.name,name:pl.name,kind:"station",p:[p[0]+22,p[1]+18+j*14,p[2]],r:5,color:"#86cfc8",tap:function(){__map.place(pl.name);}});});
    });
    var main=A.map&&A.map.cities&&A.map.cities[b.name];
    (A.places||[]).filter(function(p){return p.parent===b.name;}).forEach(function(p,j){
      if(p.type==="ville"){if(!main||main.name!==p.name)return;var lon=0.5,lat=0.45,dir=[Math.cos(lat)*Math.cos(lon),Math.sin(lat),Math.cos(lat)*Math.sin(lon)];
        objs.push({id:"pl:"+p.name,name:p.name+(main.home?" · port d'attache":""),kind:"city",p:[dir[0]*RR,dir[1]*RR,dir[2]*RR],nrm:dir,r:4,home:!!main.home,tap:function(){__map.place(p.name);}});}
      else if(p.type==="station"){var a=-0.6+j*0.5;objs.push({id:"pl:"+p.name,name:p.name,kind:"station",p:[(RR+45)*Math.cos(a),26,(RR+45)*Math.sin(a)],r:5,color:"#86cfc8",tap:function(){__map.place(p.name);}});}});
    /* repères personnels d'Exo (posés par Seeker) */
    var RP=window.__mgGet?__mgGet("reperes"):{};Object.keys(RP).forEach(function(k){var r=RP[k];if(!r)return;var onMoon=moons.find(function(m){return m.name===r.body;});
      if(r.body!==b.name&&!onMoon)return;var h=hash(k),lon=(h%628)/100,lat=((h>>9)%120-60)/100;
      if(onMoon){var mo=objs.find(function(o){return o.id===onMoon.name;});if(!mo)return;objs.push({id:"rp:"+k,name:r.nom,kind:"repere",p:[mo.p[0]+16*Math.cos(lon),mo.p[1]+10,mo.p[2]+16*Math.sin(lon)],r:3,note:r.note,tap:function(){repTap(r,"rp:"+k);}});return;}
      var dir=[Math.cos(lat)*Math.cos(lon),Math.sin(lat),Math.cos(lat)*Math.sin(lon)];objs.push({id:"rp:"+k,name:r.nom,kind:"repere",p:[dir[0]*RR*1.01,dir[1]*RR*1.01,dir[2]*RR*1.01],nrm:dir,r:3,note:r.note,tap:function(){repTap(r,"rp:"+k);}});});
    clearLabels();objs.forEach(function(o){addLabel(o,o.kind==="station"?"st":o.kind==="city"?"city"+(o.home?" home":""):o.kind==="repere"?"rep":"",o.name);});
    SC={view:"body",sys:st.sys,body:b.name,objs:objs,rings:rings,lines:[],grid:null,center:[0,0,0],rad:moons.length?520:330,ph:1.12};
  }

  function repTap(r,id){selId=id;typeTo(T,r.nom.toUpperCase());typeTo(C,(r.note||"Repère personnel").slice(0,60));if(window.mgFx)mgFx.beep();}
  window.__mapRefresh=function(){SC.key="";sync();};
  /* ---------- état et transitions ---------- */
  var cur={view:"",sel:""},firstRun=true;
  function sync(){
    var st=window.__map&&__map.state?__map.state():null;if(!st)return;
    var key=st.view+"|"+st.sys+"|"+(st.view==="body"?st.body:"");
    if(key!==SC.key){var DEP={galaxy:0,system:1,body:2},deeper=DEP[st.view]>(DEP[cur.view]||0);
      if(st.view==="galaxy")sceneGalaxy(st);else if(st.view==="system")sceneSystem(st);else sceneBody(st);SC.key=key;
      if(firstRun||deeper)tgt=SC.center.slice();ph=SC.ph;auto=true;var goal=SC.rad;
      if(!firstRun){rad=deeper?goal*2.2:goal*0.35;radGoal=goal;wrap.classList.remove("arrive");void wrap.offsetWidth;wrap.classList.add("arrive");sweep();}else rad=goal;
      firstRun=false;}
    var sel=st.sel||"";
    if(st.view==="galaxy")selId=sel.indexOf("sys:")===0?sel:null;else selId=sel.indexOf("sys:")===0?null:sel.replace(/^si:/,"pl:");
    var nm=sel.replace(/^(sys|pl|si):/,"");if(nm&&nm!==cur.sel){typeTo(T,nm.toUpperCase());typeTo(C,coordOf(nm));if(window.mgFx&&cur.view)mgFx.beep();}
    cur={view:st.view,sel:nm};
  }
  function enterSys(n){if(wrap._fly)return;var o=SC.objs.find(function(x){return x.id==="sys:"+n;});if(!o){__map.go("sys:"+n);return;}
    selId="sys:"+n;typeTo(T,n.toUpperCase());typeTo(C,coordOf(n));if(window.mgFx)mgFx.beep();
    var s0=tgt.slice(),r0=rad,t0=performance.now(),D=800;wrap._fly=true;radGoal=null;
    (function step(now){var k=Math.min(1,(now-t0)/D),e=k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2;for(var i=0;i<3;i++)tgt[i]=s0[i]+(o.p[i]-s0[i])*e;rad=r0+(40-r0)*e;if(k<1)requestAnimationFrame(step);else{wrap.classList.add("warp");setTimeout(function(){wrap.classList.remove("warp");wrap._fly=false;__map.go("sys:"+n);},240);}})(t0);}


  /* ---------- route de mission (tracée par Seeker) ---------- */
  var RT=null,rcard=document.createElement("div");rcard.className="mfx-route";rcard.hidden=true;wrap.appendChild(rcard);
  function arcPts(a,b,lift,n){var pts=[],d=Math.hypot(b[0]-a[0],b[2]-a[2]),mid=[(a[0]+b[0])/2,Math.max(a[1],b[1])+d*lift,(a[2]+b[2])/2];
    for(var k=0;k<=n;k++){var u=k/n,v=1-u;pts.push([v*v*a[0]+2*v*u*mid[0]+u*u*b[0],v*v*a[1]+2*v*u*mid[1]+u*u*b[1],v*v*a[2]+2*v*u*mid[2]+u*u*b[2]]);}return pts;}
  function objBy(ids){for(var i=0;i<ids.length;i++){if(!ids[i])continue;var o=SC.objs.find(function(x){return x.id===ids[i];});if(o)return o;}return null;}
  function routePts(){if(!RT)return null;var nodes=[];
    if(SC.view==="galaxy"&&RT.path&&RT.path.length>1){RT.path.forEach(function(n){var o=objBy(["sys:"+n]);if(o)nodes.push(o.p);});}
    else if(SC.view==="system"&&SC.sys===RT.sys){RT.anchors.forEach(function(ids){var o=objBy(ids);if(o)nodes.push(o.p);});}
    else if(SC.view==="body"&&RT.body&&SC.body===RT.body){RT.bodyAnchors.forEach(function(ids){var o=objBy(ids);if(o)nodes.push(o.p);});}
    if(nodes.length<2)return null;var mn=[1e9,1e9,1e9],mx=[-1e9,-1e9,-1e9];nodes.forEach(function(n){for(var c=0;c<3;c++){mn[c]=Math.min(mn[c],n[c]);mx[c]=Math.max(mx[c],n[c]);}});
    RT.focus=[(mn[0]+mx[0])/2,(mn[1]+mx[1])/2,(mn[2]+mx[2])/2];RT.span=Math.max(mx[0]-mn[0],mx[2]-mn[2],30);var pts=[];
    for(var i=0;i<nodes.length-1;i++){var seg=arcPts(nodes[i],nodes[i+1],SC.view==="galaxy"?0.12:0.28,48);if(i)seg.shift();pts=pts.concat(seg);}return pts;}
  function drawRoute(t){var P=routePts();if(!P){if(RT){RT.shown=false;RT.focus=null;}return;}
    if(!RT.shown){RT.shown=true;RT.t0=t;radGoal=Math.max(SC.rad*0.35,Math.min(SC.rad*1.4,RT.span*(W<H?2.6:1.7)*(SC.view==="galaxy"?1.5:1)));}
    var S=P.map(proj).filter(Boolean);if(S.length<2)return;
    var L=[0];for(var i=1;i<S.length;i++)L.push(L[i-1]+Math.hypot(S[i][0]-S[i-1][0],S[i][1]-S[i-1][1]));var tot=L[L.length-1]||1;
    var k=Math.min(1,(t-RT.t0)/1600),e=1-Math.pow(1-k,3),lim=tot*e;
    function path(){ctx.beginPath();ctx.moveTo(S[0][0],S[0][1]);for(var j=1;j<S.length&&L[j]<=lim;j++)ctx.lineTo(S[j][0],S[j][1]);if(j<S.length){var f=(lim-L[j-1])/((L[j]-L[j-1])||1);ctx.lineTo(S[j-1][0]+(S[j][0]-S[j-1][0])*f,S[j-1][1]+(S[j][1]-S[j-1][1])*f);}}
    ctx.save();ctx.lineCap="round";
    path();ctx.strokeStyle="rgba(255,179,71,.18)";ctx.lineWidth=9;ctx.stroke();
    path();ctx.setLineDash([10,7]);ctx.lineDashOffset=-t/40;ctx.strokeStyle="rgba(255,196,110,.95)";ctx.lineWidth=2;ctx.stroke();ctx.setLineDash([]);
    function at(d){for(var j=1;j<S.length;j++)if(L[j]>=d){var f=(d-L[j-1])/((L[j]-L[j-1])||1);return [S[j-1][0]+(S[j][0]-S[j-1][0])*f,S[j-1][1]+(S[j][1]-S[j-1][1])*f];}return S[S.length-1];}
    var a=S[0];ctx.strokeStyle="rgba(95,227,240,.95)";ctx.lineWidth=2;ctx.beginPath();ctx.arc(a[0],a[1],7,0,Math.PI*2);ctx.stroke();
    if(k>=1){for(var q=0;q<3;q++){var u=((t/2200)+q/3)%1,pp=at(u*tot);ctx.fillStyle="rgba(255,236,200,"+(1-u*.6).toFixed(2)+")";ctx.beginPath();ctx.arc(pp[0],pp[1],3,0,Math.PI*2);ctx.fill();}
      var z=S[S.length-1],ph2=(t%1400)/1400;ctx.strokeStyle="rgba(255,179,71,"+(1-ph2).toFixed(2)+")";ctx.lineWidth=2;ctx.beginPath();ctx.arc(z[0],z[1],8+ph2*22,0,Math.PI*2);ctx.stroke();
      ctx.fillStyle="#ffb347";ctx.beginPath();ctx.moveTo(z[0],z[1]-9);ctx.lineTo(z[0]+6,z[1]);ctx.lineTo(z[0],z[1]+9);ctx.lineTo(z[0]-6,z[1]);ctx.closePath();ctx.fill();}
    else{var hd=at(lim);ctx.fillStyle="#fff";ctx.shadowColor="#ffb347";ctx.shadowBlur=14;ctx.beginPath();ctx.arc(hd[0],hd[1],4,0,Math.PI*2);ctx.fill();}
    ctx.restore();}
  function esc2(x){return String(x).replace(/[&<>]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;"}[c];});}
  window.__mapRoute={
    set:function(r){RT=r;RT.shown=false;wrap.classList.add("routing");
      rcard.innerHTML='<div class="mr-h"><span>Route · '+esc2(r.titre)+'</span><button type="button" class="mr-x" aria-label="Effacer la route">✕</button></div><ol>'+r.etapes.map(function(x,i){return '<li style="animation-delay:'+(0.25+i*0.22)+'s">'+esc2(x)+'</li>';}).join("")+'</ol>';
      if(r.dest){typeTo(T,r.dest.toUpperCase());typeTo(C,"ROUTE · "+r.etapes.length+" ÉTAPES");}rcard.hidden=false;rcard.classList.remove("in");void rcard.offsetWidth;rcard.classList.add("in");sweep();if(window.mgFx)mgFx.seeker();},
    clear:function(){RT=null;radGoal=SC.rad;rcard.hidden=true;wrap.classList.remove("routing");},
    get:function(){return RT;}};
  rcard.addEventListener("click",function(e){if(e.target.closest(".mr-x"))__mapRoute.clear();});
  ["pointerdown","pointerup"].forEach(function(ev){rcard.addEventListener(ev,function(e){e.stopPropagation();});});

  /* ---------- gestes ---------- */
  var pt={},dragS=null,mv=false;wrap.style.touchAction="pan-y";
  wrap.addEventListener("pointerdown",function(e){pt[e.pointerId]={x:e.clientX,y:e.clientY};mv=false;dragS={x:e.clientX,y:e.clientY,th:th};});
  wrap.addEventListener("pointermove",function(e){if(!pt[e.pointerId])return;var pv=pt[e.pointerId];pt[e.pointerId]={x:e.clientX,y:e.clientY};var ids=Object.keys(pt);
    if(ids.length===2){var a=pt[ids[0]],b=pt[ids[1]],pa=ids[0]==e.pointerId?pv:a,pb=ids[1]==e.pointerId?pv:b;var d0=Math.hypot(pa.x-pb.x,pa.y-pb.y),d1=Math.hypot(a.x-b.x,a.y-b.y);if(d1>0){rad=Math.min(SC.rad*2.5,Math.max(SC.rad*0.15,rad*d0/d1));radGoal=null;auto=false;}mv=true;return;}
    if(!dragS)return;var dx=e.clientX-dragS.x,dy=e.clientY-dragS.y;if(!mv&&Math.hypot(dx,dy)<7)return;if(!mv&&Math.abs(dy)>Math.abs(dx)){dragS=null;mv=true;return;}mv=true;auto=false;th=dragS.th-dx*0.008;});
  function upP(e){delete pt[e.pointerId];if(!Object.keys(pt).length)dragS=null;}
  wrap.addEventListener("pointerup",function(e){var wasMv=mv;upP(e);if(wasMv||e.target.closest(".g3d-l"))return;var r=wrap.getBoundingClientRect(),best=null,bd=30;
    SC.objs.forEach(function(o){if(!o.s||o.hidden||!o.tap)return;var d=Math.hypot(o.s[0]-(e.clientX-r.left),o.s[1]-(e.clientY-r.top))-Math.min(60,o.sr||0);if(d<bd){bd=d;best=o;}});if(best)best.tap();});
  wrap.addEventListener("pointercancel",function(e){upP(e);mv=true;});
  wrap.addEventListener("wheel",function(e){if(!e.ctrlKey&&Math.abs(e.deltaY)<Math.abs(e.deltaX))return;e.preventDefault();auto=false;radGoal=null;rad=Math.min(SC.rad*2.5,Math.max(SC.rad*0.15,rad*(e.deltaY>0?1.1:0.9)));},{passive:false});
  lab.addEventListener("click",function(e){var b=e.target.closest("[data-oid]");if(!b)return;e.stopPropagation();var o=SC.objs.find(function(x){return x.id===b.dataset.oid;});if(o&&o.tap)o.tap();});

  /* ---------- boucle ---------- */
  function size(){if(!stage.clientWidth)return;W=stage.clientWidth;H=svg.getBoundingClientRect().height||stage.clientHeight||420;wrap.style.height=H+"px";cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);cv.style.width=W+"px";cv.style.height=H+"px";}
  window.addEventListener("resize",size);
  var raf=null;
  function loop(){if(raf)return;size();(function frame(t){if(!stage.offsetParent){raf=null;return;}raf=requestAnimationFrame(frame);var hh=svg.getBoundingClientRect().height||stage.clientHeight;if(stage.clientWidth!==W||Math.abs(hh-H)>1)size();var dt=Math.min(50,t-(lastT||t));lastT=t;
    if(auto)th+=dt*0.00005;if(!wrap._fly){var kk=Math.min(1,dt/160);var fc=(RT&&RT.focus)||SC.center;for(var ci=0;ci<3;ci++)tgt[ci]+=(fc[ci]-tgt[ci])*kk;}if(radGoal!==null){rad+=(radGoal-rad)*Math.min(1,dt/140);if(Math.abs(radGoal-rad)<0.5)radGoal=null;}
    camUpdate();var cd=nrm(sub(cam,[0,0,0]));SC.objs.forEach(function(o){if((o.kind==="city"||o.kind==="repere")&&o.nrm)o.hidden=dot(o.nrm,cd)<0.05;});
    if(SC.homeEl){var hs=SC.objs.find(function(o){return o.home;}),hp=hs&&proj(hs.p);if(hp){SC.homeEl.style.display="";SC.homeEl.style.transform="translate("+hp[0].toFixed(1)+"px,"+(hp[1]-40).toFixed(1)+"px) translate(-50%,0)";}else SC.homeEl.style.display="none";}
    render(t);})(performance.now());}
  new MutationObserver(function(){sync();loop();}).observe(svg,{childList:true});
  window.addEventListener("hashchange",function(){if(location.hash==="#carte")setTimeout(function(){size();loop();},30);});
  var hb=mount.querySelector("[data-home]");if(hb)hb.addEventListener("click",function(){auto=true;},true);
  setTimeout(function(){sync();loop();},60);
})();
