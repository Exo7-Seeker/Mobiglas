/* Lecture en pages plein écran (journal et Spectrum) : le texte coule de page en page comme une vraie revue */
(function(){
  var esc=function(t){return String(t==null?"":t).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});};
  var pad=function(n){return (n<10?"0":"")+n;};
  var USED=null;function key(im){return im.src?"src:"+im.src:im.scene?"scene:"+im.scene:im.url?"url:"+im.url:"wiki:"+im.wiki;}
  function fresh(im){if(!im||!USED)return !!im;var k=key(im);if(USED[k])return false;USED[k]=1;return true;}
  function fig(im,cls){if(!im||!fresh(im))return "";USEDF[key(im)]=1;var cc=catOf(im);if(cc)im=Object.assign({},cc,im,{legende:im.legende||cc.legende,wiki:im.wiki||cc.wiki});
    var wk=im.wiki&&window.__WIKI&&__WIKI[im.wiki];if(!wk&&im.url)wk={thumb:im.thumb||im.url,full:im.url};
    if(wk)return '<figure class="rv-fig '+(cls||"")+'"><img src="'+esc(wk.thumb)+'" data-full="'+esc(wk.full)+'" data-fb="'+esc(im.scene||"")+'" data-fbcap="'+esc(im.fbcap||"")+'" alt="'+esc(im.legende||"")+'" onerror="__imgFail(this)">'+(im.legende?'<figcaption>'+esc(im.legende)+'<span class="rv-cred"> · Star Citizen Wiki</span></figcaption>':"")+'</figure>';
var media=im.scene?'<canvas data-scene="'+esc(im.scene)+'" aria-hidden="true"></canvas>':'<img src="'+esc(im.src)+'" alt="'+esc(im.legende||"")+'">';
    return '<figure class="rv-fig '+(cls||"")+'">'+media+(im.legende?'<figcaption>'+esc(im.legende)+'</figcaption>':"")+'</figure>';}


  /* catalogue : chaque image et les passages du récit qu'elle illustre */
  var CAT=[
    {scene:"cockpit",fbcap:"Approche de Teasa : couloir trois, vent de travers",wiki:"Lorville-Teasa-Spaceport-Aerial.jpg",legende:"Approche de Teasa Spaceport, Lorville",kw:/contrôleur|procédure d'approche|couloir trois|cockpit|fréquence cardiaque/i},
    {scene:"lorville",fbcap:"Lorville, vue d'artiste",wiki:"Lorville-buildings-3.19-CIG.jpg",legende:"Lorville sort du smog",kw:/Central Tower|émerge du smog|cheminée/i},
    {scene:"metro",fbcap:"Ligne Perimeter, Lorville",wiki:"Lorville-workers-district-metro-center-3.4.1.jpg",legende:"Ligne Perimeter : les métros qu'il sait encore lire",kw:/métro|angles morts|caméras/i},
    {scene:"lorvillenight",fbcap:"Workers District, la nuit",wiki:"Lorville-workers-district-leavsden-square01-3.4.1.jpg",legende:"Leavsden Square, Workers District",kw:/Workers District|Leavsden/i},
    {scene:"mine",fbcap:"Les mines sous la ville, où travaillait son père",wiki:"Hurston-strip-mine-3.4.1.jpg",legende:"Les mines sous la ville, où travaillait son père",kw:/mines|sous la ville|incident d'exploitation|son père/i},
    {scene:"baraques",fbcap:"Les baraques au-delà des portes",wiki:"Hurston_OuterDistricts_v002.jpg",legende:"Les quartiers au-delà des portes",kw:/baraques|au-delà des portes|a grandi/i},
    {scene:"casse",fbcap:"La casse de Reclamation & Disposal, payé au kilo",wiki:"Lorville-workers-district-reclamation-3.4.1.jpg",legende:"La casse de Reclamation & Disposal, payé au kilo",kw:/Reclamation|Darneely|kilo de métal|gamins/i},
    {scene:"depart",fbcap:"Dix-sept ans : un vieux cargo Drake quitte Teasa",wiki:"Lorville-TeasaSpaceport-Overview-Daytime-Alpha3.17.jpg",legende:"Teasa Spaceport, d'où partent les cargos",kw:/dix-sept ans|cargo Drake|sans prévenir/i},
    {scene:"plaque",wiki:"Lorville-workers-district-L19-vista-3.4.1.jpg",legende:"Workers District : la ville qu'il sait encore lire",kw:/n'est pas revenu|plus personne|sous le smog|seule ville/i},
    {scene:"seul",wiki:"Lorville-workers-district-L19-habroom-3.4.1.jpg",legende:"Seul, ou presque",kw:/pas d'amis|seul|le vide/i},
    {src:"f7c.webp",legende:"Le F7C Hornet : douze ans de contrats aux côtés du capitaine",kw:/se battre|nettoyer|douze ans de contrats|employeurs/i},
    {src:"corsair.webp",legende:"Le Corsair, souvenir des années d'équipage",kw:/escorter|route d'un autre|équipage/i},
    {scene:"area18",wiki:"RSI-Arccorp_03-Min.jpg",legende:"Area18, où les offres ne manquaient pas",kw:/Area18/i},
    {scene:"qt",wiki:"Streaking_Vulture.png",legende:"Le Vulture en saut quantique vers Hurston",kw:/premier saut|route qu'il a tracée/i},
    {scene:"qtpanne",fbcap:"Le moteur quantique lâche, dans l'ombre de Magda",wiki:"Stanton-hurston-magda-orbit-3.17.jpg",legende:"Magda : le Vulture retombe dans son ombre",kw:/moteur quantique|claquement|surchauffe|régulateur/i},
    {scene:"epave",wiki:"Vulture_flying_through_debris_field.jpg",legende:"Le Vulture tourne autour de l'épave, têtes de récupération éteintes",kw:/épave|à la dérive|transpondeur|dépecer|soutes vides/i},
    {scene:"descente",fbcap:"La descente sur Hurston secoue la coque",wiki:"Lorville_redesign_preview_2022-11-22.jpg",legende:"Lorville sous la fumée des usines",kw:/descente sur Hurston|secoué la coque|fumée des usines/i},
    {scene:"hangar",wiki:"Lorville-Teasa-Spaceport-3.19.jpg",legende:"Teasa Spaceport, où l'attend le hangar 10-03",kw:/hangar 10-03|verrière|odeur/i},
    {scene:"hopital",fbcap:"Maria Pure of Heart, aile des soins",wiki:"MariaPureOfHeart.jpg",legende:"Maria Pure of Heart, le premier bilan depuis l'adolescence",kw:/Maria Pure of Heart|bilan médical|hôpital du Workers|résultats étaient bons/i},
    {scene:"entree",fbcap:"Maria Pure of Heart et la statue de Maria Wharton",wiki:"Lorville-workers-district-maria-hospital-3.4.1.jpg",legende:"Maria Pure of Heart, l'hôpital du Workers District",kw:/Maria Wharton|devise|Good health/i},
    {scene:"imprint",wiki:"Hospital_Bed_Regeneration.png",legende:"Régénération : désormais, s'il tombe, c'est ici qu'il revient",kw:/imprint|borne d'assurance|régénération doit/i},
    {src:"vulture.webp",legende:"Le Vulture sous les néons du monte-charge n°4",kw:/Vulture garé|monte-charge|coque taguée/i},
    {scene:"bar",wiki:"Lorville-workers-district-MV-bar-3.4.1.jpg",legende:"Le bar où il n'est pas allé",kw:/au bar/i},
    {scene:"hurston",fbcap:"Hurston depuis l'orbite",wiki:"Hurston-4.3.jpg",legende:"Hurston, la planète-usine",kw:/Hurston/i,weak:1}
  ];
  function catOf(im){return CAT.find(function(c){return key(c)===key(im);});}
  function score(c,text){if(USEDF[key(c)])return 0;var m=String(text).match(new RegExp(c.kw.source,"gi"));return m?m.length*(c.weak?0.3:1):0;}
  var USEDF={};
  function pickFor(text){var best=null,bs=0;CAT.forEach(function(c){var s=score(c,text);if(s>bs){bs=s;best=c;}});return best?{im:best,s:bs}:null;}

  window.__imgFail=function(img){if(img.dataset.full&&img.getAttribute("src")!==img.dataset.full){img.src=img.dataset.full;return;}var fg0=img.closest("figure");if(fg0){fg0.remove();return;}var sc=img.dataset.fb;if(!sc){img.style.display="none";return;}
    var c=document.createElement("canvas");c.dataset.scene=sc;c.setAttribute("aria-hidden","true");var fg=img.parentNode;img.replaceWith(c);var cr=fg&&fg.querySelector(".rv-cred");if(cr)cr.remove();var fc=fg&&fg.querySelector("figcaption");if(fc&&img.dataset.fbcap)fc.textContent=img.dataset.fbcap;if(window.__drawCanvas)requestAnimationFrame(function(){__drawCanvas(c);c._drawn=c.clientWidth;});};
  /* ---------- lecteur générique ---------- */
  function Reader(panel,sections,opt){
    [].slice.call(panel.children).forEach(function(c){if(!c.classList.contains("rv"))c.classList.add("rv-hide");});
    var old=panel.querySelector(".rv");if(old)old.remove();
    var rv=document.createElement("div");rv.className="rv "+(opt.cls||"");
    rv.innerHTML='<div class="rv-view"><div class="rv-flow">'+sections.map(function(s,i){return '<section class="rv-sec '+(s.cls||"")+'" data-sec="'+i+'">'+s.html+'</section>';}).join("")+'</div></div>'+
      '<div class="rv-bar"><button type="button" class="rv-nav" data-d="-1" aria-label="Page précédente">‹</button><button type="button" class="rv-pg" data-toc aria-label="Sommaire"><span class="rv-n">01</span> / <span class="rv-t">01</span></button><button type="button" class="rv-nav" data-d="1" aria-label="Page suivante">›</button></div>';
    panel.appendChild(rv);
    var view=rv.querySelector(".rv-view"),flow=rv.querySelector(".rv-flow"),nEl=rv.querySelector(".rv-n"),tEl=rv.querySelector(".rv-t"),W=0,N=1,cur=0;
    function layout(){if(!rv.isConnected)return;tries={};
      [].slice.call(flow.querySelectorAll(".rv-fig.rv-auto")).forEach(function(f){var c=f.querySelector("canvas[data-scene]"),im=f.querySelector("img");delete USEDF[c?"scene:"+c.dataset.scene:(im&&im.dataset.fb?"scene:"+im.dataset.fb:"src:"+(im&&im.getAttribute("src")))];f.remove();});
      var top=view.getBoundingClientRect().top,barH=rv.querySelector(".rv-bar").offsetHeight||44;
      var Hh=Math.max(360,window.innerHeight-Math.max(0,top)-barH-6);W=view.clientWidth;
      rv.style.setProperty("--rv-h",Hh+"px");rv.style.setProperty("--rv-w",W+"px");
      flow.style.transition="none";
      requestAnimationFrame(function(){N=Math.max(1,Math.round(flow.scrollWidth/W));if(opt.pool)fillPages();tEl.textContent=pad(N);if(cur>N-1)cur=N-1;place(false);
        if(opt.onLayout)opt.onLayout(secPage);paint();});
    }

    var tries={};
    function pageOf(el){return Math.max(0,Math.floor((el.getBoundingClientRect().left-flow.getBoundingClientRect().left+2)/W));}
    function fillPages(){var all=flow.textContent;
      function real(c){return c.wiki||c.src;}function reserve(){return CAT.find(function(c){return real(c)&&!USEDF[key(c)]&&!c.weak&&!c.kw.test(all);})||CAT.find(function(c){return real(c)&&!USEDF[key(c)]&&c.weak;})||CAT.find(function(c){return real(c)&&!USEDF[key(c)];});}
      for(var pass=0;pass<40;pass++){
        var has={};[].slice.call(flow.querySelectorAll(".rv-fig,.rv-cover")).forEach(function(f){has[pageOf(f)]=1;});
        var miss=-1;for(var p=0;p<N;p++)if(!has[p]&&!tries[p]){miss=p;break;}if(miss<0)break;tries[miss]=1;
        var blocks=[].slice.call(flow.querySelectorAll(".rv-sec>*:not(.rv-fig):not(.rv-body),.rv-body>*:not(.rv-fig)")).filter(function(b){return pageOf(b)===miss;});if(!blocks.length)continue;
        var best=null,bs=0;CAT.forEach(function(cc){var sc=0;blocks.forEach(function(b,k){sc+=score(cc,b.textContent)/(1+2*k);});if(sc>bs){bs=sc;best=cc;}});var im=best||reserve();if(!im)break;
        var vt=view.getBoundingClientRect().top,spots=[];blocks.forEach(function(b,k){if(k||Math.abs(b.getBoundingClientRect().top-vt)>30)spots.push([b,"beforebegin"]);spots.push([b,"afterend"]);});
        var ok=false;for(var sz=0;sz<2&&!ok;sz++)for(var k=0;k<spots.length&&!ok;k++){spots[k][0].insertAdjacentHTML(spots[k][1],fig(im,sz?"rv-sm rv-auto":"rv-auto"));
          var f=spots[k][1]==="afterend"?spots[k][0].nextElementSibling:spots[k][0].previousElementSibling;
          if(f&&pageOf(f)===miss&&Math.round(flow.scrollWidth/W)>=N)ok=true;else{if(f)f.remove();delete USEDF[key(im)];if(USED)delete USED[key(im)];}}
        N=Math.max(1,Math.round(flow.scrollWidth/W));}
      tEl.textContent=pad(N);}
    function secPage(i){var s=flow.querySelector('[data-sec="'+i+'"]');if(!s)return 0;var fl=flow.getBoundingClientRect().left+cur*0;return Math.max(0,Math.floor((s.getBoundingClientRect().left-flow.getBoundingClientRect().left+2)/W));}
    function place(anim){flow.style.transition=anim?"transform .45s cubic-bezier(.3,.7,.2,1)":"none";flow.style.transform="translateX("+(-cur*W)+"px)";nEl.textContent=pad(cur+1);
      rv.classList.remove("turn");if(anim){void rv.offsetWidth;rv.classList.add("turn");}}
    function go(i){i=Math.max(0,Math.min(N-1,i));if(i===cur)return;cur=i;place(true);if(window.mgFx)mgFx.tick();setTimeout(paint,460);}
    function paint(){[].slice.call(flow.querySelectorAll("canvas[data-scene]")).forEach(function(c){if(c.clientWidth&&window.__drawCanvas&&c._drawn!==c.clientWidth){__drawCanvas(c);c._drawn=c.clientWidth;}});}
    rv.addEventListener("click",function(e){var b=e.target.closest("[data-d],[data-toc],[data-gosec]");if(!b)return;
      if(b.dataset.d)go(cur+parseInt(b.dataset.d,10));else if(b.hasAttribute("data-toc"))go(opt.tocSec!=null?secPage(opt.tocSec):0);else go(secPage(parseInt(b.dataset.gosec,10)));});
    /* glisser = tourner la page ; toucher les bords = page suivante/précédente */
    var sx=null,sy=null,st=0;view.style.touchAction="pan-y";
    view.addEventListener("pointerdown",function(e){sx=e.clientX;sy=e.clientY;st=Date.now();});
    view.addEventListener("pointerup",function(e){if(sx===null)return;var dx=e.clientX-sx,dy=e.clientY-sy;sx=null;
      if(Math.abs(dx)>40&&Math.abs(dx)>Math.abs(dy)){go(cur+(dx<0?1:-1));return;}
      if(Math.abs(dx)<8&&Math.abs(dy)<8&&Date.now()-st<400&&!e.target.closest("a,button,.term,[data-gosec]")){var r=view.getBoundingClientRect(),x=e.clientX-r.left;if(x>r.width*0.78)go(cur+1);else if(x<r.width*0.22)go(cur-1);}});
    var rT=null;window.addEventListener("resize",function(){clearTimeout(rT);rT=setTimeout(function(){if(rv.isConnected&&panel.offsetParent&&view.clientWidth!==W)layout();},150);});
    window.addEventListener("hashchange",function(){if(rv.isConnected&&!panel.hidden&&panel.offsetParent)setTimeout(layout,40);});
    if(window.__linkTerms)try{__linkTerms(flow);}catch(e){}
    if(!panel.hidden)setTimeout(layout,40);
    if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){if(panel.offsetParent)layout();});
    return {layout:layout,go:go};
  }

  /* ---------- mode lecture : pas de défilement de la page ---------- */
  function readingMode(){var t=location.hash.slice(1);document.documentElement.classList.toggle("mg-reading",t==="journal");}
  window.addEventListener("hashchange",readingMode);

  /* ---------- JOURNAL ---------- */
  function buildJournal(){
    var panel=document.getElementById("tab-journal");if(!panel)return;
    var J=window.__mgGet?__mgGet("journal"):{};
    var entries=Object.keys(J).map(function(k){return J[k];}).sort(function(a,b){return a.ordre-b.ordre;}),last=entries[entries.length-1];
    USED={"src:exo.webp":1};
    var lede=panel.querySelector(".lede"),passe=panel.querySelector("#passe .text"),S=[];
    S.push({cls:"rv-cover",t:"Couverture",html:
      '<div class="rv-cov-img"><img src="exo.webp" alt="Exo devant son Vulture"></div>'+
      '<div class="rv-cov-top"><div class="rv-mast">EXO</div><div class="rv-issue">Journal de bord · N°'+pad(last?last.ordre:0)+' · '+esc(last?last.date:"2956")+'</div></div>'+
      '<div class="rv-cov-lines"><div class="rv-cl big">'+esc(last?last.titre:"Retour à Lorville")+'</div><div class="rv-cl">Retour à Lorville <span>· Prologue</span></div><div class="rv-cl">Le marginal de Lorville <span>· Souvenirs</span></div><div class="rv-cl">Maria Pure of Heart, l\'hôpital d\'une famille <span>· N°'+pad(last?last.ordre:0)+'</span></div></div>'+
      '<div class="rv-swipe">Glisse pour tourner la page →</div>'});
    S.push({cls:"rv-tocs",t:"Sommaire",html:'<div class="rv-kick">Dans ce numéro</div><h2 class="rv-h">Sommaire</h2><ol class="rv-toc" id="rv-toc-j"></ol>'});
    var arts=[];
    if(lede){arts.push({t:"Retour à Lorville",k:"Prologue · Entrée 0",html:fig({scene:"lorville",legende:"Approche de Teasa : la Central Tower perce le smog"},"rv-hero")+'<div class="rv-kick">Prologue · Entrée 0 · Octobre 2956</div><h2 class="rv-h">Retour à Lorville</h2><div class="rv-body rv-drop">'+[].slice.call(lede.querySelectorAll("p")).map(function(p){return p.outerHTML;}).join("")+'</div><div class="rv-end">■</div>'});}
    if(passe){var title=(passe.querySelector("h2")||{}).textContent||"Origines",ps=[].slice.call(passe.querySelectorAll("p")).map(function(p){return p.outerHTML;});
      arts.push({t:title,k:"Souvenirs",cls:"rv-flash",html:fig({scene:"lorvillenight",legende:"Workers District, la nuit. Mémoire de Seeker, fichier restauré"},"rv-hero")+'<div class="rv-kick">Souvenir · Lorville · 2921 → 2938</div><h2 class="rv-h">'+esc(title)+'</h2><div class="rv-body rv-drop">'+ps.join("")+'</div><div class="rv-end">■</div>'});}
    entries.forEach(function(e){var paras=e.paragraphes||[],own=(e.images||[]).map(function(im){return im.scene==="salvage"?Object.assign({},im,{scene:"epave"}):im;}).filter(function(im){return !USED[key(im)];});
      /* image d'ouverture : celle qui illustre le premier paragraphe */
      var h0=pickFor(paras[0]||""),hero=h0?h0.im:(own.shift()||null);own=own.filter(function(im){return !hero||key(im)!==key(hero);});
      /* chaque image du récit va juste après le paragraphe qu'elle raconte */
      var after={};own.forEach(function(im){var c=catOf(im)||{kw:new RegExp((im.legende||"").split(/\W+/).filter(function(w){return w.length>5;}).join("|")||"$^","i")},bi=paras.length-1,bs=0;
        paras.forEach(function(p,k){var m=String(p).match(new RegExp(c.kw.source,"gi"));if(m&&m.length>bs){bs=m.length;bi=k;}});(after[bi]=after[bi]||[]).push(im);});
      var body="";paras.forEach(function(p,k){body+='<p>'+esc(p)+'</p>';if(k===1&&e.seeker)body+='<blockquote class="rv-pull voice-line">'+esc(e.seeker)+'<span>Seeker, IA de bord</span></blockquote>';(after[k]||[]).forEach(function(im){body+=fig(im);});});
      arts.push({t:e.titre,k:e.numero,html:fig(hero,"rv-hero")+'<div class="rv-kick">'+esc(e.numero)+' · '+esc(e.date)+' · '+esc(e.lieu)+'</div><h2 class="rv-h">'+esc(e.titre)+'</h2><div class="rv-body rv-drop">'+body+'</div><div class="rv-end">■</div>'});});
    arts.forEach(function(a){S.push({cls:a.cls||"",t:a.t,k:a.k,html:a.html});});
    var POOL=[{scene:"cockpit",legende:"Approche de Hurston depuis le cockpit du Vulture"},{scene:"hangar",legende:"Hangar 10-03, Teasa Spaceport"},{scene:"metro",legende:"Ligne Perimeter, Lorville"},{scene:"hopital",legende:"Maria Pure of Heart, aile des soins"},{src:"f7c.webp",legende:"Le F7C Hornet d'Exo"},{scene:"qt",legende:"Saut quantique"},{src:"corsair.webp",legende:"Le Corsair d'Exo"},{scene:"raid",legende:"Douze ans de contrats : souvenirs de combat"},{scene:"convoi",legende:"Escorte de convoi, du temps de l'équipage"},{scene:"stanton",legende:"Stanton, l'étoile du système"},{scene:"area18",legende:"Area18, ArcCorp"},{scene:"crusader",legende:"Crusader, la géante gazeuse"},{scene:"orison",legende:"Orison, les plateformes dans les nuages"},{scene:"nyx",legende:"Nyx, aux confins"},{scene:"pyro",legende:"Pyro, de l'autre côté du point de saut"},{scene:"earth",legende:"La Terre, berceau de l'humanité"}].filter(function(im){return !USED[key(im)];});
    var used2=USED;USED=null;
    Reader(panel,S,{cls:"rv-journal",pool:POOL.map(function(im){return im;}),tocSec:1,onLayout:function(secPage){var ol=document.getElementById("rv-toc-j");if(!ol)return;ol.innerHTML=S.map(function(s,i){return i<2?"":'<li><button type="button" data-gosec="'+i+'"><span class="n">'+pad(secPage(i)+1)+'</span><span class="t">'+esc(s.t)+'</span>'+(s.k?'<span class="k">'+esc(s.k)+'</span>':"")+'</button></li>';}).join("");}});
  }

  /* ---------- SPECTRUM : la une, puis l'article s'ouvre ---------- */
  var RUBSCENE={Stanton:"orison",Politique:"senat",Diplomatie:"convoi",Nyx:"raid",Hurston:"metro",Pyro:"pyro"};
  function imgOf(a){return a.image||{scene:RUBSCENE[a.rubrique]||"stanton"};}
  function thumb(im){var wk=im.wiki&&window.__WIKI&&__WIKI[im.wiki];if(wk)return '<img src="'+esc(wk.thumb)+'" data-full="'+esc(wk.full)+'" alt="" onerror="if(this.src!==this.dataset.full)this.src=this.dataset.full;else this.style.visibility=\'hidden\'">';return im.scene?'<canvas data-scene="'+esc(im.scene)+'" aria-hidden="true"></canvas>':'<img src="'+esc(im.src)+'" alt="">';}
  function buildSpectrum(){
    var panel=document.getElementById("tab-spectrum");if(!panel)return;
    var D=window.__mgGet?__mgGet("spectrum"):{},eds=Object.keys(D).map(function(k){return D[k];}).sort(function(a,b){return b.ordre-a.ordre;}),ed=eds[0]||{titres:[]};
    var arts=(ed.articles&&ed.articles.length)?ed.articles:(ed.titres||[]),lead=arts[0]||{};
    var S=[];
    S.push({cls:"sp-une",html:'<div class="sp-mast">SPECTRUM</div><div class="sp-line"><span>Édition '+esc(ed.edition||"")+'</span><span>Réseau d\'information de l\'UEE</span></div>'+
      '<button type="button" class="sp-lead" data-art="0"><span class="sp-lead-img">'+thumb(imgOf(lead))+'</span><span class="sp-rub">'+esc(lead.rubrique||"")+(lead.source?' · '+esc(lead.source):"")+'</span><span class="sp-lead-t">'+esc(lead.titre||"")+'</span></button>'+
      '<ul class="sp-heads">'+arts.slice(1).map(function(a,i){return '<li><button type="button" data-art="'+(i+1)+'"><span class="sp-th">'+thumb(imgOf(a))+'</span><span class="sp-ht"><span class="sp-rub">'+esc(a.rubrique)+(a.source?' · '+esc(a.source):"")+'</span>'+esc(a.titre)+'</span></button></li>';}).join("")+'</ul>'+
      (ed.annonce?'<div class="sp-flash"><b>Flash</b> '+esc(ed.annonce)+'</div>':"")});
    [].slice.call(panel.querySelectorAll("aside.interlude")).forEach(function(a){var tag=(a.querySelector(".il-tag")||{}).textContent||"Annonce",p=a.querySelector("p"),sp=p&&p.querySelector("span"),q=p?p.firstChild&&p.firstChild.nodeValue:"";
      S.push({cls:"sp-ad",html:'<div class="sp-ad-in"><div class="sp-ad-tag">'+esc(tag)+'</div><div class="sp-ad-q">'+esc((q||"").trim())+'</div>'+(sp?'<div class="sp-ad-s">'+esc(sp.textContent)+'</div>':"")+'</div>'});});
    Reader(panel,S,{cls:"rv-spectrum",tocSec:0});
    var ov=document.createElement("div");ov.className="sp-open";ov.hidden=true;ov.innerHTML='<div class="sp-top"><button type="button" class="sp-back">‹ À la une</button><span class="sp-top-ed">Spectrum · '+esc(ed.edition||"")+'</span></div><div class="sp-host"></div>';panel.appendChild(ov);
    function close(){if(ov.hidden)return;ov.classList.add("out");setTimeout(function(){ov.hidden=true;ov.classList.remove("out");},260);}
    function open(i){var a=arts[i];if(!a)return;var paras=String(a.texte||"").split(/(?<=[.!?»])\s+(?=[A-ZÀ-Ý«])/),half=Math.ceil(paras.length/2);
      ov.style.top=Math.max(0,panel.getBoundingClientRect().top)+"px";ov.hidden=false;ov.classList.remove("in");void ov.offsetWidth;ov.classList.add("in");
      Reader(ov.querySelector(".sp-host"),[{cls:"sp-arts",html:fig(Object.assign({},imgOf(a)),"rv-hero")+'<div class="sp-src"><b>'+esc(a.source||"Spectrum")+'</b><span>'+esc(ed.edition||"")+' · '+pad(i+1)+'/'+pad(arts.length)+'</span></div><div class="sp-rub">'+esc(a.rubrique)+'</div><h3>'+esc(a.titre)+'</h3><div class="rv-body sp-body">'+paras.map(function(p){return '<p>'+esc(p)+'</p>';}).join("")+'</div>'+
        (i+1<arts.length?'<button type="button" class="sp-next" data-art="'+(i+1)+'">Article suivant · '+esc(arts[i+1].titre)+' ›</button>':'<button type="button" class="sp-next sp-home">‹ Retour à la une</button>')}],{cls:"rv-spectrum"});
      if(window.mgFx)mgFx.open();}
    panel.addEventListener("click",function(e){var b=e.target.closest("[data-art]");if(b){e.stopPropagation();open(parseInt(b.dataset.art,10));return;}if(e.target.closest(".sp-back,.sp-home"))close();});
    window.addEventListener("hashchange",function(){ov.hidden=true;});
  }

  /* le livre (book.js) reprend le catalogue d'images ; l'ancien lecteur n'est plus lancé */
  window.__rvCat={CAT:CAT,key:key,catOf:catOf};
  (window.__mgReady||Promise.resolve()).then(function(){setTimeout(readingMode,0);});
})();
