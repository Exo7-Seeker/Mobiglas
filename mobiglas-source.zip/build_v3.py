import re, json, html as H
ns = {}
exec(open('build_tabs.py', encoding='utf-8').read(), ns)
g = lambda k: ns[k]
esc = H.escape
data = g('data')

def slug(s):
    import unicodedata
    s = unicodedata.normalize('NFD', s); s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9]+', '-', s.lower()).strip('-')

# ---------------- ships
STORY = {
 "f7c": "Son premier vaisseau, acheté avec des années d'économies de matelot. Un chasseur civil, nerveux, avec un vide dans le dos là où les militaires montent une tourelle.",
 "vulture": "Un charognard de chez Drake, le seul bien qu'il possède assuré à vie. Le métier de la cour de Darneely, en plus grand.",
 "corsair": "Le plus gros achat de sa vie. Drake le vend comme un explorateur ; tout le monde sait que c'est six canons avec des ailes et une soute. Quatre lits, dont trois toujours vides. Le cœur de Seeker est câblé derrière la console.",
 "pulse": "Rangé dans la soute du Corsair, pour les derniers kilomètres, là où aucun vaisseau ne se pose.",
}
SHORT = {"f7c": "F7C", "vulture": "Vulture", "corsair": "Corsair", "pulse": "Pulse"}
SICON = {"f7c": "fighter", "vulture": "salvager", "corsair": "heavy", "pulse": "bike"}
EICON = {"f7c-ball": "turret", "f7c-nose": "noseturret", "f7c-ad4b": "gatling", "f7c-mantis": "gatling", "vul-cinch": "head_cinch", "vul-trawler": "head_trawler", "vul-abrade": "head_abrade", "cor-guns": "guns", "cor-shield": "shield", "cor-qd": "quantum"}
ships = []
for s in g('SHIPS'):
    ships.append(dict(id=s["id"], nom=s["nom"], maker=s["maker"], role=s["role"], short=SHORT[s["id"]], icon=SICON[s["id"]], story=STORY[s["id"]],
                      specs=s["specs"], evo=[dict(id=e[0], nom=e[1], effet=e[2], ou=e[3], icon=EICON[e[0]]) for e in s["evo"]]))

# ---------------- contacts
exo_html = '<p>Né en 2921 dans le Workers District de Lorville. Marginal, pilote indépendant, ni hors-la-loi ni respectueux des règles. Son histoire complète est dans l\'onglet Journal, partie Passé.</p>' + g('exo_fiche')
contacts = [
 dict(id="exo", cat="Équipage", title="Exo", sub="Pilote indépendant · Lorville", mk="Le locataire du hangar de Teasa", tag="Civil", icon="person", html=exo_html),
 dict(id="seeker", cat="Équipage", title="Seeker", sub="IA de bord · non déclarée", mk="Intelligence de bord", tag="Seul ami d'Exo", icon="ai", html=g('seeker_cols')),
]
def _parent(pid, name, role, born, died, job, txt):
    return dict(id=pid, cat="Famille", title=name, sub=role + " · décédé" + ("e" if "Mère" in role else ""), mk=role, tag="In memoriam", icon="person", dim=True,
                html='<p>' + txt + '</p><aside class="data"><h3>Fiche · registre de Lorville</h3><dl><dt>Lien</dt><dd>' + role + ' d\'Exo</dd><dt>Naissance</dt><dd>' + born + '</dd><dt>Décès</dt><dd>' + died + '</dd><dt>Employeur</dt><dd>' + job + '</dd><dt>Domicile</dt><dd>Workers District, Lorville, près de Leavsden Square</dd></dl></aside>')
contacts.append(_parent("fam-pere", "Marek Halden", "Père", "2893, Lorville", "2932, mines sous Lorville · « incident d'exploitation »", "Hurston Dynamics · contrat longue durée (mineur)",
    "Mineur sous la ville pendant vingt ans. Le rapport tenait en trois lignes, sans responsable. Son contrat, lui, n'est pas mort : la dette est passée à la famille."))
contacts.append(_parent("fam-mere", "Ilsa Halden", "Mère", "2897, Lorville", "2938, Lorville", "Hurston Dynamics · contrat longue durée",
    "Après la mort de Marek, elle a quitté le Workers District avec son fils pour les baraques au-delà des portes. Elle s'est éteinte quand il avait dix-sept ans. C'est ce jour-là qu'Exo est parti."))
for n, b, c in g('known'):
    contacts.append(dict(id="k-" + slug(n), cat="Connus de réputation", title=n, sub=b, mk=b, icon="person", html=f'<p>{esc(c)}</p>', dim=True))

# ---------------- codex
def chap_title(html):
    m = re.search(r'<h2>(.*?)</h2>', html); return H.unescape(re.sub('<.*?>', '', m.group(1))) if m else ''
codex = []
for key, var, sub in [("empire", "empire", "Histoire de l'UEE"), ("stanton", "stanton", "Le système et ses puissances"), ("hurston", "hurston", "La planète-usine"),
                      ("lorville", "lorville", "La ville d'Exo"), ("ombres", "ombres", "Nine Tails, régénération"), ("au-dela", "audela", "Pyro et Nyx")]:
    html = g(var)
    codex.append(dict(id="ch-" + key, cat="Histoire et lieux", title=chap_title(html), sub=sub, icon="book", html=html, text=re.sub('<.*?>', ' ', html)[:4000]))
for p in data["peoples_h"]:
    codex.append(dict(id="pe-" + slug(p["n"]), cat="Peuples", title=p["n"], sub=p["t"], mk=p["t"], icon="people", paras=[p["d"]], text=p["d"]))
for p in data["peoples_a"]:
    codex.append(dict(id="pe-" + slug(p["n"]), cat="Peuples", title=p["n"], sub=p["t"], mk=p["t"], icon="people", paras=[p["d"]], text=p["d"]))
for n, c, w, d in g('FAUNA'):
    codex.append(dict(id="fa-" + slug(n), cat="Faune", title=n, sub=c, mk=c, where=w, icon="fauna", paras=[d], text=w + " " + d))
for n, w, d in g('FLORA'):
    codex.append(dict(id="fl-" + slug(n), cat="Flore", title=n, sub=w, mk="Flore · " + w, icon="flora", paras=[d], text=d))
for grp in data["factions"]:
    for it in grp["items"]:
        codex.append(dict(id="fc-" + slug(it["n"]), cat="Factions", title=it["n"], sub=grp["g"], mk="Faction · " + grp["g"], icon="faction", paras=[it["d"]], text=it["d"]))
lex = g('lexique')
for gm in re.finditer(r'<div class="lex-group"><h3>(.*?)</h3><dl>(.*?)</dl></div>', lex, re.S):
    grp = H.unescape(gm.group(1))
    for im in re.finditer(r'<div id="(lex-[^"]+)"><dt>(.*?)</dt><dd>(.*?)</dd></div>', gm.group(2), re.S):
        t, d = H.unescape(im.group(2)), H.unescape(im.group(3))
        codex.append(dict(id=im.group(1), cat="Lexique", title=t, sub=grp, mk="Lexique · " + grp, icon="term", paras=[d], text=d))
codexCats = ["Histoire et lieux", "Peuples", "Faune", "Flore", "Factions", "Lexique"]

# ---------------- map config
MAP = dict(
 cities={"Hurston": {"name": "Lorville", "home": True}, "Crusader": {"name": "Orison"}, "ArcCorp": {"name": "Area18"}, "microTech": {"name": "New Babbage"}, "Delamar": {"name": "Levski"}},
 galaxy=dict(nodes={
   "Stanton": dict(x=500, y=320, r=16, color="#ffd27a"),
   "Pyro": dict(x=220, y=410, r=14, color="#ff7a45"),
   "Nyx": dict(x=780, y=190, r=13, color="#bcd4ff"),
   "Magnus": dict(x=330, y=150, r=7, color="#9aa3ad", faded=True),
   "Terra": dict(x=760, y=470, r=9, color="#9aa3ad", faded=True),
   "Hadrian": dict(x=560, y=545, r=7, color="#9aa3ad", faded=True)},
  links=[["Stanton", "Pyro", False], ["Stanton", "Nyx", True], ["Pyro", "Nyx", False], ["Stanton", "Magnus", False], ["Stanton", "Terra", False], ["Stanton", "Hadrian", False]]),
 layout={
  "Stanton": {"Hurston": dict(r=95, a=200, s=16), "Crusader": dict(r=160, a=330, s=24), "Aaron Halo": dict(ring=True, r=200, la=95),
              "ArcCorp": dict(r=235, a=110, s=15), "microTech": dict(r=290, a=245, s=15), "Installations Onyx": dict(special=True, x=860, y=560)},
  "Pyro": {"Pyro I": dict(r=75, a=30, s=10), "Monox": dict(r=120, a=150, s=11), "Bloom": dict(r=165, a=265, s=12), "Pyro IV": dict(r=210, a=10, s=11),
           "Pyro V": dict(r=255, a=120, s=24), "Terminus": dict(r=295, a=220, s=13), "Stations de Pyro": dict(special=True, x=860, y=560)},
  "Nyx": {"Nyx I": dict(r=85, a=300, s=11), "Nyx II": dict(r=135, a=160, s=13), "Glaciem Ring": dict(ring=True, r=185, la=270), "Delamar": dict(r=185, a=35, s=9),
          "Nyx III": dict(r=240, a=215, s=20), "Keeger Belt": dict(ring=True, r=295, la=88)},
 })

exec(open("lore_merge.py",encoding="utf-8").read())
_P=json.load(open('places.json',encoding='utf-8'))['places']
for _p in _P:
    if _p['sys']=='Nyx' and _p['name']=='Pyro Gateway': _p['name']='Pyro Gateway (Nyx)'
    for _k in ('lp','owner','services','notes'): _p.setdefault(_k,'')
_AC=json.load(open('access.json',encoding='utf-8'))['places']
_SI=[]
for _f in ('sites_hc.json','sites_am.json','sites_pn.json'): _SI+=json.load(open(_f,encoding='utf-8'))['sites']
APP = dict(access=_AC, sites=_SI, places=_P, ships=ships, contacts=contacts, codex=codex, codexCats=codexCats, bodies=data["bodies"], systems=data["systems"], tags=data["tags"], map=MAP)
appjs = open('app_v3.js', encoding='utf-8').read().replace('__APP__', json.dumps(APP, ensure_ascii=False).replace('</', '<\\/'))

# ---------------- panels
def panel(k, inner, label):
    return f'  <section class="tab-panel" id="tab-{k}" role="tabpanel" aria-label="{label}" hidden>\n{inner}\n  </section>'
carte = '''  <div id="map-mount"></div>'''
hangar = '''  <div id="hangar-mount"></div>'''
contacts_p = '''  <div class="text"><h2>Contacts</h2><p class="tab-intro">Exo, Seeker, ceux qu'il connaît de réputation, et ceux qu'il rencontre au fil des sessions.</p></div>
  <div id="contacts-mount"></div>'''
codex_p = '''  <div class="text"><h2>Codex</h2><p class="tab-intro">L'univers de 2956 rangé comme un inventaire : histoire et lieux, peuples, faune, flore, factions, lexique.</p></div>
  <div id="codex-mount"></div>'''

_j = g('journal'); _ci = _j.index('  <div class="tl-head"><span class="tl-mark">Cap</span>')
journal_only = _j[:_ci].rstrip() ; cap_only = _j[_ci:]
cap_p = '''  <div id="cap" class="cap"><p class="empty-note">Aucun objectif déclaré pour l'instant.</p></div>'''
header_v = g('header').replace('data-tab="journal" aria-selected="false">Journal</a>', 'data-tab="journal" aria-selected="false">Journal</a>\n    <a class="tab" role="tab" href="#cap" data-tab="cap" aria-selected="false">Cap</a>')
assert header_v != g('header')
body = '<div class="wrap">\n' + header_v + '\n' + '\n'.join([
    panel("cap", cap_p, "Cap"),
    panel("journal", journal_only, "Journal"), panel("carte", carte, "Carte"), panel("hangar", hangar, "Hangar"),
    panel("contacts", contacts_p, "Contacts"), panel("codex", codex_p, "Codex"), panel("spectrum", g('spectrum'), "Spectrum")]) + '\n' + g('footer') + '\n</div>'

# ---------------- scripts
script = g('script').replace('window.__redraw=drawAll;', 'window.__redraw=drawAll;window.__drawCanvas=draw;', 1)
assert 'window.__drawCanvas' in script
tabjs = g('tabjs').replace('const TABS=["journal",','const TABS=["journal","cap",')
a = tabjs.index('  // HANGAR'); b = tabjs.index('  // SPECTRUM'); tabjs = tabjs[:a] + tabjs[b:]
tabjs = tabjs.replace('function tabFor(id){if(TABS.includes(id))return id;',
                      'function tabFor(id){if(TABS.includes(id))return id;if(id&&id.startsWith("lex-"))return "codex";')
tabjs = tabjs.replace('requestAnimationFrame(()=>{if(anchor&&anchor!==t){',
                      'if(anchor&&anchor.startsWith("lex-")&&window.__codexSelect){window.__codexSelect(anchor);requestAnimationFrame(()=>{const d=document.querySelector("#tab-codex .inv-detail");if(d)d.scrollIntoView({block:"start"});});return;}\n    requestAnimationFrame(()=>{if(anchor&&anchor!==t){')
assert 'window.__codexSelect(anchor)' in tabjs

css = '''
/* ---------- inventory ---------- */
.inv{display:grid;grid-template-columns:minmax(260px,340px) minmax(0,1fr);gap:20px;margin-top:22px;align-items:start}
@media (max-width:820px){.inv{grid-template-columns:minmax(0,1fr)}}
.inv-side{position:sticky;top:112px;max-height:calc(100vh - 130px);display:grid;grid-template-rows:auto auto minmax(0,1fr);gap:10px;border:1px solid var(--line);background:var(--hull);padding:12px;scroll-margin-top:110px}
@media (max-width:820px){.inv-side{position:static;max-height:60vh}}
.inv-search{background:var(--void);border:1px solid var(--line);padding:9px 11px;font-family:var(--mono);font-size:12.5px;color:var(--star);width:100%}
.inv-search::placeholder{color:var(--faint)}
.inv-cats{display:flex;flex-wrap:wrap;gap:5px}
.inv-cat{background:transparent;border:1px solid var(--line);color:var(--dim);font-family:var(--mono);font-size:9.5px;letter-spacing:.08em;text-transform:uppercase;padding:5px 8px;cursor:pointer}
.inv-cat[aria-pressed="true"]{border-color:var(--amber);color:var(--amber)}
.inv-list{overflow:auto;display:grid;gap:12px;align-content:start;padding-right:2px}
.inv-group h3{margin:0 0 6px;font-family:var(--mono);font-weight:400;font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--hud);display:flex;justify-content:space-between}
.inv-group h3 span{color:var(--faint)}
.inv-item{width:100%;display:grid;grid-template-columns:34px minmax(0,1fr) auto;grid-template-rows:auto auto;column-gap:10px;align-items:center;text-align:left;background:transparent;border:1px solid transparent;color:var(--star);padding:6px 8px;cursor:pointer}
.inv-item:hover{border-color:var(--line);background:var(--panel)}
.inv-item[aria-current="true"]{border-color:var(--amber);background:color-mix(in srgb,var(--amber) 8%,transparent)}
.inv-item .ico{grid-row:1 / span 2;width:34px;height:34px;color:var(--hud)}
.inv-item.dim .ico{color:var(--faint)}
.inv-item .t{font-family:var(--body);font-size:15px;line-height:1.2;overflow-wrap:anywhere}
.inv-item .s{grid-column:2 / span 2;font-family:var(--mono);font-size:9.5px;letter-spacing:.04em;color:var(--faint);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.inv-item .b{font-family:var(--mono);font-size:9px;letter-spacing:.08em;text-transform:uppercase;padding:1px 5px;border:1px solid var(--line);color:var(--faint)}
.inv-item .b-vise{color:var(--amber);border-color:var(--amber)}
.inv-item .b-installe{color:var(--void);background:var(--hud);border-color:var(--hud)}
.inv-detail{border:1px solid var(--line);background:var(--hull);padding:18px clamp(16px,2.5vw,26px);min-height:300px;display:grid;gap:14px;align-content:start;scroll-margin-top:110px}
.inv-detail:focus{outline:none}
.inv-back{display:none;justify-self:start;background:none;border:0;color:var(--hud);font-family:var(--mono);font-size:11px;letter-spacing:.06em;cursor:pointer;padding:0}
@media (max-width:820px){.inv-back{display:inline-block}}
.d-head{display:grid;gap:3px}
.d-head .mk{font-family:var(--mono);font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--faint)}
.d-head h2{margin:0;font-family:var(--display);font-weight:500;text-transform:uppercase;font-size:clamp(34px,5vw,52px);line-height:.95}
.d-head .tag{font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--amber)}
.d-story{margin:0;font-style:italic;color:var(--star);font-size:17px;max-width:64ch}
.inv-detail h4,.map-detail h4{margin:4px 0 0;font-family:var(--mono);font-weight:400;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--hud);border-top:1px solid var(--line);padding-top:10px}
.inv-detail p{margin:0;max-width:68ch}
.muted{color:var(--dim);font-size:14.5px}
.where{font-family:var(--mono);font-size:11.5px;color:var(--hud);line-height:1.5}
.d-text{display:grid;gap:10px}
.d-html .chapter{margin-top:0}
.d-html .cols{grid-template-columns:minmax(0,1fr)}
.d-html .data{max-width:520px}
.slot{margin:0;display:grid;gap:8px}
.slot img{width:100%;max-height:360px;object-fit:cover;border:1px solid var(--line);display:block}
.schem{position:relative;aspect-ratio:16/8;max-height:300px;border:1px solid var(--line);display:grid;place-items:center;color:var(--hud);
  background:linear-gradient(var(--hull),var(--hull)) padding-box,repeating-linear-gradient(0deg,transparent 0 23px,rgba(134,207,200,.08) 23px 24px),repeating-linear-gradient(90deg,transparent 0 23px,rgba(134,207,200,.08) 23px 24px);
  background-blend-mode:normal}
.schem{background:repeating-linear-gradient(0deg,transparent 0 23px,rgba(134,207,200,.07) 23px 24px),repeating-linear-gradient(90deg,transparent 0 23px,rgba(134,207,200,.07) 23px 24px),#0b1219}
.schem .ico{width:min(46%,220px);height:auto;stroke-width:1.6}
.schem span{position:absolute;left:10px;bottom:8px;font-family:var(--mono);font-size:9.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--faint)}
.up{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.small-btn{font-size:10px;padding:6px 10px;cursor:pointer}
.up-msg{font-family:var(--mono);font-size:10.5px;color:var(--dim)}
.evo-grid{display:grid;gap:8px;grid-template-columns:repeat(auto-fill,minmax(min(230px,100%),1fr))}
.evo-chip{display:grid;grid-template-columns:30px minmax(0,1fr);grid-template-rows:auto auto;column-gap:10px;align-items:center;text-align:left;background:var(--panel);border:1px solid var(--line);color:var(--star);padding:8px 10px;cursor:pointer;font-family:var(--body);font-size:14.5px}
.evo-chip:hover{border-color:var(--hud)}
.evo-chip .ico{grid-row:1 / span 2;width:30px;height:30px;color:var(--hud)}
.evo-chip .evo-status{justify-self:start;margin-top:3px}
.evo-status.big{justify-self:start;font-size:11px;padding:3px 9px}
/* ---------- map ---------- */
.map{margin-top:22px;display:grid;gap:10px;position:relative;left:50%;width:min(1500px,calc(100vw - 32px));transform:translateX(-50%)}
.map-bar{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}
.crumbs{font-family:var(--mono);font-size:11px;letter-spacing:.06em;color:var(--faint);display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.crumbs button{background:none;border:0;color:var(--hud);font:inherit;letter-spacing:inherit;cursor:pointer;padding:2px 0;text-decoration:underline dotted}
.crumbs span{color:var(--star)}
.map-body{display:grid;grid-template-columns:minmax(0,2.5fr) minmax(300px,1fr);gap:16px;align-items:start}
@media (max-width:1000px){.map-body{grid-template-columns:minmax(0,1fr)}}
.map-detail{max-height:min(860px,calc(100vh - 40px));overflow:auto;position:sticky;top:16px}
@media (max-width:1000px){.map-detail{max-height:none;position:static}}
.map-stage{overflow-x:auto;-webkit-overflow-scrolling:touch;border:1px solid var(--line);background:radial-gradient(ellipse at 50% 50%,#0d1420,#05070b 70%);overflow:hidden}
.map-stage svg{display:block;width:100%;height:auto;min-width:760px}
.map-hint{display:none;font-family:var(--mono);font-size:10.5px;color:var(--faint);letter-spacing:.06em}
@media (max-width:800px){.map-hint{display:block}}
.map-detail{border:1px solid var(--line);background:var(--hull);padding:16px 18px;display:grid;gap:12px;align-content:start}
.map-detail .d-head h2{font-size:clamp(30px,4vw,44px)}
.star{fill:#e9e5da;opacity:.55}
.lbl{fill:var(--star);font-family:var(--mono);font-size:15px;paint-order:stroke;stroke:#05070b;stroke-width:4px;stroke-linejoin:round;letter-spacing:.06em;pointer-events:none}
.lbl.big{font-size:17px;font-family:var(--display);letter-spacing:.08em;text-transform:uppercase}
.lbl.tiny{fill:var(--faint);font-size:11px}
.lbl.ring-l{fill:var(--hud);font-size:11.5px}
.home-l{fill:var(--amber)!important;font-size:12.5px}
.jump{stroke:var(--hud);stroke-width:1.5;opacity:.7}
.jump.dash{stroke-dasharray:6 6}
.jump.faded{opacity:.22}
.orbit{fill:none;stroke:rgba(134,207,200,.16);stroke-width:1}
.belt{fill:none;stroke:rgba(180,170,150,.35);stroke-width:7;stroke-dasharray:2 5}
.hit{fill:none;stroke:transparent;stroke-width:16}
.node{cursor:pointer;outline:none}
.node .sel{fill:none;stroke:transparent;stroke-width:2}
.node:hover .sel,.node:focus-visible .sel{stroke:var(--hud)}
.node.act .sel{stroke:var(--amber)}
.ringnode:hover .hit,.ringnode:focus-visible .hit{stroke:rgba(134,207,200,.18)}
.ringnode.act .hit{stroke:rgba(224,163,71,.25)}
.sysnode.faded{cursor:default;opacity:.55}
.spec{fill:var(--panel);stroke:var(--line)}
.specnode:hover .spec,.specnode:focus-visible .spec{stroke:var(--hud)}
.specnode.act .spec{stroke:var(--amber)}
.inv-cats[hidden],.evo-card[hidden],.evo-group[hidden]{display:none}
.evo-filter{display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 14px}
.evo-group{margin:0 0 16px}
.evo-group h5{font-family:var(--mono);font-size:10.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--faint);margin:0 0 8px;font-weight:400}
.evo-card{border:1px solid var(--line);background:var(--panel);margin:0 0 8px}
.evo-card[data-status="vise"]{border-color:rgba(224,163,71,.55)}
.evo-card[data-status="installe"]{border-color:var(--hud)}
.evo-card summary{display:grid;grid-template-columns:36px minmax(0,1fr) auto;grid-template-rows:auto auto;column-gap:12px;row-gap:2px;align-items:center;padding:10px 12px;cursor:pointer;list-style:none}
.evo-card summary::-webkit-details-marker{display:none}
.evo-card summary .ico{grid-row:1 / span 2;width:36px;height:36px;color:var(--hud)}
.evo-card summary .t{font-size:16px;color:var(--star);min-width:0}
.evo-card summary .s{grid-column:2 / span 2;font-family:var(--mono);font-size:11px;color:var(--faint);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.evo-card[open] summary .s{white-space:normal}
.evo-card summary:hover .t{color:var(--hud)}
.evo-card summary:focus-visible{outline:1px solid var(--hud);outline-offset:-1px}
.evo-body{padding:0 12px 12px}
.evo-body .slot{max-width:420px}
.lore-note{display:inline-block;font-family:var(--mono);font-size:10.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--faint);border:1px dashed var(--line);padding:3px 8px;margin:0 0 12px}
.lbl.small{font-size:14.5px}
.sysnode.lore .lbl{fill:var(--dim)}
.sysnode.lore:hover .lbl,.sysnode.lore.act .lbl{fill:var(--star)}
.map.portrait .map-stage svg{min-width:0}
.map.portrait .map-hint{display:none}
.map.portrait .lbl{font-size:21px;stroke-width:5px}
.map.portrait .lbl.big{font-size:25px}
.map.portrait .lbl.small{font-size:20px}
.map.portrait .lbl.tiny{font-size:16px}
.map.portrait .lbl.ring-l{font-size:17px}
.moondot{fill:#cfd6dd;opacity:.85;pointer-events:none}
#tab-cap .cap{margin-top:28px}
.node.unexplored .body{opacity:.45}
.node.unexplored .lbl{fill:var(--dim)}
.disc{fill:none;stroke:var(--hud);stroke-width:2;stroke-dasharray:3 3;pointer-events:none}
.disc-row{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;font-family:var(--mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--faint)}
.disc-row.on .disc-state{color:var(--hud)}
.disc-msg{color:var(--amber);text-transform:none;letter-spacing:0}
.chip-disc{grid-column:2;justify-self:end;color:var(--hud);font-family:var(--mono);font-size:12px}
.placenode .body{fill:#86cfc8;stroke:#05070b;stroke-width:1.5}
.placenode.t-ville .body{fill:#e0a347}
.placenode.t-gateway .body{fill:#a99be8}
.placenode.unexplored .body{opacity:.6}
.lbl.pl-l{font-size:11px;fill:var(--dim);pointer-events:auto;cursor:pointer}
.placenode:hover .lbl,.placenode.act .lbl{fill:var(--star)}
.map.portrait .lbl.pl-l{font-size:15px}
.map.portrait .placenode.t-lagrange:not(.act) .pl-l{display:none}
.map-detail .pl-head h2{font-size:clamp(24px,3vw,32px);line-height:1.05}
.zl{list-style:none;margin:0;padding:0;display:grid;gap:8px}
.zl li{display:grid;gap:2px;border-left:2px solid var(--line);padding:2px 0 2px 10px;font-size:14.5px}
.zl li b{font-weight:400;color:var(--star)}
.zl li span:not(.acc){color:var(--dim);font-size:13.5px;line-height:1.45}
.acc{justify-self:start;font-family:var(--mono);font-size:9.5px;letter-spacing:.1em;text-transform:uppercase;padding:1px 6px;border:1px solid var(--line);color:var(--faint)}
.acc-a{color:var(--hud);border-color:var(--hud)}.acc-v{color:var(--amber);border-color:var(--amber)}.acc-x{color:#e2624b;border-color:#e2624b}
.placenode.marker .body{fill:#7d8590}
.sitenode .body{stroke-width:2;stroke:#05070b}
.sitenode.s-l .body{fill:#86cfc8}.sitenode.s-h .body{fill:#e2624b}.sitenode.s-u .body{fill:#b0a79c}
.sitenode.unq .body{fill:#05070b;stroke-width:1.8}
.sitenode.unq.s-l .body{stroke:#86cfc8}.sitenode.unq.s-h .body{stroke:#e2624b}.sitenode.unq.s-u .body{stroke:#b0a79c}
.lbl.site-l{font-size:11px;opacity:0;transition:opacity .15s}
.sitenode:hover .site-l,.sitenode:focus-visible .site-l,.sitenode.act .site-l{opacity:1}
.map.portrait .lbl.site-l{font-size:15px}
.acc-h{color:var(--amber)!important}
.cat-h{margin:6px 0 2px;font-family:var(--mono);font-weight:400;font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--faint)}
.zl li i{font-style:normal;color:var(--faint)}
.site-chips{display:flex;flex-wrap:wrap;gap:6px}
.site-chip{font-family:var(--mono);font-size:11px;padding:4px 8px;background:var(--panel);border:1px solid var(--line);color:var(--star);cursor:pointer;text-align:left}
.site-chip:hover{border-color:var(--hud)}
.site-chip.s-h{border-left:3px solid #e2624b}.site-chip.s-l{border-left:3px solid #86cfc8}.site-chip.s-u{border-left:3px solid #b0a79c}
.site-chip.unq{border-style:dashed}
.muted.small{font-size:12px}
.map-body{grid-template-areas:"stage detail" "hint detail" "list detail";grid-template-rows:auto auto 1fr}
.map-stage{grid-area:stage;min-width:0}.map-hint{grid-area:hint}.map-detail{grid-area:detail}.map-list{grid-area:list;align-self:start;min-width:0}
@media (max-width:1000px){.map-body{grid-template-areas:"stage" "hint" "detail" "list";grid-template-rows:auto}}
.map-list{margin-top:0;border:1px solid var(--line);background:var(--hull);padding:14px 16px;display:grid;gap:8px}
.ml-head{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:baseline;gap:6px 14px}
.ml-head h3{margin:0;font-family:var(--display);font-weight:500;font-size:22px;text-transform:uppercase;letter-spacing:.04em;color:var(--star)}
.ml-head span,.ml-leg{font-family:var(--mono);font-size:11px;color:var(--faint);letter-spacing:.04em;margin:0}
.ml-leg .qt{margin-left:10px}
.qt{font-family:var(--mono);color:var(--faint)}.qt.on{color:var(--hud)}
.ml-grp{border-top:1px solid var(--line);padding-top:6px}
.ml-grp summary{cursor:pointer;font-family:var(--mono);font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--amber);padding:4px 0}
.ml-grp summary span{color:var(--faint);margin-left:6px}
.ml-grp ul{list-style:none;margin:4px 0 6px;padding:0;display:grid;gap:2px;grid-template-columns:repeat(auto-fill,minmax(min(280px,100%),1fr))}
.ml-it{width:100%;display:grid;grid-template-columns:16px minmax(0,1fr) auto;gap:8px;align-items:center;text-align:left;background:none;border:1px solid transparent;color:var(--star);font-family:var(--body);font-size:14.5px;padding:5px 8px;cursor:pointer}
.ml-it:hover{border-color:var(--line);background:var(--panel)}
.ml-it.act{border-color:var(--amber);background:var(--panel)}
.ml-it .n{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ml-it .ty{font-family:var(--mono);font-size:9.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--faint);white-space:nowrap}
.qt.hx{color:#e2624b}
.ml-h summary{color:#e2624b}.ml-u summary{color:var(--dim)}
.ml-it{grid-template-columns:16px minmax(0,1fr);row-gap:0}
.ml-it .ty{grid-column:2;white-space:normal}
.ml-it .n{white-space:normal}
.pulse{pointer-events:none;fill:none;stroke:var(--amber);stroke-width:1.5;opacity:.8;transform-box:fill-box;transform-origin:center;animation:pulse 2.4s ease-out infinite}
@keyframes pulse{0%{transform:scale(.7);opacity:.9}100%{transform:scale(1.25);opacity:0}}
@media (prefers-reduced-motion:reduce){.pulse{animation:none}}
.home{cursor:pointer}
.citymark circle{fill:var(--star)}
.citymark.home circle:first-child{fill:var(--amber)}
.city{font-family:var(--mono);font-size:12px;color:var(--star);margin:0}
.city.home{color:var(--amber)}
.utils{display:grid;gap:6px}
.utils .u{display:grid;grid-template-columns:auto 1fr;gap:10px;align-items:baseline;font-size:14px;line-height:1.4}
.tagc{--c:var(--dim);font-family:var(--mono);font-size:9.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--c);border:1px solid color-mix(in srgb,var(--c) 55%,transparent);padding:2px 6px;white-space:nowrap}
'''
style = g('head_style').replace('</style>', g('extra_css') + css + '\n</style>')
out = g('title_and_fonts') + '\n' + style + '\n\n' + body + '\n\n' + script + '\n<script>\n' + appjs + '\n</script>' + tabjs + '\n'
open('journal-v3.html', 'w', encoding='utf-8').write(out)
print(len(out), len(codex), 'codex items')
